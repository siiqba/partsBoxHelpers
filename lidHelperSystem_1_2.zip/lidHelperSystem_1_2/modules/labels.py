from PySide6.QtCore import Qt, QDir, QXmlStreamAttributes, QXmlStreamWriter, QByteArray, QXmlStreamReader
from enum import Enum
from typing import Any, ClassVar, Final
from PySide6.QtCore import QRect, QRectF, QSize, QSizeF, QPoint, QPointF, QMarginsF, QMargins, QBuffer
from PySide6.QtGui import QFont, QFontMetrics, QFontMetricsF, QPageSize, QPageLayout, QPainter, QBrush, QFontInfo, QPen
from PySide6.QtSvg import QSvgGenerator

# if __name__ != "__main__":
#     from modules.dataProviders import PidItemData
if __name__ == "__main__":
    from PySide6.QtPrintSupport import QPrinterInfo, QPrinter
    from PySide6.QtSvg import QSvgRenderer
    from PySide6.QtWidgets import QApplication
    
    # def setPrinter(self, printer:Any|dict|None)->bool:
    #     if print is None: return False
    #     if isinstance(printer, PrinterDescriptor):
    #         self.name = printer.name
    #         self.dpi = printer.dpi
    #         self.systemName = printer.systemName
    #         return True
    #     try:
    #         self.name = printer["name"]
    #         self.dpi = int(printer["dpi"])
    #         self.systemName = printer["systemName"]
    #     except:
    #         return False
    #     return True


class LabelDescriptor(object):
    name:str
    width:int
    height:int
    margin:list[float]
    
    basicKeys: ClassVar[list[str]]=["name", "width", "height", "margin"]

    @classmethod
    def getInstance(cls, label:Any|dict|None)->Any|None:
        if label is None: return None
        tempObj = cls()
        if isinstance(label, LabelDescriptor):
            tempObj.name = label.name
            tempObj.width = label.width
            tempObj.height = label.height
            tempObj.margin = label.margin
        elif isinstance(label, dict):
            for key in cls.basicKeys:
                if key in label:
                    setattr(tempObj, key, label[key])
                else:
                    return None
        return tempObj

    def __new__(cls):
        return super(__class__, cls).__new__(cls)
    
    def __init__(self):
        # super().__init__(None)
        self.name = "NaN"
        self.width = 0
        self.height = 0
        self.margin = [0, 0, 0, 0]

    def __str__(self):
        return f"{self.name}-> W:{self.width}, H:{self.height}, M:{self.margin}"
    
    # def setLabel(self, label:Any|dict|None)->bool:
    #     if label is None: return False
    #     if isinstance(label, LabelDescriptor):
    #         self.name = label.name
    #         self.width = label.width
    #         self.height = label.height
    #         return True
    #     try:
    #         self.name = label["name"]
    #         self.width = label["width"]
    #         self.height = label["height"]
    #     except:
    #         return False
    #     return True


class SVG_FONTFAMILI(Enum):
        ARIAL = "Arial"
        COURIER = "Courier"
        COURIER_NEW = "Courier New"
        CONSOLAS = "Consolas"
    
class SVG_COLOR(Enum):
        CORAL = "coral"
        YELLOW = "yellow"
        WHITE = "white"
        BLACK = "black"
        REG = "red"
        GOLD = "goldenrod"
        NONE = "none"

class SVG_FONTWEIGHT(Enum):
    BOLD = "bold"
    NORMAL = "Normal"

class SVG_RESOLUTION(Enum):
        DPI203 = 203
        DPI300 = 300
        DPI600 = 600

#width -> x
class PartLabel(object):
    code128BTablePattern:Final[list]=[
    [2, 1, 2, 2, 2, 2],
    [2, 2, 2, 1, 2, 2],
    [2, 2, 2, 2, 2, 1],
    [1, 2, 1, 2, 2, 3],
    [1, 2, 1, 3, 2, 2],
    [1, 3, 1, 2, 2, 2],
    [1, 2, 2, 2, 1, 3],
    [1, 2, 2, 3, 1, 2],
    [1, 3, 2, 2, 1, 2],
    [2, 2, 1, 2, 1, 3],
    [2, 2, 1, 3, 1, 2],
    [2, 3, 1, 2, 1, 2],
    [1, 1, 2, 2, 3, 2],
    [1, 2, 2, 1, 3, 2],
    [1, 2, 2, 2, 3, 1],
    [1, 1, 3, 2, 2, 2],
    [1, 2, 3, 1, 2, 2],
    [1, 2, 3, 2, 2, 1],
    [2, 2, 3, 2, 1, 1],
    [2, 2, 1, 1, 3, 2],
    [2, 2, 1, 2, 3, 1],
    [2, 1, 3, 2, 1, 2],
    [2, 2, 3, 1, 1, 2],
    [3, 1, 2, 1, 3, 1],
    [3, 1, 1, 2, 2, 2],
    [3, 2, 1, 1, 2, 2],
    [3, 2, 1, 2, 2, 1],
    [3, 1, 2, 2, 1, 2],
    [3, 2, 2, 1, 1, 2],
    [3, 2, 2, 2, 1, 1],
    [2, 1, 2, 1, 2, 3],
    [2, 1, 2, 3, 2, 1],
    [2, 3, 2, 1, 2, 1],
    [1, 1, 1, 3, 2, 3],
    [1, 3, 1, 1, 2, 3],
    [1, 3, 1, 3, 2, 1],
    [1, 1, 2, 3, 1, 3],
    [1, 3, 2, 1, 1, 3],
    [1, 3, 2, 3, 1, 1],
    [2, 1, 1, 3, 1, 3],
    [2, 3, 1, 1, 1, 3],
    [2, 3, 1, 3, 1, 1],
    [1, 1, 2, 1, 3, 3],
    [1, 1, 2, 3, 3, 1],
    [1, 3, 2, 1, 3, 1],
    [1, 1, 3, 1, 2, 3],
    [1, 1, 3, 3, 2, 1],
    [1, 3, 3, 1, 2, 1],
    [3, 1, 3, 1, 2, 1],
    [2, 1, 1, 3, 3, 1],
    [2, 3, 1, 1, 3, 1],
    [2, 1, 3, 1, 1, 3],
    [2, 1, 3, 3, 1, 1],
    [2, 1, 3, 1, 3, 1],
    [3, 1, 1, 1, 2, 3],
    [3, 1, 1, 3, 2, 1],
    [3, 3, 1, 1, 2, 1],
    [3, 1, 2, 1, 1, 3],
    [3, 1, 2, 3, 1, 1],
    [3, 3, 2, 1, 1, 1],
    [3, 1, 4, 1, 1, 1],
    [2, 2, 1, 4, 1, 1],
    [4, 3, 1, 1, 1, 1],
    [1, 1, 1, 2, 2, 4],
    [1, 1, 1, 4, 2, 2],
    [1, 2, 1, 1, 2, 4],
    [1, 2, 1, 4, 2, 1],
    [1, 4, 1, 1, 2, 2],
    [1, 4, 1, 2, 2, 1],
    [1, 1, 2, 2, 1, 4],
    [1, 1, 2, 4, 1, 2],
    [1, 2, 2, 1, 1, 4],
    [1, 2, 2, 4, 1, 1],
    [1, 4, 2, 1, 1, 2],
    [1, 4, 2, 2, 1, 1],
    [2, 4, 1, 2, 1, 1],
    [2, 2, 1, 1, 1, 4],
    [4, 1, 3, 1, 1, 1],
    [2, 4, 1, 1, 1, 2],
    [1, 3, 4, 1, 1, 1],
    [1, 1, 1, 2, 4, 2],
    [1, 2, 1, 1, 4, 2],
    [1, 2, 1, 2, 4, 1],
    [1, 1, 4, 2, 1, 2],
    [1, 2, 4, 1, 1, 2],
    [1, 2, 4, 2, 1, 1],
    [4, 1, 1, 2, 1, 2],
    [4, 2, 1, 1, 1, 2],
    [4, 2, 1, 2, 1, 1],
    [2, 1, 2, 1, 4, 1],
    [2, 1, 4, 1, 2, 1],
    [4, 1, 2, 1, 2, 1],
    [1, 1, 1, 1, 4, 3],
    [1, 1, 1, 3, 4, 1],
    [1, 3, 1, 1, 4, 1],
    [1, 1, 4, 1, 1, 3],
    [1, 1, 4, 3, 1, 1],
    [4, 1, 1, 1, 1, 3],
    [4, 1, 1, 3, 1, 1],
    [1, 1, 3, 1, 4, 1],
    [1, 1, 4, 1, 3, 1],
    [3, 1, 1, 1, 4, 1],
    [4, 1, 1, 1, 3, 1],
    [2, 1, 1, 4, 1, 2],
    [2, 1, 1, 2, 1, 4],
    [2, 1, 1, 2, 3, 2],
    [2, 3, 3, 1, 1, 1],

    [2, 1, 1, 2, 1, 4],
    [2, 3, 3, 1, 1, 1, 2]
    ]

    CODE128MODULESSIZE:Final[int] = 11
    CODE128STOPMODULESSIZE:Final[int] = 13
    CODE128SILENCEAREA:Final[int] = 2
    CODE128BSTARTCODE:Final[int] = 104
    CODE128BSTARTCODE_IND:Final[int] = -2
    CODE128BSTOP_IND:Final[int] = -1
    CODE128ASTARTCODE:Final[int] = 103
    CODE128BMODULO:Final[int] = 103

    LABEL_CONTENT_ITEM_ELEMENTS:ClassVar[int] = 4
    LABEL_CONTENT_ITEM_TYPE_IND:ClassVar[int] = 0
    LABEL_CONTENT_ITEM_FONT_WEIGHT_IND:ClassVar[int] = 1
    LABEL_CONTENT_ITEM_FONT_INVERT_IND:ClassVar[int] = 2
    LABEL_CONTENT_ITEM_TEXT_IND:ClassVar[int] = 3
    LABEL_CONTENT_ITEM_TYPE_TXT:ClassVar[str] = "txt"
    LABEL_CONTENT_ITEM_TYPE_BAR:ClassVar[str] = "bar"

    INCH:Final[float] = 25.4
    FONTPOINT:Final[float] = 72.0
    # INVERTEDTEXTPADDING:Final[int]=2

    labelsBoundaryBox:dict[str, list[float]]={
        "PidItemData":[5, 3, 2, 2, 2, 2],
        "LidItemData":[6, 3, 3, 3, 2]
    }

    labelSize_mm:QSizeF
    labelSize_pix:QSizeF
    labelMargin_mm:QMarginsF
    labelMargin_pix:QMarginsF
    labelFrontColor:SVG_COLOR
    labelBackgroundColor:SVG_COLOR
    iconFrontColor:SVG_COLOR
    iconBackgroundColor:SVG_COLOR
    labelResolution:int
    currentFrontColor:SVG_COLOR
    currentBackgroundColor:SVG_COLOR

    strOutputCanvas:str|None



    def __new__(cls):
        return super(__class__, cls).__new__(cls)
    
    def __init__(self):
        self.labelSize_mm = QSizeF(60, 40)
        self.labelMargin_mm = QMarginsF(0.2, 0.2, 0.2, 0.2)
        self.labelFrontColor = SVG_COLOR.BLACK
        self.labelBackgroundColor = SVG_COLOR.WHITE
        self.iconFrontColor = SVG_COLOR.BLACK
        self.iconBackgroundColor = SVG_COLOR.CORAL
        self.labelResolution = SVG_RESOLUTION.DPI300.value
        self.currentFrontColor = self.labelFrontColor
        self.currentBackgroundColor = self.labelBackgroundColor

        self.strOutputCanvas = None
        self.calculateLabelParam()
    
    def mm2pix(self, mmValue:float)->float:
        temp:float = (self.labelResolution * mmValue) / self.INCH
        return temp
    
    def calculateLabelParam(self)->None:
        wi = self.mm2pix(self.labelSize_mm.width())
        hi = self.mm2pix(self.labelSize_mm.height())
        self.labelSize_pix = QSizeF(wi, hi)
        self.labelMargin_pix = QMarginsF(self.mm2pix(self.labelMargin_mm.left()),
                                        self.mm2pix(self.labelMargin_mm.top()),
                                        self.mm2pix(self.labelMargin_mm.right()),
                                        self.mm2pix(self.labelMargin_mm.bottom()))
    
    def setPrinterDpi(self, dpi:int|SVG_RESOLUTION|None)->None:
        if isinstance(dpi, int):
            self.labelResolution = dpi
        elif isinstance(dpi, SVG_RESOLUTION):
            self.labelResolution = dpi.value
        else:
            self.labelResolution = SVG_RESOLUTION.DPI300
        self.calculateLabelParam()
    
    def setLabelSize(self, size:QSize|QSizeF|None)->None:
        if isinstance(size, QSize) or isinstance(size, QSizeF):
            self.labelSize_mm = QSizeF(size)
        else:
            self.labelSize_mm = QSizeF(60, 40)
        self.calculateLabelParam()

    def setLabelMargin(self, margin:QMarginsF|list[float]|None)->None:
        if isinstance(margin, QMarginsF):
            self.labelMargin_mm = QMarginsF(margin)
        elif isinstance(margin, list) and (len(margin) == 4):
            self.labelMargin_mm = QMarginsF(margin[0], margin[1], margin[2], margin[3])
        else:
            self.labelMargin_mm = QMarginsF(0.1, 0.1, 0.1, 0.1)
        self.calculateLabelParam()

    def setLabelColors(self, color:SVG_COLOR|None=SVG_COLOR.BLACK, colorBack:SVG_COLOR|None = None)->None:
        if isinstance(color, SVG_COLOR):
            self.labelFrontColor = color
        else:
            self.labelFrontColor = SVG_COLOR.BLACK
        if isinstance(colorBack, SVG_COLOR):
            self.labelBackgroundColor = colorBack
        else:
            self.labelBackgroundColor = SVG_COLOR.WHITE
    
    def setIconColors(self, color:SVG_COLOR|None=SVG_COLOR.BLACK, colorBack:SVG_COLOR|None = None)->None:
        if isinstance(color, SVG_COLOR):
            self.iconFrontColor = color
        else:
            self.iconFrontColor = SVG_COLOR.BLACK
        if isinstance(colorBack, SVG_COLOR):
            self.iconBackgroundColor = colorBack
        else:
            self.iconBackgroundColor = SVG_COLOR.CORAL

    def setLabelParamByDict(self, param)->None:
        if not isinstance(param, dict): return
        """{'name': '50 x 40 mm', 'width': 50, 'height': 40}"""
        self.setLabelSize(QSizeF(param['width'], param["height"]))
    
    def setPrinterParamByDict(self, param)->None:
        if not isinstance(param, dict): return
        """{'name': 'ZEBRA ZD220', 'dpi': 203, 'systemName': 'ZD220'}"""
        self.setPrinterDpi(param['dpi'])

    def setCollors(self, isIcon:bool = False, invert:bool = False)->None:
        if invert:
            if isIcon:
                self.currentFrontColor = self.iconBackgroundColor
                self.currentBackgroundColor = self.iconFrontColor
            else:
                self.currentFrontColor = self.labelBackgroundColor
                self.currentBackgroundColor = self.labelFrontColor
        else:
            if isIcon:
                self.currentFrontColor = self.iconFrontColor
                self.currentBackgroundColor = self.iconBackgroundColor
            else:
                self.currentFrontColor = self.labelFrontColor
                self.currentBackgroundColor = self.labelBackgroundColor

    """<rect x="10" y="10" width="180" height="80" rx="20" ry="20" fill="none" stroke="blue" stroke-width="2"/> width -> x""" 
    def drawRectange(self, boundaryBox:QRectF, recStartPoint:QPointF, size_endPoint:QSizeF|QPointF, borderColor:SVG_COLOR|None = None,
                      strokeWidth:int|None = None, rx:int|None=None, ry:int|None=None)->None:
        
        if isinstance(size_endPoint, QPointF):
            recSize = QSizeF(abs(size_endPoint.x() - recStartPoint.x()), abs(size_endPoint.y() - recStartPoint.y()))
        elif isinstance(size_endPoint, QSizeF):
            recSize = size_endPoint
        elif size_endPoint is None: return
        
        dr_X = round(boundaryBox.left() + recStartPoint.x() * boundaryBox.width())
        dr_Y = round(boundaryBox.top() + recStartPoint.y() * boundaryBox.height())
        dr_Width = round(boundaryBox.width() * recSize.width())
        dr_Height = round(boundaryBox.height() * recSize.height())

        outStr = f"<rect x=\"{str(dr_X)}\" y=\"{str(dr_Y)}\" width=\"{str(dr_Width)}\" height=\"{str(dr_Height)}\"" +\
                    f" fill=\"{self.currentFrontColor.value}\""
        if isinstance(borderColor, SVG_COLOR):
            outStr += f" stroke=\"{borderColor.value}\""
        if isinstance(strokeWidth, int) and strokeWidth > 0:
            outStr += f" stroke-width=\"{str(strokeWidth)}\""
        if isinstance(rx, int) and rx > 0:
            outStr += f" rx=\"{str(rx)}\""
        if isinstance(ry, int) and ry > 0:
            outStr += f" ry=\"{str(ry)}\""
        outStr += " />"
        self.strOutputCanvas += outStr
    
    def drawDebugRectange(self, boundaryBox:QRectF, recStartPoint:QPointF, size_endPoint:QSizeF|QPointF, borderColor:SVG_COLOR|None = None,
                      strokeWidth:int|None = None, rx:int|None=None, ry:int|None=None)->None:
        
        if isinstance(size_endPoint, QPointF):
            recSize = QSizeF(abs(size_endPoint.x() - recStartPoint.x()), abs(size_endPoint.y() - recStartPoint.y()))
        elif isinstance(size_endPoint, QSizeF):
            recSize = size_endPoint
        elif size_endPoint is None: return
        
        dr_X = round(boundaryBox.left() + recStartPoint.x() * boundaryBox.width())
        dr_Y = round(boundaryBox.top() + recStartPoint.y() * boundaryBox.height())
        dr_Width = round(boundaryBox.width() * recSize.width())
        dr_Height = round(boundaryBox.height() * recSize.height())

        # outStr = f"<rect x=\"{str(dr_X)}\" y=\"{str(dr_Y)}\" width=\"{str(dr_Width)}\" height=\"{str(dr_Height)}\"" +\
        #             f" fill=\"{self.currentFrontColor.value}\""
        outStr = f"<rect x=\"{str(dr_X)}\" y=\"{str(dr_Y)}\" width=\"{str(dr_Width)}\" height=\"{str(dr_Height)}\"" +\
                    f" fill=\"none\""
        if isinstance(borderColor, SVG_COLOR):
            outStr += f" stroke=\"{borderColor.value}\""
        if isinstance(strokeWidth, int) and strokeWidth > 0:
            outStr += f" stroke-width=\"{str(strokeWidth)}\""
        if isinstance(rx, int) and rx > 0:
            outStr += f" rx=\"{str(rx)}\""
        if isinstance(ry, int) and ry > 0:
            outStr += f" ry=\"{str(ry)}\""
        outStr += " />"
        self.strOutputCanvas += outStr

    def drawSvgStartElement(self, isIcon:bool=False)->None:
        
        self.strOutputCanvas = f"<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"{str(round(self.labelSize_pix.width()))}\" "+\
            f"height=\"{str(round(self.labelSize_pix.height()))}\" fill=\"none\">"
        
        if isIcon:
            self.setCollors(isIcon, invert=True)
            self.drawRectange(QRectF(QPointF(0, 0), self.labelSize_pix), QPointF(0, 0), QSizeF(1, 1),
                              None, None, 30, 30)
            self.setCollors(isIcon, invert=False)
    
    def drawEndElement(self)->None:
        self.strOutputCanvas += "</svg>"
    
    def getFontSizeForBoundaryBox(self, boundaryBox:QRectF, txt:str, fontFamily:SVG_FONTFAMILI,\
                                  weight:bool|SVG_FONTWEIGHT = SVG_FONTWEIGHT.NORMAL)->list:
    
        maxTextWidth = boundaryBox.width()
        if weight == SVG_FONTWEIGHT.NORMAL: isBold = False
        else: isBold = True

        calcFontSize = 10
        font = QFont(fontFamily.value, calcFontSize)
        font.setBold(isBold)
        fontMetric = QFontMetricsF(font)
        fontRec = fontMetric.boundingRect(txt)
        # horizontalAdvance = fontMetric.horizontalAdvance(txt)
        # height = fontMetric.height()
        horizontalAdvance = fontRec.width()
        height = fontRec.height()
        descent = fontMetric.descent()
        ascent = fontMetric.ascent()
       
        ratioW = horizontalAdvance / maxTextWidth
        ratioH = height/boundaryBox.height()
        calcFontSize = (calcFontSize / max(ratioW, ratioH))
        descent = descent / max(ratioW, ratioH)
        ascent = ascent / max(ratioW, ratioH)
        horizontalAdvance = horizontalAdvance / max(ratioW, ratioH)
        
        return [calcFontSize, ascent, descent, horizontalAdvance]
    
    def drawTextCenter(self, boundaryBox:QRectF, txt:str, fontFamily:SVG_FONTFAMILI, weight:SVG_FONTWEIGHT,\
                       invert:bool = False)->None:
        fontBoxParam = self.getFontSizeForBoundaryBox(boundaryBox, txt, fontFamily, weight)
        fontSize = fontBoxParam[0]
        ascent = fontBoxParam[1]
        descent = fontBoxParam[2]
        textWidth = fontBoxParam[3]
        fontHalfHeight = (ascent + descent)/2.0
        # test1 = boundaryBox.center().y()
        posX = round(boundaryBox.center().x())
        posY = round(boundaryBox.center().y() + (fontHalfHeight - descent))
        colorFront = self.currentFrontColor.value
        outStr = ""
        if invert:
            colorFront = self.currentBackgroundColor.value
            colorBack = self.currentFrontColor.value
            recPosX = round(boundaryBox.center().x() - (textWidth/2))
            recPosY = round(boundaryBox.center().y() - fontHalfHeight )
            recWidth = textWidth
            recHeight = fontHalfHeight*2 
            outStr = f"<rect x=\"{recPosX}\" y=\"{recPosY}\" width=\"{recWidth}\" height=\"{recHeight}\"" +\
                    f" fill=\"{colorBack}\" />"
        txt = txt.replace("&", "&amp;")
        txt = txt.replace(">", "&gt;")
        txt = txt.replace("<", "&lt;")
        outStr += f"<text x=\"{posX}\" y=\"{posY}\" fill=\"{colorFront}\" stroke=\"{colorFront}\"" +\
                 f" font-weight=\"{weight.value}\" font-family=\"{fontFamily.value}\" font-size=\"{fontSize}pt\" text-anchor=\"middle\">" +\
                 f"{txt} </text>"
        
        self.strOutputCanvas += outStr

    def drawBarcodeChar(self, x_start:int, y_comon:int, height:int, moduleSize:float, data:int|str)->int:
        if isinstance(data, str): data = ord(data) - ord(" ")
        pattern = self.code128BTablePattern[data]
        curX = x_start
        outStr = ""
        j = 0
        for i in pattern:
            subModule = moduleSize*float(i)
            if not j%2:
                outStr += f"<rect x=\"{round(curX, 2)}\" y=\"{y_comon}\" width=\"{round(subModule, 2)}\" height=\"{height}\"" +\
                        f" fill=\"{self.currentFrontColor.value}\"/>"
            curX = curX + subModule
            j +=1
        self.strOutputCanvas += outStr
        return curX
        
    def drawBarCode(self, boundaryBox:QRectF, content:str)->None:
        #start(11) + content(len*11) + crc(11) + stop(13)
        codeModules = self.CODE128SILENCEAREA + self.CODE128MODULESSIZE + (self.CODE128MODULESSIZE*len(content)) + \
                    self.CODE128MODULESSIZE + self.CODE128STOPMODULESSIZE + self.CODE128SILENCEAREA
        singleModuleSize:float = boundaryBox.width() / codeModules

        if singleModuleSize < 1.0: return
        
        crc:int = 104 #start Code B value
        for i in range(1, len(content)+1):
            crc += (ord(content[i-1]) - ord(" ")) * i
        crc = crc % 103

        startX = round(boundaryBox.left() + (self.CODE128SILENCEAREA * singleModuleSize))
        commonY = round(boundaryBox.top())
        commonHeight = round(boundaryBox.height())
        startX = self.drawBarcodeChar(startX, commonY, commonHeight, singleModuleSize, self.CODE128BSTARTCODE_IND)
        for t in content:
            startX = self.drawBarcodeChar(startX, commonY, commonHeight, singleModuleSize, t)
        startX = self.drawBarcodeChar(startX, commonY, commonHeight, singleModuleSize, crc)
        startX = self.drawBarcodeChar(startX, commonY, commonHeight, singleModuleSize, self.CODE128BSTOP_IND)
        pass

    def getBoundaryBoxs(self, rowAspectList:list[float])->list[QRectF]:
        nrOfModules = sum(rowAspectList)
        ret = list()
        labelActiveWidth:float = self.labelSize_pix.width() - self.labelMargin_pix.left() - self.labelMargin_pix.right()
        labelActiveHeight:float = self.labelSize_pix.height() - self.labelMargin_pix.top() - self.labelMargin_pix.bottom()
        labelHeightDelta:float = labelActiveHeight / float(nrOfModules)
        curYcounter:float = self.labelMargin_pix.top()
        for rowAspect in rowAspectList:
            ret.append(QRectF(self.labelMargin_pix.left(), curYcounter, labelActiveWidth, (labelHeightDelta * rowAspect)))
            curYcounter += (labelHeightDelta * rowAspect)
        return ret

    def drawItemContent(self, boundaryBox: QRectF, itemData:list[str, SVG_FONTWEIGHT, bool, str])->None:
        if not (isinstance(itemData, list) and len(itemData) == PartLabel.LABEL_CONTENT_ITEM_ELEMENTS): return
        if itemData[PartLabel.LABEL_CONTENT_ITEM_TYPE_IND] == PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT:
            self.drawTextCenter(boundaryBox,
                                itemData[PartLabel.LABEL_CONTENT_ITEM_TEXT_IND],
                                SVG_FONTFAMILI.ARIAL,
                                itemData[PartLabel.LABEL_CONTENT_ITEM_FONT_WEIGHT_IND],
                                itemData[PartLabel.LABEL_CONTENT_ITEM_FONT_INVERT_IND])
        elif itemData[PartLabel.LABEL_CONTENT_ITEM_TYPE_IND] == PartLabel.LABEL_CONTENT_ITEM_TYPE_BAR:
            self.drawBarCode(boundaryBox, itemData[PartLabel.LABEL_CONTENT_ITEM_TEXT_IND])
        else:
            return

    def getSvgLabel(self, content:list[str,list[str, SVG_FONTWEIGHT, bool, str]], isIcon:bool = False)->str:
       
        if not (isinstance(content, list) and len(content) == 2): return ""
        if content[0] not in self.labelsBoundaryBox: return ""
        aspectRatioBox = self.labelsBoundaryBox[content[0]].copy()
        _content:list = content[1]
        if not (isinstance(_content, list) and len(_content) > 0): return ""
        if len(_content[0]) != self.LABEL_CONTENT_ITEM_ELEMENTS: return ""

        while len(aspectRatioBox) > len(_content):
            aspectRatioBox.pop()

        boundaryBoxes = self.getBoundaryBoxs(aspectRatioBox)
        self.drawSvgStartElement(isIcon)
        
        self.setCollors(isIcon, invert=False)
        i = 0
        for box in boundaryBoxes:
            # self.drawDebugRectange(box, QPointF(0,0), QSizeF(1, 1), SVG_COLOR.YELLOW, 2)
            self.drawItemContent(box, _content[i])
            i += 1
        self.drawEndElement()
        return self.strOutputCanvas

    # def getLabel(self, obj:PidItemData|list, isIcon:bool = False)->str:
    #     if isinstance(obj, PidItemData):
    #         content = ["PidItemData",]
    #         subContent = list()
    #         subContent.append([PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.BOLD, False, obj.pid])
    #         subContent.append([PartLabel.LABEL_CONTENT_ITEM_TYPE_BAR, SVG_FONTWEIGHT.NORMAL, False, obj.pid])
    #         subContent.append([PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.BOLD, False, obj.mpn])
    #         subContent.append([PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, False, obj.manufacturer])
    #         subContent.append([PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.BOLD, True, obj.sds1])
    #         if len(obj.sds2) > 0:
    #             subContent.append([PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, False, obj.sds2])
    #         content.append(subContent)
    #         return self.getSvgLabel(content, isIcon)
    #     if isinstance(obj, list):
    #         return self.getSvgLabel(obj, isIcon)
    #     else:
    #         return ""
        
def printOnPrinter(printerName:str, labelSize:QSizeF, svgTx:str)->None:
    # app = QApplication()
    printersInfo = QPrinterInfo.availablePrinters()
    selectedPrinter = None
    for printer in printersInfo:
        if printer.isNull():
            continue
        if not printerName in printer.printerName():
            continue
        selectedPrinter = printer  
        break
    if selectedPrinter is not None:
        tempPrinter = QPrinter(selectedPrinter)
        retOk = tempPrinter.setPageSize(QPageSize(labelSize, QPageSize.Unit.Millimeter))
        # retOk = tempPrinter.setPageSize(QPageSize(labelSize, QPageSize.Unit.Millimeter))
        retOk = tempPrinter.setPageOrientation(QPageLayout.Orientation.Portrait)
        tempPrinter.setFullPage(True)
        retOk = tempPrinter.setPageMargins(QMarginsF(0, 0, 0, 0), QPageLayout.Unit.Millimeter)
        # retOk = tempPrinter.setPageMargins(QMarginsF(2, 2.0, 2, 2.0), QPageLayout.Unit.Millimeter)
        
        retOk = tempPrinter.isValid()

        svgXmlStreeam = QXmlStreamReader(svgTx)
        svgRender = QSvgRenderer(svgXmlStreeam)
        svgPainter = QPainter(tempPrinter)
        svgRender.render(svgPainter)
        svgPainter.end()
        pass

if __name__ == "__main__":
    # test:PartsLabel = PartsLabel(QSize(57, 32))
    # retTxt = test.generatePidLabelRaw2("#C0001", "RC0402FR-072K49L", "Yageo Group", "2k49 1% 0402")
    # print(retTxt)
    # checkFont = QFont("Arial", 10, QFont.Weight.Bold)
    # fm = QFontMetrics(checkFont)
    # size = fm.size(0, "Ala ma kota")
    # print(size)
    app = QApplication()
    labelSize = QSizeF(50, 40)
    # labelSize = QSizeF(57, 32)
    testLabel = PartLabel()
    # testLabel.setLabelColors(SVG_COLOR.BLACK, SVG_COLOR.NONE)
    testLabel.setLabelColors(SVG_COLOR.BLACK, SVG_COLOR.CORAL)
    testLabel.setLabelSize(labelSize)
    testLabel.setLabelMargin(QMarginsF(0.5, 0.5, 0.5, 0.5))
    testLabel.setPrinterDpi(SVG_RESOLUTION.DPI203)
    # testLabel.setPrinterDpi(SVG_RESOLUTION.DPI300)
    
    labelContentList=[
        "PidItemData",
        [
            [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.BOLD, False, "#C0001"],
            [PartLabel.LABEL_CONTENT_ITEM_TYPE_BAR, SVG_FONTWEIGHT.NORMAL, False, "#C0001"],
            [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.BOLD, False, "MNP part number"],
            [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, False, "manufacturer"],
            [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, True, "SDS1 filed - opis"],
            [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, False, "SDS2 filed - opis"]
        ]
    ]
    svgTx = testLabel.getSvgLabel(labelContentList, True)# BaRdZo DłuGi TeXt TeStOwY

    # printOnPrinter("ZD220", labelSize, svgTx)#ZD220  
    print(svgTx)
    exit(0)