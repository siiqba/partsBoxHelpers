from PySide6.QtCore import Qt, QDir, QEvent, QSizeF
from PySide6.QtWidgets import (QPushButton, QWidget, QLineEdit, QGridLayout, QComboBox,
                               QHBoxLayout, QVBoxLayout, QLabel, QMessageBox,
                               QSizePolicy, QTableView, QTextEdit, QMainWindow, QListView,
                               QHeaderView, QFileDialog, QProgressBar)
from PySide6.QtGui import QPixmap
from modules.appMenagment import AppMenagment
from modules.appSettings import AppSettings
from modules.partsBoxProvider import PartsBoxProject, PartsBoxPart
from modules.widgets.label import QCLabelWidget
from modules.labels import PartLabel, SVG_FONTWEIGHT, SVG_COLOR, LabelDescriptor
from modules.printer import PrinterDescriptor

from typing import Any

class LidLabelWindow(QMainWindow):
    currentPidIndex:int
    appMenagment:AppMenagment
    appSettings:AppSettings
    currentProject:PartsBoxProject
    pidPartsList:list[PartsBoxPart]|None
    currentPidPart:PartsBoxPart|None
    currentPrinterDescriptor: PrinterDescriptor|None
    currentLabelDescriptor: LabelDescriptor|None

    svgLabelPid:str|None
    svgLabelLid:str|None

    def __init__(self, parent: QWidget | None, appMenagment:AppMenagment, currentProject:PartsBoxProject) -> None:
        super().__init__(parent)
        self.currentPidIndex = 0
        self.appMenagment = appMenagment
        self.appSettings = self.appMenagment.getAppSettings()
        self.currentProject = currentProject
        self.svgLabelPid = None
        self.svgLabelLid = None

        self.prepareLayout()
        self.updateLayoutValues()

        self.textEditProjectName.setText(self.currentProject.name)
        self.lineEditProjectQuantity.setText("1")
        if isinstance(self.currentProject.image, QPixmap):
            self.labelProjectPic.setText("")
            self.labelProjectPic.setPixmap(self.currentProject.image.scaled(120, 120, Qt.AspectRatioMode.KeepAspectRatio))
        else:
            self.labelProjectPic.setText("No Pic")
        
        self.currentLabelDescriptor = self.appSettings.getCurrentParam(LabelDescriptor)
        print("Label: {}".format(self.currentLabelDescriptor))
        self.currentPrinterDescriptor = self.appSettings.getCurrentParam(PrinterDescriptor)
        print("Printer: {}".format(self.currentPrinterDescriptor))

        self.appSettings.langSettingsChanged.connect(self.updateLayoutValues)
        # self.appSettings.printerSettingsChanged.connect(self.printerChangedEvent)
        self.appSettings.anyParamChanged.connect(self.currentSettingsChangedEvent)

        self.buttonPidUp.clicked.connect(self.buttonPidUpEvent)
        self.buttonPidDown.clicked.connect(self.buttonPidDownEvent)

        self.pidPartsList = self.collectPidElements(self.currentProject)
        if isinstance(self.pidPartsList, list):
            self.currentPidPart = self.pidPartsList[0]
        self.setCurrentPidElement(self.currentPidPart)
        # labelPidContentList=[
        #     "PidItemData",
        #     [
        #         [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.BOLD, False, "#C0001"],
        #         [PartLabel.LABEL_CONTENT_ITEM_TYPE_BAR, SVG_FONTWEIGHT.NORMAL, False, "#C0001"],
        #         [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.BOLD, False, "MNP part number"],
        #         [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, False, "manufacturer"],
        #         [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, True, "SDS1 filed - opis"],
        #         [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, False, "SDS2 filed - opis"]
        #     ]
        # ]
        # labelLidContentList=[
        #     "LidItemData",
        #     [
        #         [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.BOLD, False, "C0001"],
        #         [PartLabel.LABEL_CONTENT_ITEM_TYPE_BAR, SVG_FONTWEIGHT.NORMAL, False, "C0001"],
        #         [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.BOLD, False, "SDS1 filed - opis"],
        #         [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, False, "SDS2 filed - opis"],
        #         [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, False, "Footprint"]
        #     ]
        # ]
        # labelGenerator = PartLabel()
        # labelGenerator.setLabelSize(QSizeF(self.currentLabelDescriptor.width, self.currentLabelDescriptor.height))
        # labelGenerator.setLabelMargin(self.currentLabelDescriptor.margin)
        # labelGenerator.setIconColors(SVG_COLOR.BLACK, SVG_COLOR.CORAL)
        # self.svgLabelPid = labelGenerator.getSvgLabel(labelPidContentList, True)
        # self.stickerPidDisplay.setSvg(self.svgLabelPid)
        # labelGenerator.setIconColors(SVG_COLOR.BLACK, SVG_COLOR.GOLD)
        # self.svgLabelLid = labelGenerator.getSvgLabel(labelLidContentList, True)
        # self.stickerLidDisplay.setSvg(self.svgLabelLid)

    def updateLayoutValues(self)->None:
        self.labelProjectName.setText(self.appSettings.tr(self, "labelProjectName"))
        self.labelQuantity.setText(self.appSettings.tr(self, "labelQuantity"))
        self.setWindowTitle(self.appSettings.tr(self.appSettings.SETTINGS_TYPE.GLOBAL,\
                                                self.appSettings.SETTINGS_TYPE.APP_NAME))
        self.buttonPidUp.setText(self.appSettings.tr(self, "buttonPidUp"))
        self.buttonPidDown.setText(self.appSettings.tr(self, "buttonPidDown"))
        self.buttonAssignaLid.setText(self.appSettings.tr(self, "buttonAssignaLid"))
        self.buttonUnasignLid.setText(self.appSettings.tr(self, "buttonUnasignLid"))
    
    def prepareLayout(self)->None:
        self.labelProjectName = QLabel("Project:")
        self.labelQuantity = QLabel("Quantity:")
        self.textEditProjectName = QTextEdit("Project name", self, readOnly=True)
        self.lineEditProjectQuantity = QLineEdit("5", self)
        self.labelProjectPic = QLabel("pic", self)
        self.stickerLidDisplay = QCLabelWidget(350, 200, self)
        self.stickerPidDisplay = QCLabelWidget(350, 200, self)
        self.stickerLidDisplay.setMinimumWidth(400)
        self.stickerLidDisplay.setMaximumWidth(450)
        self.stickerLidDisplay.setMinimumHeight(180)# do usuniecia
        self.stickerLidDisplay.setMaximumHeight(200)
        self.stickerPidDisplay.setMinimumWidth(400)
        self.stickerPidDisplay.setMaximumWidth(450)
        self.stickerPidDisplay.setMinimumHeight(180)# do usuniecia
        self.stickerPidDisplay.setMaximumHeight(200)

        self.buttonPidUp = QPushButton("up", self)
        self.lineEditPid = QLineEdit("", self)
        self.lineEditPid.setDisabled(True)
        self.lineEditPidDescription = QLineEdit("", self)
        self.lineEditPidAvaliableQuantity = QLineEdit("", self)
        self.lineEditPidPositionCount = QLineEdit("", self)
        self.buttonPidDown = QPushButton("Down", self)

        self.tableViewLid=QTableView(self)
        self.buttonAssignaLid = QPushButton("assign", self)
        self.buttonUnasignLid = QPushButton("unassign", self)

        containerG1 = QWidget(self)
        containerG1.setProperty('class', 'widgetBorder')
        layoutG1 = QGridLayout(containerG1)
        #                                               R   C
        layoutG1.addWidget(self.labelProjectName,       0, 0, Qt.AlignmentFlag.AlignLeft)
        layoutG1.addWidget(self.labelQuantity,          1, 0, Qt.AlignmentFlag.AlignLeft)
        self.textEditProjectName.setMaximumSize(10000, 60)
        self.textEditProjectName.setMinimumSize(500, 60)
        self.textEditProjectName.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)
        layoutG1.addWidget(self.textEditProjectName,    0, 1, Qt.AlignmentFlag.AlignLeft)
        self.lineEditProjectQuantity.setMaximumSize(1000, 30)
        self.lineEditProjectQuantity.setMinimumSize(250, 30)
        self.lineEditProjectQuantity.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)
        layoutG1.addWidget(self.lineEditProjectQuantity, 1, 1, Qt.AlignmentFlag.AlignLeft)
        expandWidgetG1 = QWidget(self)
        expandWidgetG1.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)
        layoutG1.addWidget(expandWidgetG1,              1, 2)
        self.labelProjectPic.setMaximumSize(120, 120)
        self.labelProjectPic.setMinimumSize(60, 60)
        layoutG1.addWidget(self.labelProjectPic,        0, 3, 3, 1, Qt.AlignmentFlag.AlignRight)

        containerH1 = QWidget(self)
        containerH1.setProperty('class', 'widgetBorder')
        layoutH1 = QHBoxLayout(containerH1)
        layoutH1.addWidget(self.stickerPidDisplay, 0, Qt.AlignmentFlag.AlignLeft)
        expandWidgetH1 = QWidget(self)
        # expandWidgetH1.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)
        layoutH1.addWidget(expandWidgetH1, 1)
        layoutH1.addWidget(self.stickerLidDisplay, 0, Qt.AlignmentFlag.AlignRight)

        containerH2 = QWidget(self)
        layoutH2 = QHBoxLayout(containerH2)
        expandWidgetV2L = QWidget(self)
        expandWidgetV2L.setSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)
        expandWidgetV2R = QWidget(self)
        expandWidgetV2R.setSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)
        layoutH2.addWidget(expandWidgetV2L, 1, Qt.AlignmentFlag.AlignLeft)
        layoutH2.addWidget(self.buttonPidUp, 0, Qt.AlignmentFlag.AlignLeft)
        layoutH2.addWidget(self.lineEditPid, 0, Qt.AlignmentFlag.AlignLeft)
        layoutH2.addWidget(self.lineEditPidDescription, 0, Qt.AlignmentFlag.AlignLeft)
        layoutH2.addWidget(self.lineEditPidAvaliableQuantity, 0, Qt.AlignmentFlag.AlignLeft)
        layoutH2.addWidget(self.lineEditPidPositionCount, 0, Qt.AlignmentFlag.AlignLeft)
        layoutH2.addWidget(self.buttonPidDown, 0, Qt.AlignmentFlag.AlignLeft)
        layoutH2.addWidget(expandWidgetV2R, 1, Qt.AlignmentFlag.AlignRight)
        
        containerH3 = QWidget(self)
        layoutH3 = QHBoxLayout(containerH3)
        layoutH3.addWidget(self.tableViewLid, 1, Qt.AlignmentFlag.AlignLeft)
        layoutH3.addWidget(self.buttonAssignaLid, 0, Qt.AlignmentFlag.AlignLeft)
        layoutH3.addWidget(self.buttonUnasignLid, 0, Qt.AlignmentFlag.AlignLeft)

        containerV2 = QWidget(self)
        containerV2.setProperty('class', 'widgetBorder')
        layoutV2 = QVBoxLayout(containerV2)
        layoutV2.addWidget(containerH2, 0, Qt.AlignmentFlag.AlignTop)
        layoutV2.addWidget(containerH3, 1, Qt.AlignmentFlag.AlignTop)

        layoutV1 = QVBoxLayout()
        containerG1.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)
        layoutV1.addWidget(containerG1, 0, Qt.AlignmentFlag.AlignTop)
        layoutV1.addWidget(containerH1, 0, Qt.AlignmentFlag.AlignTop)
        layoutV1.addWidget(containerV2, 0, Qt.AlignmentFlag.AlignTop)
        self.mainWidget = QWidget(self)
        self.mainWidget.setLayout(layoutV1)
        self.setCentralWidget(self.mainWidget)

    def updateLabelParam(self, newLabel:LabelDescriptor)->None:
        self.currentLabelDescriptor = newLabel
        # print("Label: {}".format(self.currentLabelDescriptor))
        labelPidContentList=[
            "PidItemData",
            [
                [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.BOLD, False, "#C0001"],
                [PartLabel.LABEL_CONTENT_ITEM_TYPE_BAR, SVG_FONTWEIGHT.NORMAL, False, "#C0001"],
                [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.BOLD, False, "MNP part number"],
                [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, False, "manufacturer"],
                [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, True, "SDS1 filed - opis"],
                [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, False, "SDS2 filed - opis"]
            ]
        ]
        labelLidContentList=[
            "LidItemData",
            [
                [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.BOLD, False, "C0001"],
                [PartLabel.LABEL_CONTENT_ITEM_TYPE_BAR, SVG_FONTWEIGHT.NORMAL, False, "C0001"],
                [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.BOLD, False, "SDS1 filed - opis"],
                [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, False, "SDS2 filed - opis"],
                [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, False, "Footprint"]
            ]
        ]
        labelGenerator = PartLabel()
        labelGenerator.setLabelSize(QSizeF(self.currentLabelDescriptor.width, self.currentLabelDescriptor.height))
        labelGenerator.setLabelMargin(self.currentLabelDescriptor.margin)
        labelGenerator.setIconColors(SVG_COLOR.BLACK, SVG_COLOR.CORAL)
        self.svgLabelPid = labelGenerator.getSvgLabel(labelPidContentList, True)
        self.stickerPidDisplay.setSvg(self.svgLabelPid)
        labelGenerator.setIconColors(SVG_COLOR.BLACK, SVG_COLOR.GOLD)
        self.svgLabelLid = labelGenerator.getSvgLabel(labelLidContentList, True)
        self.stickerLidDisplay.setSvg(self.svgLabelLid)

    def collectPidElements(self, project:PartsBoxProject)->list[PartsBoxPart]|None:
        pidElementsList:list[PartsBoxPart] = list()
        if not isinstance(project.bom, list): return None
        for tlid in project.bom:
            if not isinstance(tlid, PartsBoxPart): continue
            _tlid:PartsBoxPart = tlid
            if _tlid.isPid:
                pidElementsList.append(_tlid)
                continue
            elif _tlid.isLid:
                if not isinstance(_tlid.pidParts, list): continue
                for tpid in _tlid.pidParts:
                    if not isinstance(tpid, PartsBoxPart): continue
                    _tpid:PartsBoxPart = tpid
                    if _tpid.isPid:
                        pidElementsList.append(_tpid)
        if len(pidElementsList) < 1: return None
        return pidElementsList

    def currentSettingsChangedEvent(self, name:str, value:Any, isValid:bool)->None:
        if isinstance(value, LabelDescriptor): self.updateLabelParam(value)
        elif isinstance(value, PrinterDescriptor):
            self.currentPrinterDescriptor = value
            print("Printer: {}".format(self.currentPrinterDescriptor))

    def updateCurrentPidlable(self, part:PartsBoxPart|None = None)->None:
        if part is None:
            part = self.currentPidPart
        if part is None: return
        labelPidContentList=[
            "PidItemData",
            [
                [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.BOLD, False, part.name],
                [PartLabel.LABEL_CONTENT_ITEM_TYPE_BAR, SVG_FONTWEIGHT.NORMAL, False, part.name],
                [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.BOLD, False, part.mpn],
                [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, False, part.manufacturer]
                # [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, True, "SDS1 filed - opis"],
                # [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, False, "SDS2 filed - opis"]
            ]
        ]
        if part.sds1 is None:
            labelPidContentList[1].append(
                [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, True, "NaN"])
        else:
            labelPidContentList[1].append(
                [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, True, part.sds1])
        if part.sds2 is None:
            pass
        else:
            labelPidContentList[1].append(
                [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, False, part.sds2])
        labelGenerator = PartLabel()
        labelGenerator.setLabelSize(
            QSizeF(self.currentLabelDescriptor.width, self.currentLabelDescriptor.height))
        labelGenerator.setLabelMargin(self.currentLabelDescriptor.margin)
        labelGenerator.setIconColors(SVG_COLOR.BLACK, SVG_COLOR.CORAL)
        self.svgLabelPid = labelGenerator.getSvgLabel(labelPidContentList, True)
        self.stickerPidDisplay.setSvg(self.svgLabelPid)

    def setCurrentPidElement(self, part:PartsBoxPart|None)->None:
        if part is None: return
        if not part.isPid: return
        self.currentPidPart = part
        self.lineEditPid.setText(part.name)
        self.updateCurrentPidlable()


    def buttonPidUpEvent(self)->None:
        if not isinstance(self.pidPartsList, list): return
        if len(self.pidPartsList) < 1: return
        self.currentPidIndex += 1
        if self.currentPidIndex >= len(self.pidPartsList):
            self.currentPidIndex = len(self.pidPartsList) -1
        self.setCurrentPidElement(self.pidPartsList[self.currentPidIndex])

    def buttonPidDownEvent(self)->None:
        if not isinstance(self.pidPartsList, list): return
        if len(self.pidPartsList) < 1: return
        self.currentPidIndex -= 1
        if self.currentPidIndex < 0: self.currentPidIndex = 0
        self.setCurrentPidElement(self.pidPartsList[self.currentPidIndex])

    def closeEvent(self, event):
        # if event.type() != QEvent.Type.User:
        self.appMenagment.onWindowClose(self)
        return super().closeEvent(event)