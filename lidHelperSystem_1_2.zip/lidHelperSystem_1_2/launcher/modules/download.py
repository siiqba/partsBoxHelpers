from PySide6.QtCore import Qt, QObject, Signal, Slot, QThreadPool, QRunnable
from typing import Any, ClassVar, Final, Self
from enum import Enum
import requests

class GitHubDowload(QObject, QRunnable):
    reqestFinal:ClassVar[Signal] = Signal((bool, str, int, int))
    reqestUpdate:ClassVar[Signal] = Signal((str, int, int))

    chunkSize:Final[int] = 8192
    url:str
    destination:str|None
    returnText:str|bool|None

    def __init__(self, url:str, destination:str|None=None, parent:QObject|None = None):
        QRunnable.__init__(self)
        QObject.__init__(self, parent)
        self.url = url
        self.destination = destination
        self.returnText = None
    
    def getReturn(self)->str|bool|None:
        return self.returnText
    
    @Slot()
    def run(self)->None:
        req:requests.Response|None = None
        totalSize:int = 0

        self.reqestUpdate.emit("Reciving data", 0, 0)
        if self.destination is None:
            streemMode = False
        else:
            streemMode = True
        try:
            req = requests.get(self.url, stream=streemMode, timeout=10)
            req.raise_for_status()
            totalSize = int(req.headers.get("Content-Length", 0))
        except:
            req = None
        if req is None:
            self.returnText = None
            self.reqestFinal.emit(False, "Error in reciving data", 1, 0)
            return
        if not streemMode:
            self.returnText = req.text
            req.close()
            self.reqestFinal.emit(True, "End of reciving", 1, 0)
            return

        chunkMax = int(totalSize / self.chunkSize)
        chunkVal = 0

        with open(self.destination, "wb") as f:
            for chunk in req.iter_content(chunk_size=self.chunkSize):
                if chunk:  # filter out keep-alive chunks
                    f.write(chunk)
                    chunkVal += 1
                    self.reqestUpdate.emit("reciving file", chunkMax, chunkVal)
        self.returnText = True
        self.reqestFinal.emit(True, "End of reciving", 1, 0)
        req.close()
        
    
class UpdateProcess(QObject):
    reqestFinal:ClassVar[Signal] = Signal((bool, str, int, int,))
    reqestUpdate:ClassVar[Signal] = Signal((str, int, int,))
    statusUrl:str
    gitHubDownload:GitHubDowload|None
    workerThreadPool:QThreadPool
    returnValue:str|bool|None

    def __init__(self, parent:QObject|None = None):
        QObject.__init__(self, parent)
        self.statusUrl = "https://raw.githubusercontent.com/siiqba/partsBoxHelpers/main/status.json"
        self.gitHubDownload = None
        self.returnValue = None
        self.workerThreadPool = QThreadPool()

    @Slot()
    def reqestFinalSlot(self, sucess:bool, txt:str, maxVal:int, val:int)->None:
        self.returnValue = self.gitHubDownload.getReturn()
        # self.reqestFinal.disconnect()
        self.gitHubDownload.reqestFinal.disconnect()
        self.gitHubDownload.reqestUpdate.disconnect()
        # del self.gitHubDownload
        self.reqestFinal.emit(sucess, txt, maxVal, val)
    
    @Slot()
    def reqestUpdateSlot(self, txt:str, maxVal:int, val:int)->None:
        self.reqestUpdate.emit(txt, maxVal, val)

    def startGetStatus(self, onUpdate:object, onFinal:object)->None:
        self.gitHubDownload = GitHubDowload(self.statusUrl)
        self.gitHubDownload.reqestUpdate.connect(self.reqestUpdateSlot)
        self.gitHubDownload.reqestFinal.connect(self.reqestFinalSlot)
        # self.reqestFinal.connect(onFinal)
        self.workerThreadPool.start(self.gitHubDownload)

    def getReturnValue(self)->str|bool|None:
        return self.returnValue

