from PySide6.QtCore import Qt, QDir, QTimer, Slot
from PySide6.QtWidgets import (QPushButton, QWidget, QLineEdit, QGridLayout, QComboBox,
                               QHBoxLayout, QVBoxLayout, QLabel, QMessageBox,
                               QSizePolicy, QTableView, QTextEdit, QMainWindow, QListView,
                               QHeaderView, QFileDialog, QProgressBar)
from PySide6.QtGui import QPixmap
from typing import Any, ClassVar, Final, Self
from enum import Enum
# import requests
import json

from modules.download import UpdateProcess

class SplashWindow(QMainWindow):
    leftTime:int
    updateProcess:UpdateProcess|None

    def __init__(self, parent: QWidget|None = None) -> None:
        super().__init__(parent)
        self.updateProcess = None
        
        self.setWindowFlag(Qt.WindowType.FramelessWindowHint|Qt.WindowType.WindowStaysOnTopHint)
        self.leftTime = 20
        self.timerWait1s = QTimer(self, singleShot=False, interval= 1000)
        self.setWindowTitle("Update")
        self.setGeometry(400, 400, 600, 400)
        self.prepareLayout()

        # screen = self.screen()
        # print(f"{screen.name()} -> availableGeometry():{screen.availableGeometry()}; geometry():{screen.geometry()}")
        self.center_on_screen(self)

        self.pushButtonCancel.clicked.connect(self.pushButtonCancelPressEvent)
        self.pushButtonUpdate.clicked.connect(self.pushButtonUpdateEvent)
        self.timerWait1s.timeout.connect(self.timerWait1sTimeoutEvent)

        self.timerWait1s.start()

    def center_on_screen(self, window:QWidget)->None:
        screen = window.screen()
        screen_geo = screen.availableGeometry()
        window_geo = window.frameGeometry()

        x = screen_geo.x() + (screen_geo.width() - window_geo.width()) // 2
        y = screen_geo.y() + (screen_geo.height() - window_geo.height()) // 2

        window.move(x, y)

    def timerWait1sTimeoutEvent(self)->None:
        if self.leftTime > 0:
            self.leftTime -= 1
            self.qLabelTimer.setText(str(self.leftTime))
        else:
            self.timerWait1s.stop()
            # self.pushButtonUpdateEvent()

    def pushButtonCancelPressEvent(self)->None:
        self.close()

    def updateLayoutMessage(self, text:str, maxVal:int, val:int)->None:
        self.progressBarMain.setMaximum(maxVal)
        self.progressBarMain.setValue(val)
        self.progressBarMain.setFormat(text)
        messageText = self.textEditMessage.toPlainText()
        messageText += text + "\n"
        self.textEditMessage.setPlainText(messageText)

    # @Slot()
    def onUpdateEvent(self, text:str, maxVal:int, val:int)->None:
        self.updateLayoutMessage(text, maxVal, val)

    # @Slot()
    def onFinalEvent(self, isSucess:bool, text:str, maxVal:int, val:int)->None:
        self.updateProcess.reqestUpdate.disconnect(self.onUpdateEvent)
        self.updateProcess.reqestFinal.disconnect(self.onFinalEvent)
        ret = self.updateProcess.getReturnValue()
        ret = json.loads(ret)
        self.updateLayoutMessage(text, maxVal, val)
        del self.updateProcess
        self.updateProcess = None

    def pushButtonUpdateEvent(self)->None:
        # if self.updateProcess is None:
        self.updateProcess = UpdateProcess()
        self.updateProcess.reqestUpdate.connect(self.onUpdateEvent)
        self.updateProcess.reqestFinal.connect(self.onFinalEvent)
        self.updateProcess.startGetStatus(self.onUpdateEvent, self.onFinalEvent)
        # output_path = ".\\temp\\ala.7z"

    def prepareLayout(self)->None:
        self.setStyleSheet("Widget{background-color:#3C413C;}")

        self.labelTitle = QLabel("Check for update", self)

        self.progressBarMain = QProgressBar(self)
        self.progressBarMain.setTextVisible(True)
        self.progressBarMain.setFormat("Ala ma kota")
        self.progressBarMain.setMinimum(0)
        self.progressBarMain.setMaximum(0)
        self.progressBarMain.setValue(5)
        self.progressBarMain.setFormat("ala ma kota")

        self.textEditMessage = QTextEdit("", self)
        self.textEditMessage.setEnabled(False)

        self.pushButtonCancel = QPushButton("Cancel", self)
        self.pushButtonUpdate = QPushButton("Update", self)
        self.qLabelTimer = QLabel(str(self.leftTime), self)
        containerH1 = QWidget(self)
        layoutH1 = QHBoxLayout(containerH1)
        layoutH1.addWidget(self.pushButtonCancel, 1)
        layoutH1.addWidget(self.qLabelTimer, 0, Qt.AlignmentFlag.AlignCenter)
        layoutH1.addWidget(self.pushButtonUpdate, 1)

        centerWidget = QWidget(self)
        layoutMain = QVBoxLayout(centerWidget)
        self.setCentralWidget(centerWidget)
        layoutMain.addWidget(self.labelTitle, 0)
        layoutMain.addWidget(self.progressBarMain, 0)
        layoutMain.addWidget(self.textEditMessage, 1)
        layoutMain.addWidget(containerH1, 0)




