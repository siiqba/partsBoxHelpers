from PySide6.QtWidgets import QApplication, QSplashScreen
from PySide6.QtCore import QDir, QIODevice, Qt
from PySide6.QtGui import QPalette, QColor
from sys import exit, path
from pathlib import Path



APP_SETTINGS_NAME:str = "settings/settingsApp.json"
APP_STATE_NAME:str = "settings/lastStateApp.json"


def get_darkModePalette( app:QApplication ):
    
    darkPalette = app.palette()
    darkPalette.setColor( QPalette.ColorRole.Window, QColor( 53, 53, 53 ) )
    darkPalette.setColor( QPalette.ColorRole.WindowText, Qt.GlobalColor.white )
    darkPalette.setColor( QPalette.ColorGroup.Disabled, QPalette.ColorRole.WindowText, QColor( 127, 127, 127 ) )
    darkPalette.setColor( QPalette.ColorRole.Base, QColor( 42, 42, 42 ) )
    darkPalette.setColor( QPalette.ColorRole.AlternateBase, QColor( 66, 66, 66 ) )
    darkPalette.setColor( QPalette.ColorRole.ToolTipBase, QColor( 53, 53, 53 ) )
    darkPalette.setColor( QPalette.ColorRole.ToolTipText, Qt.GlobalColor.white )
    darkPalette.setColor( QPalette.ColorRole.Text, Qt.GlobalColor.white )
    darkPalette.setColor( QPalette.ColorGroup.Disabled, QPalette.ColorRole.Text, QColor( 127, 127, 127 ) )
    darkPalette.setColor( QPalette.ColorRole.Dark, QColor( 35, 35, 35 ) )
    darkPalette.setColor( QPalette.ColorRole.Shadow, QColor( 20, 20, 20 ) )
    darkPalette.setColor( QPalette.ColorRole.Button, QColor( 53, 53, 53 ) )
    darkPalette.setColor( QPalette.ColorRole.ButtonText, Qt.GlobalColor.white )
    darkPalette.setColor( QPalette.ColorGroup.Disabled, QPalette.ColorRole.ButtonText, QColor( 127, 127, 127 ) )
    darkPalette.setColor( QPalette.ColorRole.BrightText, Qt.GlobalColor.red )
    darkPalette.setColor( QPalette.ColorRole.Link, QColor( 42, 130, 218 ) )
    darkPalette.setColor( QPalette.ColorRole.Highlight, QColor( 42, 130, 218 ) )
    darkPalette.setColor( QPalette.ColorGroup.Disabled, QPalette.ColorRole.Highlight, QColor( 80, 80, 80 ) )
    darkPalette.setColor( QPalette.ColorRole.HighlightedText, Qt.GlobalColor.white )
    darkPalette.setColor( QPalette.ColorGroup.Disabled, QPalette.ColorRole.HighlightedText, QColor( 127, 127, 127 ), )
    
    return darkPalette
    
def appRun()->int:
    BASE_DIR = Path(__file__).resolve().parent
    print(BASE_DIR)
    path.insert(0, str(BASE_DIR))
    from modules.appMenagment import AppMenagment

    APP_MAIN_VERSION:int = 1
    APP_MINOR_VERSION:int = 2

    app = QApplication()
    app.setStyle('Fusion')
    app.setPalette( get_darkModePalette( app ) )

    script_path = Path(__file__).resolve()
    rootPath = str(script_path.parent)
    qRootPath = QDir(rootPath)
    
    cssSheetPath = qRootPath.__copy__()
    cssSheetPath.cd("css")
    
    cssFilePath = cssSheetPath.filePath("appStyles.css")
    with open(cssFilePath, "r", encoding="utf-8") as f:
        app.setStyleSheet(f.read())

    appManagment = AppMenagment(qRootPath, APP_SETTINGS_NAME, APP_STATE_NAME)
    appManagment.showWindow("MainAppWindow")
    if not appManagment.isAnyWidowPresent():
        exit(0)
        # app.closeAllWindows()
    
    appRet = app.exec()
    return appRet

if __name__ == "__main__":
    # from pathlib import Path

    # APP_MAIN_VERSION:int = 1
    # APP_MINOR_VERSION:int = 2

    # app = QApplication()
    # app.setStyle('Fusion')
    # app.setPalette( get_darkModePalette( app ) )

    # script_path = Path(__file__).resolve()
    # rootPath = str(script_path.parent)
    # qRootPath = QDir(rootPath)
    
    # cssSheetPath = qRootPath.__copy__()
    # cssSheetPath.cd("css")
    
    # cssFilePath = cssSheetPath.filePath("appStyles.css")
    # with open(cssFilePath, "r", encoding="utf-8") as f:
    #     app.setStyleSheet(f.read())

    # appManagment = AppMenagment(qRootPath, APP_SETTINGS_NAME, APP_STATE_NAME)
    # appManagment.showWindow("MainAppWindow")
    # if not appManagment.isAnyWidowPresent():
    #     exit(0)
    #     # app.closeAllWindows()
    
    # appRet = app.exec()
    appRet = appRun()
    exit(appRet)