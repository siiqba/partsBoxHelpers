from PySide6.QtCore import Qt, QDir, QEvent, QSizeF, QAbstractTableModel, QModelIndex, QTimer, QItemSelection, QPersistentModelIndex
from PySide6.QtWidgets import (QPushButton, QWidget, QLineEdit, QGridLayout, QComboBox,
                               QHBoxLayout, QVBoxLayout, QLabel, QMessageBox,
                               QSizePolicy, QTableView, QTextEdit, QMainWindow, QListView,
                               QHeaderView, QFileDialog, QProgressBar, QAbstractItemView)
from PySide6.QtGui import QPixmap, QColor, QAction

from app.modules.appMenagment import AppMenagment
from app.modules.appSettings import AppSettings
from app.modules.windows.pidInventoryWindow import PidPartsInventory
from app.modules.partsBoxProvider import PidPart, PartsBoxStorage, PidPartStockItem
from app.modules.userMessages import UserMessage, UserMessageStatus, UserMessageEngin
# from app.modules.partsBoxProvider import PartsBoxProject, PartsBoxPart, PartsBoxWrapper, PidPart
# from app.modules.widgets.label import QCLabelWidget, QCScalledLabel2, QCBarcodeScannerWidget
# from app.modules.labels import PartLabel, LabelDescriptor, SVG_COLOR, SVG_FONTWEIGHT
# from app.modules.printer import PrinterDescriptor, LabelPrinter

from enum import Enum
from typing import Any, ClassVar, Final
import re

class UserMessages:
    OK :ClassVar[UserMessage] = UserMessage("Ok", UserMessageStatus.OK)
    START_GETTING_STORAGE_LIST :ClassVar[UserMessage] = UserMessage("Pobieranie listy magazynów", UserMessageStatus.WORNING)
    ERROR_GETTING_STORAGE_LIST :ClassVar[UserMessage] = UserMessage("Pobieranie listy magazynów", UserMessageStatus.ERROR)
    OK_GETTING_STORAGE_LIST :ClassVar[UserMessage] = UserMessage("Pobieranie listy magazynów", UserMessageStatus.OK)
    ERROR_FIND :ClassVar[UserMessage] = UserMessage("NIe znaleziono elementu", UserMessageStatus.WORNING)
    OK_FIND :ClassVar[UserMessage] = UserMessage("Znaleziono elelement", UserMessageStatus.OK)
    NO_PART_LOADED :ClassVar[UserMessage] = UserMessage("Nie ma elementów do dodania", UserMessageStatus.WORNING)
    NO_STORAGE_LOADED :ClassVar[UserMessage] = UserMessage("Brak dmyślnego magazynu", UserMessageStatus.ERROR)
    NO_INVENTORY_MESSAGE :ClassVar[UserMessage] = UserMessage("brak komentaża do inwentaryzacji", UserMessageStatus.ERROR)
    NO_PARTSBOX_PROVIDER :ClassVar[UserMessage] = UserMessage("Brak połączenia z PartsBox", UserMessageStatus.ERROR)
    NO_PARTS_TO_MODYFY :ClassVar[UserMessage] = UserMessage("Brak zinwentaryzowanych elementów", UserMessageStatus.WORNING)
    PARTSBOX_UPDATE_OK :ClassVar[UserMessage] = UserMessage("Dodanie do Partbox powiodło się", UserMessageStatus.OK)

class PidInventoryToPartsBoxWindow(QMainWindow):
    appMenagment:AppMenagment
    appSettings:AppSettings
    pidPartsInventory:PidPartsInventory|None
    currentPidPart:PidPart|None
    tableAutoSelection:bool
    currentActionLineEditPid:QAction|None
    partsBoxStoragesList:list[PartsBoxStorage]|None
    userMessage:UserMessageEngin
    
    def __init__(self, parent: QWidget | None, appMenagment:AppMenagment, pidPartsInventory:PidPartsInventory|None = None) -> None:
        super().__init__(parent)
        self.appMenagment = appMenagment
        self.appSettings = self.appMenagment.getAppSettings()
        self.pidPartsInventory = pidPartsInventory
        self.calculateAction(self.pidPartsInventory)
        self.prepareLayout()
        self.updateLayoutValues()
        self.updateToolTipValues()
        appIcon = self.appSettings.getIcon(AppSettings.ICON_NAME.APP_ICON)
        if not(appIcon is None):
            self.setWindowIcon(appIcon)
        self.appSettings.langSettingsChanged.connect(self.updateLayoutValues)
        self.appSettings.langSettingsChanged.connect(self.updateToolTipValues)
        self.buttonCancel.pressed.connect(self.buttonClosePressedEvent)
        self.buttonFind.pressed.connect(self.buttonFindPresedEvent)
        self.lineEditFindPid.textChanged.connect(self.lineEditFindPidChangedEvent)
        self.lineEditFindPid.returnPressed.connect(self.buttonFindPresedEvent)
        if self.pidPartsInventory is None:
            self.close()
        else:
            self.pidPartsInventory.setShowOperation(True)
            self.tableViewParts.setModel(self.pidPartsInventory)
        self.tableViewParts.selectionModel().selectionChanged.connect(self.tableViewPartsSelectionEvent)
        self.currentPidPart = None
        self.tableAutoSelection = False
        self.currentActionLineEditPid = None
        self.partsBoxStoragesList = None
        self.buttonAdd.clicked.connect(self.buttonAddClickedEvent)
        self.comboBoxDefaultStorage.currentIndexChanged.connect(self.defaultStorageComboBoxChanged)
        self.userMessage = UserMessageEngin(self.lineEditMessage, self.progressBarr, self)

        # pobranie listy magazynów
        self.userMessage.displayMessage(UserMessages.START_GETTING_STORAGE_LIST, 0, 0)
        partsBoxWrapper = self.appMenagment.getPartsBoxWrapper()
        partsBoxWrapper.getPartsBoxStorageDone.connect(self.storageListDoneEvent)
        partsBoxWrapper.startGetAllStorages()
        self.setUiActive(False)

    def calculateAction(self, data:PidPartsInventory|None)->None:
        if data is None: return
        for _part in data:
            part:PidPart = _part
            if part.wasCounted :
                part.operation = part.quantity - part.stockQuantity
    
    def setUiActive(self, isActive:bool = True)->None:
        self.lineEditPartsBoxComment.setEnabled(isActive)
        self.comboBoxDefaultStorage.setEnabled(isActive)
        self.buttonFind.setEnabled(isActive)
        self.lineEditFindPid.setEnabled(isActive)
        self.tableViewParts.setEnabled(isActive)
        self.buttonCancel.setEnabled(isActive)
        self.buttonAdd.setEnabled(isActive)

    def prepareLayout(self)->None:
        #################### ROW 1
        #---------------layoutH1 + containerH1
        # Edit Box Message
        self.lineEditMessage = QLineEdit("Message", self)
        self.lineEditMessage.setProperty('class', 'editLineMessage')
        self.lineEditMessage.setReadOnly(True)
        self.lineEditMessage.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        #Progress bar
        self.progressBarr = QProgressBar(self)
        self.progressBarr.setTextVisible(True)
        self.progressBarr.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.progressBarr.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        #layout H1 + container H1 !!!!!!!!!!!!
        containerH1 = QWidget(self)
        containerH1.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)
        containerH1.setProperty('class', 'widgetBorder')
        layoutH1 = QHBoxLayout(containerH1)
        layoutH1.addWidget(self.lineEditMessage, 2)
        layoutH1.addWidget(self.progressBarr, 1)

        #################### ROW 2
        #---------------layoutG2+contG2 zmiana z layout V2 + container V2
        # label PartsBox Comment
        self.labelPartsBoxComment = QLabel("Comment:", self)
        # message box PartsBox Comment
        self.lineEditPartsBoxComment = QLineEdit(self)
        # self.messageBoxPartsBoxComment.setMinimumHeight(100)
        # self.messageBoxPartsBoxComment.setMaximumHeight(200)
        self.lineEditPartsBoxComment.setText("")
        self.labelDefaultStorage = QLabel("Default\nstorage:", self)
        self.comboBoxDefaultStorage = QComboBox(self)

        containerG2 = QWidget(self)
        containerG2.setProperty('class', 'widgetBorder')
        layoutG2 = QGridLayout(containerG2)
        layoutG2.addWidget(self.labelPartsBoxComment, 0, 0)
        layoutG2.addWidget(self.lineEditPartsBoxComment, 0,1)
        layoutG2.addWidget(self.labelDefaultStorage, 1, 0)
        layoutG2.addWidget(self.comboBoxDefaultStorage, 1,1)

        #################### ROW 3
        #---------------layoutG1 + containerG1
        # label PID
        self.labelPid = QLabel("PID:", self)
        # Edit Box PID
        self.lineEditPid = QLineEdit("", self)
        self.lineEditPid.setReadOnly(True)
        self.lineEditPid.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.lineEditPid.setProperty('class', 'lineEditLargeFont')
        self.lineEditPid.setMaximumWidth(150)
        self.lineEditPid.setMinimumWidth(100)

        # Label PID Description
        self.labelPidDescription = QLabel("Description:", self)
        # Edit Box PID Description
        self.lineEditPidDescription = QLineEdit("", self)
        self.lineEditPidDescription.setReadOnly(True)
        self.lineEditPidDescription.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.lineEditPidDescription.setProperty('class', 'lineEditLargeFont')

        # Label Inventory Qantity
        self.labelInventoryQuantity = QLabel("Inventory:", self)
        # Edit Box Quantity
        self.lineEditInventoryQuantity = QLineEdit("", self)
        self.lineEditInventoryQuantity.setProperty('class', 'lineEditLargeFontQuantity')
        self.lineEditInventoryQuantity.setReadOnly(True)
        self.lineEditInventoryQuantity.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.lineEditInventoryQuantity.setMaximumWidth(120)
        self.lineEditInventoryQuantity.setMinimumWidth(50)

        # Label PartsBox Qantity
        self.labelPartsBoxQuantity = QLabel("PartsBox:", self)
        # Edit Box PartsBox Quantity
        self.lineEditPartsBoxQuantity = QLineEdit("", self)
        self.lineEditPartsBoxQuantity.setProperty('class', 'lineEditLargeFontQuantity')
        self.lineEditPartsBoxQuantity.setReadOnly(True)
        self.lineEditPartsBoxQuantity.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.lineEditPartsBoxQuantity.setMaximumWidth(120)
        self.lineEditPartsBoxQuantity.setMinimumWidth(50)

        # Label Operation Qantity
        self.labelOperationQuantity = QLabel("Operation:", self)
        # Edit Box PartsBox Quantity
        self.lineEditOperationQuantity = QLineEdit("", self)
        self.lineEditOperationQuantity.setProperty('class', 'lineEditLargeFontQuantity')
        self.lineEditOperationQuantity.setReadOnly(True)
        self.lineEditOperationQuantity.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.lineEditOperationQuantity.setMaximumWidth(120)
        self.lineEditOperationQuantity.setMinimumWidth(50)

        #layout G1 + container G1 !!!!!!!!!!!!!!
        containerG1 = QWidget(self)
        layoutG1 = QGridLayout(containerG1)
        layoutG1.addWidget(self.labelPid, 0, 0)
        layoutG1.addWidget(self.labelPidDescription, 0, 1)
        layoutG1.addWidget(self.labelInventoryQuantity, 0, 2)
        layoutG1.addWidget(self.labelPartsBoxQuantity, 0, 3)
        layoutG1.addWidget(self.labelOperationQuantity, 0, 4)

        layoutG1.addWidget(self.lineEditPid, 1, 0)
        layoutG1.addWidget(self.lineEditPidDescription, 1, 1)
        layoutG1.addWidget(self.lineEditInventoryQuantity, 1, 2)
        layoutG1.addWidget(self.lineEditPartsBoxQuantity, 1, 3)
        layoutG1.addWidget(self.lineEditOperationQuantity, 1, 4)
        # layoutH2.addWidget(self.lineEditPid, 0, Qt.AlignmentFlag.AlignLeft)
        # layoutH2.addWidget(self.lineEditPidDescription, 1)
        # layoutH2.addWidget(self.lineEditQuantity, 0, Qt.AlignmentFlag.AlignRight)

        #################### ROW 4
        #---------------layoutG1 + containerG1
        # line edit PID find
        self.lineEditFindPid = QLineEdit("", self)
        # button PID find
        self.buttonFind = QPushButton("Find", self)
        findIcon = self.appSettings.getIcon(AppSettings.ICON_NAME.FIND)
        if not(findIcon is None):
            self.buttonFind.setIcon(findIcon)
        spacer1 = QWidget(self)
        # spacer6.setProperty('class', 'widgetTest')#LAYOUT DEBUG
        containerH2 = QWidget(self)
        # containerH6.setProperty('class', 'widgetTest')#LAYOUT DEBUG
        layoutH2 = QHBoxLayout(containerH2)
        layoutH2.setContentsMargins(10, 10, 10, 0) #left top right bottom
        layoutH2.setSpacing(2)
        layoutH2.addWidget(self.lineEditFindPid, 0)
        layoutH2.addWidget(self.buttonFind, 0)
        layoutH2.addWidget(spacer1, 1)

        #################### ROW 5
        #---------------None
        # table view
        self.tableViewParts = QTableView(self)
        self.tableViewParts.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)#SelectRows
        self.tableViewParts.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tableViewParts.setSortingEnabled(True)

        #################### ROW 6
        #---------------layout H3 container H3
        # button Cancel
        self.buttonCancel = QPushButton("Cancel", self)
        #spacer 2
        spacer2 = QWidget(self)
        # button Add to parts box
        self.buttonAdd = QPushButton("Add\nto PartsBox", self)
        containerH3 = QWidget(self)
        containerH3.setProperty('class', 'widgetBorder')
        layoutH3 = QHBoxLayout(containerH3)
        layoutH3.addWidget(self.buttonCancel, 1, Qt.AlignmentFlag.AlignLeft)
        layoutH3.addWidget(spacer2, 4)
        layoutH3.addWidget(self.buttonAdd, 1, Qt.AlignmentFlag.AlignRight)

        #################### ROW 3 4 5
        #-----------------layout V3 container V3
        containerV3 = QWidget(self)
        containerV3.setProperty('class', 'widgetBorder')
        layoutV3 = QVBoxLayout(containerV3)
        layoutV3.addWidget(containerG1, 0,  Qt.AlignmentFlag.AlignTop)
        layoutV3.addWidget(containerH2, 0,  Qt.AlignmentFlag.AlignTop)
        layoutV3.addWidget(self.tableViewParts, 1)

        #-----------------layout V1 main container V1 main
        mainWidget = QWidget(self)
        layoutV1_main = QVBoxLayout(mainWidget)
        layoutV1_main.addWidget(containerH1, 0, Qt.AlignmentFlag.AlignTop)
        layoutV1_main.addWidget(containerG2, 0, Qt.AlignmentFlag.AlignTop)
        layoutV1_main.addWidget(containerV3, 1)
        layoutV1_main.addWidget(containerH3, 0, Qt.AlignmentFlag.AlignBottom)

        self.setCentralWidget(mainWidget)

    def updateLayoutValues(self)->None:
        self.setWindowTitle(self.appSettings.tr(self.appSettings.SETTINGS_TYPE.GLOBAL,\
                                                self.appSettings.SETTINGS_TYPE.APP_NAME))
        self.labelPartsBoxComment.setText(self.appSettings.tr(self, "labelPartsBoxComment"))
        self.labelPid.setText(self.appSettings.tr(self, "labelPid"))
        self.labelPidDescription.setText(self.appSettings.tr(self, "labelPidDescription"))
        self.labelInventoryQuantity.setText(self.appSettings.tr(self, "labelInventoryQuantity"))
        self.labelPartsBoxQuantity.setText(self.appSettings.tr(self, "labelPartsBoxQuantity"))
        self.labelOperationQuantity.setText(self.appSettings.tr(self, "labelOperationQuantity"))
        self.buttonFind.setText(self.appSettings.tr(self, "buttonFind"))
        self.buttonCancel.setText(self.appSettings.tr(self, "buttonCancel"))
        self.buttonAdd.setText(self.appSettings.tr(self, "buttonAdd"))

    def updateToolTipValues(self)->None:
        pass

    def buttonClosePressedEvent(self)->None:
        self.close()
    
    def closeEvent(self, event):
        self.pidPartsInventory.setShowOperation(False, True)
        self.appMenagment.onWindowClose(self)
        return super().closeEvent(event)
    
    def fillPartInfoField(self, part:PidPart|None)->None:
        # if self.pidPartsBoxContent is None: return
        # if (ind <= 0) or (ind >= len(self.pidPartsBoxContent)): return
        if not (self.currentActionLineEditPid is None):
            self.lineEditPid.removeAction(self.currentActionLineEditPid)
            self.currentActionLineEditPid = None
        if part is None:
            self.lineEditPid.setText("")
            # self.lineEditPid.setClearButtonEnabled(False)
            self.lineEditPidDescription.setText("")
            self.lineEditInventoryQuantity.setText("")
            self.lineEditPartsBoxQuantity.setText("")
            self.lineEditOperationQuantity.setText("")
            return
        self.lineEditPid.setText(part.name)
        if isinstance(part.operationExecuted, bool):
            if part.operationExecuted:
                icon = self.appSettings.getIcon(AppSettings.ICON_NAME.CHECK_GREEN)
            else:
                icon = self.appSettings.getIcon(AppSettings.ICON_NAME.CROSS_RED)
        else:
            icon = self.appSettings.getIcon(AppSettings.ICON_NAME.CAUTION_YE)
        if not (icon is None):
            self.currentActionLineEditPid = self.lineEditPid.addAction(icon, QLineEdit.ActionPosition.LeadingPosition)
        self.lineEditPidDescription.setText(part.description)
        self.lineEditInventoryQuantity.setText(str(part.quantity))
        self.lineEditPartsBoxQuantity.setText(str(part.stockQuantity))
        self.lineEditOperationQuantity.setText(str(part.operation))
        # self.lineEditQuantity.setFocus(Qt.FocusReason.OtherFocusReason)

    def setCurrentPidPart(self, part:PidPart|None)->None:
        self.currentPidPart = part
        self.fillPartInfoField(self.currentPidPart)

    def tableViewPartsSelectionEvent(self, selected :QItemSelection, deselected:QItemSelection):
        if self.tableAutoSelection:
            self.tableAutoSelection = False
            return
        if len(selected.indexes()) <= 0: return
        selRowIndex = selected.indexes()[0].row()
        self.pidPartsInventory.setSuspendException(True)
        part = self.pidPartsInventory[selRowIndex]
        self.setCurrentPidPart(part)

    def tablePartSelectItem(self, index:int):
        # self.tableAutoSelection = singleLock
        if index < 0:
            self.tableViewParts.clearSelection()
            return
        scrollIndex = index
        scrollIndexStart = self.tableViewParts.verticalScrollBar().sliderPosition()
        scrollIndexEnd = scrollIndexStart + self.tableViewParts.verticalScrollBar().pageStep()
        if not (index in range(scrollIndexStart, scrollIndexEnd)):
            tableViewMaxIndex = self.tableViewParts.verticalScrollBar().maximum()
            scrollIndex = scrollIndex - int(self.tableViewParts.verticalScrollBar().pageStep()/2)
            if scrollIndex < 0: scrollIndex = 0
            scrollIndex = min(tableViewMaxIndex, scrollIndex)
            self.tableViewParts.verticalScrollBar().setSliderPosition(scrollIndex)
        self.tableViewParts.selectRow(index)

    def lineEditFindPidChangedEvent(self, txt:str)->None:
        if len(txt) == 0: return
        txt = str.upper(txt)
        if txt[0] != "#":
            txt = "#" + txt
        mat = re.findall(r"#+[a-zA-Z]{0,3}[0-9]{0,7}[a-zA-Z]?", txt)
        if (isinstance(mat, list) and len (mat)>0):
            self.lineEditFindPid.setText(mat[0])
        else:
            self.lineEditFindPid.setText("")

    def buttonFindPresedEvent(self)->None:
        pidTxt = self.lineEditFindPid.text()
        partIndex = self.pidPartsInventory.getIndex(pidTxt)
        if partIndex < 0:
            self.setCurrentPidPart(None)
            self.userMessage.displayMessage(UserMessages.ERROR_FIND)
            # self.displayMessage(UserMessages.PID_FIND_ERR)
            return
        # self.displayMessage(UserMessages.PID_FIND_OK)
        self.tablePartSelectItem(partIndex)
        self.userMessage.displayMessage(UserMessages.OK_FIND)

    def buttonAddClickedEvent(self)->None:
        partsBoxWrapper = self.appMenagment.getPartsBoxWrapper()
        if partsBoxWrapper is None:
            self.userMessage.displayMessage(UserMessages.NO_PARTSBOX_PROVIDER)
            return
        # partsBoxWrapper.getPartsBoxStorageDone.connect(self.storageListDoneEvent)
        # partsBoxWrapper.startGetAllStorages()
        addList = self.calculatingPartsToAddToPartsBox()
        if (addList is None) or (len(addList) == 0) :
            # self.userMessage.displayMessage(UserMessages.NO_PARTS_TO_MODYFY)
            return
        comment = self.lineEditPartsBoxComment.text()
        partsBoxWrapper.modyfyStockUpdate.connect(self.partsBoxModyfiUpdateEvent)
        partsBoxWrapper.modyfyStockDone.connect(self.partsBoxModyfiDoneEvent)
        partsBoxWrapper.startModyfiStock(addList, comment)

    def partsBoxModyfiUpdateEvent(self, value:int, maxVal:int, sucess:bool, desc:str)->None:
        if sucess:
            self.userMessage.displayMessage(UserMessage(), value, maxVal, desc)
        else:
            self.userMessage.displayMessage(UserMessage(desc, UserMessageStatus.WORNING), value, maxVal, desc)

    def partsBoxModyfiDoneEvent(self, isSucess:bool, message:str)->None:
        partsBoxWrapper = self.appMenagment.getPartsBoxWrapper()
        partsBoxWrapper.modyfyStockUpdate.disconnect(self.partsBoxModyfiUpdateEvent)
        partsBoxWrapper.modyfyStockDone.disconnect(self.partsBoxModyfiDoneEvent)
        if isSucess:
            self.userMessage.displayMessage(UserMessages.PARTSBOX_UPDATE_OK, 0, 1)
        else:
             self.userMessage.displayMessage(UserMessage(message, UserMessageStatus.ERROR), 0, 1)

    def storageListDoneEvent(self, sucess:bool, message:str)->None:
        self.setUiActive(True)
        if sucess:
            self.userMessage.displayMessage(UserMessages.OK_GETTING_STORAGE_LIST, 0, 1)
        else:
            self.userMessage.displayMessage(UserMessages.ERROR_GETTING_STORAGE_LIST, 0, 1)
        partsBoxWrapper = self.appMenagment.getPartsBoxWrapper()
        partsBoxWrapper.getPartsBoxStorageDone.disconnect(self.storageListDoneEvent)
        temp = partsBoxWrapper.getStorgeListRet()
        if temp is None: return
        self.partsBoxStoragesList = temp
        self.fillComboBoxStorageList()

    def fillComboBoxStorageList(self, data:list[PartsBoxStorage]|None = None)->None:
        if not isinstance(data, list):
            if not isinstance(self.partsBoxStoragesList, list):
                return
            else:
                data = self.partsBoxStoragesList
        self.comboBoxDefaultStorage.clear()
        for item in data:
            self.comboBoxDefaultStorage.addItem(item.name)
    
    def defaultStorageComboBoxChanged(self, index:int)->None:
        if self.partsBoxStoragesList is None: return
        print (self.partsBoxStoragesList[index])

    def calculatingPartsToAddToPartsBox(self)->list[PidPart]|None:
        if self.pidPartsInventory is None:
            self.userMessage.displayMessage(UserMessages.NO_PART_LOADED)
            return None
        if self.partsBoxStoragesList is None:
            self.userMessage.displayMessage(UserMessages.NO_STORAGE_LOADED)
            return None
        textMessage = self.lineEditPartsBoxComment.text()
        if len(textMessage) < 5:
            self.userMessage.displayMessage(UserMessages.NO_INVENTORY_MESSAGE)
            return None
        partsToAdd = list()
        defaultStorageUuid = self.partsBoxStoragesList[self.comboBoxDefaultStorage.currentIndex()].uuid
        for _part in self.pidPartsInventory:
            part:PidPart = _part
            if part.wasCounted:
                if not isinstance(part.stockList, list):
                    part.stockList = [PidPartStockItem(defaultStorageUuid)]
                if part.operationExecuted is None:
                    partsToAdd.append(part)
                elif isinstance(part.operationExecuted, bool):
                    if not part.operationExecuted:
                        partsToAdd.append(part)
        self.userMessage.displayMessage(UserMessage())
        return partsToAdd