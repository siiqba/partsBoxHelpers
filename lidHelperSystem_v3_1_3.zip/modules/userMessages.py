from PySide6.QtCore import QObject, QTimer
from PySide6.QtWidgets import QWidget, QLineEdit, QProgressBar

from enum import Enum
from typing import Any, ClassVar, Final

# from PySide6.QtGui import QPixmap, QColor, QIcon

class UserMessageStatus:
    OK:ClassVar[str]="OK"
    ERROR:ClassVar[str]="ERROR"
    WORNING:ClassVar[str]="WORNING"
    IDLE:ClassVar[str]=""

class UserMessage:
    message:str|None
    status:str|None
    def __init__(self, message:str|None = None, status:str|None = None):
        self.message = message
        self.status = status
    
    def isValid(self)->bool:
        if (self.message is None) or (self.status is None): return False
        return True
    
    def getStatus(self)->str:
        return self.status
    
    def getMessage(self)->str:
        return self.message
    
    def __str__(self)->str:
        return self.message

class UserMessageEngin(QObject):
    USER_MESSAGE_TIMEOUT_MS:Final[int]=2000
    displayWidget:QLineEdit
    progressBar:QProgressBar
    timer:QTimer

    def __init__(self, displayWidget:QLineEdit, progressBar:QProgressBar, parent = None):
        super().__init__(parent)
        self.timer = QTimer(self, singleShot=True)
        self.timer.setInterval(self.USER_MESSAGE_TIMEOUT_MS)
        self.displayWidget = displayWidget
        self.progressBar = progressBar
        self.timer.timeout.connect(self.timerTimeout)

    def timerTimeout(self)->None:
        self.displayWidget.setProperty("subStyle", UserMessageStatus.IDLE)
        self.displayWidget.style().unpolish(self.displayWidget)
        self.displayWidget.style().polish(self.displayWidget)

    def displayMessage(self, message:UserMessage, value:int = -1, maxVal:int = -1, progressBarMessage:str = "")->None:
        if message.isValid():
            self.displayWidget.setText(message.getMessage())
            self.displayWidget.setProperty("subStyle", message.getStatus())
            self.displayWidget.style().unpolish(self.displayWidget)
            self.displayWidget.style().polish(self.displayWidget)
            if self.timer.isActive():
                self.timer.stop()
                self.timer.setInterval(self.USER_MESSAGE_TIMEOUT_MS)
            self.timer.start()
        else:
            self.displayWidget.setText("")
            self.displayWidget.setProperty("subStyle", UserMessageStatus.IDLE)
            self.displayWidget.style().unpolish(self.displayWidget)
            self.displayWidget.style().polish(self.displayWidget)
            if self.timer.isActive():
                self.timer.stop()
        if (value >= 0) and (maxVal >= 0):
            self.progressBar.setMinimum(0)
            self.progressBar.setMaximum(maxVal)
            self.progressBar.setValue(value)
            self.progressBar.setFormat(progressBarMessage)
        else:
            self.progressBar.resetFormat()
