from PySide6.QtCore import (QObject, QAbstractTableModel, QAbstractItemModel,
                            QModelIndex, Qt, Signal, QDate, QThreadPool, QRunnable, Slot, QThread)
from PySide6.QtGui import QPixmap, QImage
from queue import Queue
# from threading import Thread
from typing import Any, ClassVar, Final, Self
from enum import Enum
import requests
# import json
# import re
# import time
# import hashlib
# import secrets
import copy

import json

class PidPartStockItem:
    uuid:str
    quantity:int
    name:str
    timestamp:int

    @staticmethod
    def fromDictionary(dict:dict)->Self|None:
        uuid = dict.get('uuid', None)
        if uuid is None: return None
        quantity = dict.get('quantity', 0)
        name = dict.get('name', 'None')
        timestamp = dict.get('timestamp', 0)
        return PidPartStockItem(uuid, quantity, name, timestamp)
    
    def __init__(self, uuid:str, quantity:int = 0, name:str = "Null", timestamp:int = 0):
        self.uuid = uuid
        self.quantity = quantity
        self.name = name
        self.timestamp = timestamp

    def toDictionary(self)->dict:
        tObj:dict = dict()
        tObj['uuid'] = self.uuid
        tObj['quantity'] = self.quantity
        tObj['name'] = self.name
        tObj['timestamp'] = self.timestamp
        return tObj
    
    def __str__(self)->str:
        tObj:dict = self.toDictionary()
        jsonStr:str = json.dumps(tObj)
        return jsonStr
    
    def __deepcopy__(self, memo)->Self:
        return self.__copy__()
    
    def __copy__(self)->Self:
        newObj = PidPartStockItem(self.uuid, self.quantity, self.name, self.timestamp)
        return newObj

# class PidPartStocksHelper:
#     data: list[PidPartStockItem]

#     def __init__(self):
#         self.data = list()

#     def getStockCount(self)->int:
#         return len(self.data)
    
#     def setStockItem(self, stockItem:PidPartStockItem|dict)->bool:
#         tUuid:str|None = None
#         # tObj:PidPartStockItem|None = None
#         if isinstance(stockItem, dict):
#             tUuid = stockItem.get('stock/storage-id', None)
#             tQuantity = stockItem.get('stock/quantity', 0)
#             tTimestamp = stockItem.get('stock/timestamp', 0)
#             # tObj = PidPartStockItem(tUuid, tQuantity, "None", tTimestamp)
#         elif isinstance(stockItem, PidPartStockItem):
#             tUuid = stockItem.uuid
#             tQuantity = stockItem.quantity
#             # tObj = stockItem
#         else:
#             return False
#         if tUuid is None: return False

#         insertIndex:int = -1
#         for i in range(0, len(self.data)):
#             if self.data[i] == tUuid:
#                 insertIndex = i
#                 break
        
#         if insertIndex < 0:
#             self.data.append(PidPartStockItem(tUuid, tQuantity, "None", tTimestamp))
#             return True
#         self.data[insertIndex].quantity += tQuantity
#         return True         
    
#     def cleanStock(self)->None:
#         removeList:list[int] = list()
#         for i in range(0, len(self.data)):
#             if self.data[i].quantity <= 0: removeList.append(i)
#         for i in removeList:
#             self.data.pop(i)
#         keyLambda = lambda stock: stock.quantity
#         self.data.sort(key=keyLambda, reverse=True)

#     @staticmethod
#     def getStockListFromJson(stockItem:list[dict])->list[PidPartStockItem]:
#         pass

                

class PidPart(QObject):
    MAPING_LIST:ClassVar[list[str]] = ["uuid", "name", "mpn", "manufacturer", "description", "sds", \
                                       "footprint", "quantity", "stockQuantity", "wasCounted", "operation",\
                                        "operationExecuted", "stockList"]
    MAPING_JSON_SIMPLE:ClassVar[dict[str, str]] = {"part/name": "name", "part/mpn":"mpn", "part/manufacturer":"manufacturer",\
                                              "part/description": "description", "part/footprint": "footprint"}
    uuid:str|None
    name:str|None
    mpn:str|None
    manufacturer:str|None
    description:str|None
    sds:list[str]|None
    footprint:str|None
    quantity:int
    stockQuantity:int
    wasCounted:bool
    operation:int
    operationExecuted:bool|None
    stockList:list[PidPartStockItem]|None

    def __init__(self,  uuid:str|None = None, parent =None):
        super().__init__(parent)
        self.uuid = uuid
        self.name = None
        self.mpn = None
        self.manufacturer = None
        self.description = None
        self.sds = None
        self.footprint = None
        self.quantity = 0
        self.stockQuantity = 0
        self.wasCounted = False
        self.operation = 0
        self.operationExecuted = None
        self.stockList = None

    @staticmethod
    def getPartFullStock(stockList:list[dict])->int:
        stockSum:int = 0
        for stock in stockList:
            if not isinstance(stock, dict): continue
            tUuid = stock.get('stock/storage-id', None)
            if tUuid is None: continue
            tQuantity = stock.get('stock/quantity', 0)
            if not isinstance(tQuantity, int): continue
            stockSum += tQuantity
        return stockSum

    #getPartStockUuid
    @staticmethod
    def getPartStockUuidList(stockList:list[dict])->list[PidPartStockItem]|None:
        retData: list[PidPartStockItem] = list()
        # maxCountValue:int = 0
        # stockUuid:str|None = None
        for stockItem in stockList:
            if not isinstance(stockItem, dict): continue
            tUuid = stockItem.get('stock/storage-id', None)
            if tUuid is None: continue
            tQuantity = stockItem.get('stock/quantity', 0)
            tTimestamp = stockItem.get('stock/timestamp', 0)

            insertIndex:int = -1
            for i in range(0, len(retData)):
                if retData[i].uuid == tUuid:
                    insertIndex = i
                    break
            if insertIndex >= 0:
                retData[insertIndex].quantity += tQuantity
                continue
            retData.append(PidPartStockItem(tUuid, tQuantity, "None", tTimestamp))
        if len(retData) == 0: return None
        cleanList:list[int] = list()
        for i in range(0, len(retData)):
            if retData[i].quantity > 0: cleanList.append(retData[i])
        if len(cleanList) == 0: return None
        keyLambda = lambda stock: stock.quantity
        cleanList.sort(key=keyLambda, reverse=True)
        return cleanList

    @classmethod
    def fromPartJson(cls, data:dict|None)->Self|None:
        if data is None: return None
        tempItem = data.get("part/id", None)
        if not isinstance(tempItem, str): return None
        tObj:PidPart = cls(tempItem)
        for tag, name in PidPart.MAPING_JSON_SIMPLE.items():
            tempItem = data.get(tag, None)
            if tempItem is None: continue
            setattr(tObj, name, tempItem)
        tempData = data.get('part/custom-fields', None)
        if isinstance(tempData, list):
            tempItem:list[str] = list()
            for i in tempData:
                t = i.get('key', "")
                if t == 'SDS_1':
                    tempItem.append(i.get('value', "PB Null"))
                if t == 'SDS_2':
                    tempItem.append(i.get('value', "PB Null"))
            if len(tempItem) > 0:
                tObj.sds = tempItem
        tempData = data.get('part/stock', [])
        if len(tempData) > 0:
            tObj.stockQuantity = PidPart.getPartFullStock(tempData)
            tObj.stockList = PidPart.getPartStockUuidList(tempData)
        return tObj
    
    # mpn manufacturer description sds footprint quantity stockQuantity wasCounted
    @classmethod
    def fromFileJson(cls, data:dict|None)->Self|None:
        if not isinstance(data, dict): return None

        temp = data.get("uuid", None)
        if not isinstance(temp, str): return None
        tObj:PidPart = cls(temp)

        temp = data.get("name", None)
        if not isinstance(temp, str): return None
        tObj.name = temp

        temp = data.get("mpn", None)
        if not isinstance(temp, str): return None
        tObj.mpn = temp

        temp = data.get("manufacturer", None)
        if not isinstance(temp, str): return None
        tObj.manufacturer = temp

        temp = data.get("description", "None")
        if not isinstance(temp, str): return None
        tObj.description = temp

        """allow NULL for some of parts in partsBox"""
        temp = data.get("sds", None)
        # if not isinstance(temp, list): return None
        tObj.sds = temp

        temp = data.get("footprint", "None")
        # if not isinstance(temp, str): return None
        tObj.footprint = temp

        temp = data.get("quantity", None)
        if not isinstance(temp, int): return None
        tObj.quantity = temp

        temp = data.get("stockQuantity", None)
        if not isinstance(temp, int): return None
        tObj.stockQuantity = temp

        temp = data.get("wasCounted", None)
        if not isinstance(temp, bool): return None
        tObj.wasCounted = temp

        temp = data.get("operation", 0)
        # if not isinstance(temp, int): return None
        tObj.operation = temp

        temp = data.get("operationExecuted", None)
        # if not isinstance(temp, int): return None
        tObj.operationExecuted = temp

        temp = data.get("stockList", None)
        if isinstance(temp, list):
            tList = list()
            for item in temp:
                t = PidPartStockItem.fromDictionary(item)
                if t is not None: tList.append(t)
            temp = tList
        tObj.stockList = temp

        return tObj
    
    def __deepcopy__(self, memo)->Self:
        return self.__copy__()
    
    def __copy__(self)->Self:
        copyObj = PidPart(self.uuid)
        copyObj.name = self.name
        copyObj.mpn = self.mpn
        copyObj.manufacturer = self.manufacturer
        copyObj.description = self.description
        copyObj.sds = copy.deepcopy(self.sds)
        copyObj.footprint = self.footprint
        copyObj.quantity = self.quantity
        copyObj.stockQuantity = self.stockQuantity
        copyObj.wasCounted = self.wasCounted
        copyObj.operation = self.operation
        copyObj.operationExecuted = self.operationExecuted
        copyObj.stockList = copy.deepcopy(self.stockList)
        return copyObj
    
    def copy(self)->Self:
        return self.__copy__()
    
    def toFileJson(self)->str|None:
        tempDict = dict()
        tempDict["uuid"] = self.uuid
        tempDict["name"] = self.name
        tempDict["mpn"] = self.mpn
        tempDict["manufacturer"] = self.manufacturer
        tempDict["description"] = self.description
        tempDict["sds"] = self.sds
        tempDict["footprint"] = self.footprint
        tempDict["quantity"] = self.quantity
        tempDict["stockQuantity"] = self.stockQuantity
        tempDict["wasCounted"] = self.wasCounted
        tempDict["operation"] = self.operation
        tempDict["operationExecuted"] = self.operationExecuted
        stockListTemp:list[dict] = list()
        if self.stockList is None:
            tempDict["stockList"] = self.stockList
        else:
            for item in self.stockList:
                stockListTemp.append(item.toDictionary())
            tempDict["stockList"] = stockListTemp
        
        txt = None
        try:
            txt = json.dumps(tempDict, indent=0)
        except:
            txt = None
        return txt
    
    def __str__(self):
        txt =  f"{self.uuid}, {self.name}, {self.mpn}, {self.manufacturer}, {self.description}"
        if isinstance(self.sds, list):
            for i in self.sds:
                txt += f", {i}"
        txt += f", {self.footprint}, {self.stockQuantity}, {self.quantity}"
        return txt

    def __repr__(self):
        return self.__str__()     

    def __getitem__(self, key)->Any|None:
        if isinstance(key, str):
            return getattr(self, key, None)
        if isinstance(key, int):
            if key < len(self.MAPING_LIST):
                return getattr(self, self.MAPING_LIST[key], None) 
            else:
                return None
    
class PartsBoxStorage(object):
    uuid:str
    name:str|None
    def __init__(self, uuid:str, name:str|None = None):
        self.uuid = uuid
        self.name = name

    def __copy__(self)->Self:
        copyObj = PartsBoxStorage(self.uuid)
        copyObj.name = self.name
        return copyObj
    
    def __deepcopy__(self, memo)->Self:
        return self.__copy__()

    def __str__(self)->str:
        return f"uuid: {self.uuid}; name: {self.name}"

# 'entry/id' 'entry/quantity' 'entry/part-id' 'entry/designators': ['IC1'] 'entry/name': 'I0056'
class PartsBoxPart(QObject):
    uuid:str|None #OK
    partsCount:int #OK
    designators:list[str]|None #OK
    pidParts:list[str]|list[Any]|None #OK
    isLid:bool #OK
    isPid:bool #OK
    description:str
    footprint:str
    name:str
    sds1:str|None
    sds2:str|None
    mpn:str|None
    manufacturer:str|None
    
    @classmethod
    def fromProjectJson(cls, project:dict|None)->Any|None:
        if project is None: return None
        partId = project.get('entry/part-id', None)
        if partId is None: return None
        designators = project.get('entry/designators', None)
        partsCount = project.get('entry/quantity', 0)
        newObj = cls(partId)
        newObj.partsCount = partsCount
        if isinstance(designators, list):
            newObj.designators = copy.deepcopy(designators)
        return newObj

    def __init__(self, entryUUID:str|None = None):
        self.partsCount = 0
        self.isLid = False
        self.isPid = False
        self.description = ""
        self.footprint = ""
        self.name = ""
        self.uuid = entryUUID
        self.pidParts = None
        self.designatore = None
        self.sds1 = None
        self.sds2 = None
       
    def updateParamFromPartJson(self, json:dict|None)->bool:
        if not isinstance(json, dict): return False
        temp = json.get('part/tags', None)
        if isinstance(temp, list):
            self.isLid = False
            self.isPid = False
            if set(temp).issuperset(["LID"]): self.isLid = True
            if set(temp).issuperset(["PID"]): self.isPid = True
        temp = json.get('part/part-ids', None)
        if isinstance(temp, list):
            self.pidParts = copy.deepcopy(temp)
        self.description = str(json.get('part/description', ""))
        self.footprint = str(json.get('part/footprint', ""))
        self.name = str(json.get('part/name', ""))
        temp = json.get('part/custom-fields', None)
        if isinstance(temp, list):
            for cfield in temp:
                if isinstance(cfield, dict):
                    fk = cfield.get("key", None)
                    if not fk is None:
                        if (fk == "SDS_1"): self.sds1 = cfield.get("value", "")
                        if (fk == "SDS_2"): self.sds2 = cfield.get("value", "")
        self.mpn = json.get('part/mpn', None)
        self.manufacturer = json.get('part/manufacturer', None)
        return True

class PartsBoxProject(QObject):
    bom:list[PartsBoxPart]|None
    notes:str
    name:str
    description:str
    custom_fields:list[dict]|None
    uuid:str
    image:str|None

    def __init__(self, uuid:str):
        super().__init__(None)
        self.bom = None
        self.image = None
        self.notes = ""
        self.name = ""
        self.description = ""
        self.custom_fields = None
        self.uuid = uuid

    @classmethod
    def fromProjectJson(cls, json:dict|None)->Any:
        if not isinstance(json, dict): return None
        uuid = json.get('project/id', None)
        if uuid is None: return None
        return cls(uuid)

    def updateProjectParams(self, json:dict|None)->bool:
        if not isinstance(json, dict): return False
        self.notes = json.get('project/notes', "")
        self.name = json.get('project/name', "")
        self.description = json.get('project/description', "")
        self.custom_fields = copy.deepcopy(json.get('project/custom-fields', []))
        self.image = json.get('project/img-id', None)
        return True
    
    def __deepcopy__(self, memo)->Any:
        newObj = PartsBoxProject(self.uuid)
        newObj.notes = self.notes
        newObj.name = self.name
        newObj.description = self.description
        newObj.image = self.image
        if not self.custom_fields is None:
            newObj.custom_fields = copy.deepcopy(self.custom_fields)
        if not self.bom is None:
            newObj.bom = copy.deepcopy(self.bom)
        return newObj

    def addProjectBomItem(self, part:PartsBoxPart|None)->bool:
        if not isinstance(part, PartsBoxPart): return False
        if self.bom is None:
            self.bom = list()
        self.bom.append(part)
        return True
    
    def cleareBom(self)->None:
        if self.bom is None: return
        self.bom.clear()
        self.bom = None

class PartsBoxStockWorker(QRunnable, QObject):
    eventUpdate:ClassVar[Signal] = Signal(int, int, bool, str)
    eventFinal:ClassVar[Signal] = Signal(bool, str)

    pidPartsList:list[PidPart]
    host:str
    reqHeader:str
    comments:str

    def __init__(self, host:str, reqHeader:str, parts:list[PidPart], comments:str, parent = None):
        QRunnable.__init__(self)
        QObject.__init__(self, parent)
        self.pidPartsList = parts
        self.host = host
        self.reqHeader = reqHeader
        self.comments = comments
    
    def addToStock(self, part:PidPart)->bool:
        reqUrl = f'https://{self.host}/stock/add'
        reqHeader = self.reqHeader
        dbody = dict()
        dbody['stock/part-id']=part.uuid
        dbody['stock/storage-id']=part.stockList[0].uuid
        dbody['stock/quantity']=part.operation
        dbody['stock/comments']=self.comments
        body = json.dumps(dbody, indent=0)
        try:
            req = requests.post(reqUrl, headers=reqHeader, data=body, timeout=10)
        except:
            part.operationExecuted = False
            return False
        if req.status_code != 200:
            req.close()
            part.operationExecuted = False
            return False
        req.close()
        jSet = req.json()
        del req
        jSet = jSet.get("partsbox.status/category", None)
        if jSet is None:
            part.operationExecuted = False
            return False
        # QThread.sleep(5)
        part.operationExecuted = True
        # part.stockQuantity += part.operation
        part.stockList[0].quantity += part.operation
        return True
    
    def removeFromStock(self, part:PidPart)->bool:
        reqUrl = f'https://{self.host}/stock/remove'
        # reqUrl = f'https://{self.host}/storage/all'
        reqHeader = self.reqHeader
        dbodyList:list[dict] = list()
        # removeQuantityList:list[int] = list()
        partsToRemove:int = abs(part.operation)
        for stock in part.stockList:
            temp = min(stock.quantity, partsToRemove)
            partsToRemove -= temp
            _dbody = dict()
            _dbody['stock/source'] = dict()
            _dbody['stock/source']['source/part-id']=part.uuid
            _dbody['stock/source']['source/storage-id']=stock.uuid
            _dbody['stock/quantity']=temp
            _dbody['stock/comments']=self.comments
            dbodyList.append(_dbody)
            if partsToRemove <= 0: break
        
        if partsToRemove > 0:
            part.operationExecuted = False
            return False

        for dbody in dbodyList:
            body = json.dumps(dbody, indent=0)
            try:
                req = requests.post(reqUrl, headers=reqHeader, data=body, timeout=10)
            except:
                req.close()
                part.operationExecuted = False
                return False
            if req.status_code != 200:
                req.close()
                part.operationExecuted = False
                return False
            req.close()
            jSet = req.json()
            del req
            jSet = jSet.get("partsbox.status/category", None)
            if jSet is None:
                part.operationExecuted = False
                return False
        # QThread.sleep(5)
        part.operationExecuted = True
        return True
    
    @Slot()
    def run(self)->None:
        errorCounter:int = 0
        partsToModyfyCount:int = len(self.pidPartsList)
        partsToModyfiedCouner:int = 0
        self.eventUpdate.emit(partsToModyfiedCouner, partsToModyfyCount, True, "Start modifing Parts in PartsBox")
        for part in self.pidPartsList:
            if part.name == "#MC0017":
                pass
            partsToModyfiedCouner += 1
            if part.operation > 0:
                if self.addToStock(part):
                    self.eventUpdate.emit(partsToModyfiedCouner, partsToModyfyCount, True, f"Adding: {part.name} OK")
                else:
                    errorCounter += 1
                    self.eventUpdate.emit(partsToModyfiedCouner, partsToModyfyCount, False, f"Adding: {part.name} ERR")
            elif part.operation == 0:
                part.operation = 1
                top1 = self.addToStock(part)
                top2 = self.removeFromStock(part)
                part.operation = 0
                if top1 and top2:
                    self.eventUpdate.emit(partsToModyfiedCouner, partsToModyfyCount, True, f"Modyfing: {part.name} OK")
                else:
                    errorCounter += 1
                    self.eventUpdate.emit(partsToModyfiedCouner, partsToModyfyCount, False, f"Modyfing: {part.name} ERR")
            else:
                if self.removeFromStock(part):
                    self.eventUpdate.emit(partsToModyfiedCouner, partsToModyfyCount, True, f"Removing: {part.name} OK")
                else:
                    errorCounter += 1
                    self.eventUpdate.emit(partsToModyfiedCouner, partsToModyfyCount, False, f"Removing: {part.name} ERR")
            
        if errorCounter == 0:
            self.eventFinal.emit(True, "OK - all parts add to PartsBox")
        else:
            self.eventFinal.emit(False, f"ERR - {errorCounter} parts not added to PartsBox")


class PartsBoxGetAllPidParts(QRunnable, QObject):
    # eventUpdate:ClassVar[Signal] = Signal(int, int, bool, str)
    eventFinal:ClassVar[Signal] = Signal(bool, str)

    host:str
    reqHeader:str
    retObj:list[PidPart]|None
    
    def __init__(self, host:str, reqHeader:str, parent = None):
        QRunnable.__init__(self)
        QObject.__init__(self, parent)

        self.host = host
        self.reqHeader = reqHeader
        self.retObj = None

    def pidFilter(self, data:list)->bool:
        self.retObj = list()
        for part in data:
            if not isinstance(part, dict): continue
            tags = part.get("part/tags", None)
            if tags is None: continue
            if not set(tags).issuperset(("PID",)): continue
            partObj = PidPart.fromPartJson(part)
            if partObj is None: continue
            self.retObj.append(partObj)
        if len(self.retObj) == 0: return False
        return True

    def getAllParts(self)->bool:
        reqUrl = f'https://{self.host}/part/all'
        reqHeader = self.reqHeader
        body = """{ }"""
        try:
            req = requests.post(reqUrl, headers=reqHeader, data=body, timeout=10)
        except:
            return False
        if req.status_code != 200:
            req.close()
            return False
        req.close()
        jSet = req.json()
        del req
        jSet = jSet.get("data", None)
        if jSet is None: return False
        return self.pidFilter(jSet)

    def getPartsRet(self)->list[PidPart]|None:
        return self.retObj
    
    @Slot()
    def run(self)->None:
        # self.eventUpdate.emit(-1, -1, True, "Collect PIDs data")
        if self.getAllParts():
            self.eventFinal.emit(True, "Data collected")
        else:
            self.eventFinal.emit(False, "Error")
               
class PartsBoxGetStorageWorker(QRunnable, QObject):
    # getStorageUpdate:ClassVar[Signal] = Signal(int, int, bool, str)
    getStorageFinaly:ClassVar[Signal] = Signal(bool, str)
    host:str
    reqHeader:str
    retValue:list[PartsBoxStorage]|None

    def __init__(self, host:str, reqHeader:str, parent = None):
        QRunnable.__init__(self)
        QObject.__init__(self, parent)
        self.host = host
        self.reqHeader = reqHeader
        self.retValue = None

    def getAllStorages(self)->bool:
        reqUrl = f'https://{self.host}/storage/all'
        reqHeader = self.reqHeader
        body = """{ }"""
        try:
            req = requests.post(reqUrl, headers=reqHeader, data=body, timeout=10)
        except:
            return False
        if req.status_code != 200:
            req.close()
            return False
        req.close()
        jSet = req.json()
        del req
        jSet = jSet.get("data", None)
        if not isinstance(jSet, list): return False
        self.retValue = list()
        for item in jSet:
            temp = item.get('storage/id', None)
            if temp is None: continue
            tObj = PartsBoxStorage(temp)
            temp = item.get('storage/name', None)
            if temp is None: continue
            tObj.name = temp
            self.retValue.append(tObj)
        return True

    @Slot()
    def run(self)->None:
        if self.getAllStorages():
            self.getStorageFinaly.emit(True, "Starages list download")
        else:
            self.getStorageFinaly.emit(False, "Error in storage list dowloading")

class PartsBoxGetBomWorker(QRunnable, QObject):
    # getBomStart:ClassVar[Signal] = Signal(int, bool, str)
    # signal(value, maxValue, Ok/Error, "description")
    getBomUpdate:ClassVar[Signal] = Signal(int, int, bool, str)
    getBomFinaly:ClassVar[Signal] = Signal(bool, str)
    host:str
    reqHeader:str
    retObj:list[PartsBoxProject]|None
    project:PartsBoxProject

    def __init__(self, host:str, reqHeader:str, project:PartsBoxProject, parent = None):
        QRunnable.__init__(self)
        QObject.__init__(self, parent)

        self.host = host
        self.reqHeader = reqHeader
        self.project = project
    
    def getPartDetails(self, part:PartsBoxPart)->bool:
        # self.getBomUpdate.emit(0, 1, True, "Collecting BOM Items")
        reqUrl = f'https://{self.host}/part/get'
        reqHeader = self.reqHeader
        body = """{"part/id":"""+"\""
        body += part.uuid
        body += """"}"""
        try:
            req = requests.post(reqUrl, headers=reqHeader, data=body, timeout=10)
        except:
            # req.close()
            # self.getBomFinaly.emit(False, "Request Error")
            return False
        if req.status_code != 200:
            req.close()
            # self.getBomFinaly.emit(False, "Request Error")
            return False
        req.close()
        jSet = req.json()
        jSet = jSet.get("data", None)
        if jSet is None: return False
        return part.updateParamFromPartJson(jSet)
        # return True

    def countChildPartsInProject(self, project:PartsBoxProject)->int:
        ret:int = 0
        if not isinstance(project.bom, list): return 0
        for part in project.bom:
            if not isinstance(part, PartsBoxPart): continue
            _part:PartsBoxPart = part
            if not isinstance(_part.pidParts, list): continue
            for pUUID in _part.pidParts:
                if not isinstance(pUUID, str): continue
                ret += 1
        return ret

    def getProjectBom(self)->bool:
        # self.getBomUpdate.emit(0, 1, True, "Collecting BOM Items")
        reqUrl = f'https://{self.host}/project/get-entries'
        reqHeader = self.reqHeader
        body = """{"project/id":"""+"\""
        body += self.project.uuid
        body += """"}"""
        try:
            req = requests.post(reqUrl, headers=reqHeader, data=body, timeout=10)
        except:
            # req.close()
            # self.getBomFinaly.emit(False, "Request Error")
            return False
        if req.status_code != 200:
            req.close()
            # self.getBomFinaly.emit(False, "Request Error")
            return False
        req.close()
        jSet = req.json()
        jSet = jSet.get("data", None)
        if jSet is None: return False
        # partList = list()
        for item in jSet:
            i = PartsBoxPart.fromProjectJson(item)
            # i = PartsBoxPart(item, isLid=True)
            if i is not None: self.project.addProjectBomItem(i)
        # self.getBomUpdate.emit(1, 1, True, "Collecting BOM Items")
        return True

    @Slot()
    def run(self)->None:
        ret:bool = True
        self.getBomUpdate.emit(0, 1, True, "Collecting BOM Items")
        if not self.getProjectBom():
            self.getBomFinaly.emit(False, "Error in Project BOM collection")
            return
        self.getBomUpdate.emit(1, len(self.project.bom)+1, True, "Collecting BOM Items")
        
        for i in range(0, len(self.project.bom), 1):
            self.getBomUpdate.emit(i+2, len(self.project.bom)+1, True, "Collecting BOM Main Item (LID): {}".format(self.project.bom[i].uuid))
            if not self.getPartDetails(self.project.bom[i]):
                # self.getBomFinaly.emit(False, "Error in part detail collection")
                self.getBomUpdate.emit(i+2, len(self.project.bom)+1, False, "Error in item: {}".format(self.project.bom[i].uuid))
                ret = False
                continue
            
        
        childPartsToCollect = self.countChildPartsInProject(self.project)
        currentChildPartInd = 1
        self.getBomUpdate.emit(0, childPartsToCollect, True, "Collecting BOM Sub Items")

        for part in self.project.bom:
            if not isinstance(part, PartsBoxPart): continue
            # childPartsList = part.pidParts
            if not isinstance(part.pidParts, list): continue
            for i in range(0, len(part.pidParts), 1):
                if not isinstance(part.pidParts[i], str): continue
                self.getBomUpdate.emit(currentChildPartInd, childPartsToCollect, True, "Collecting BOM Sub Item (PID): {}".format(part.pidParts[i]))
                part.pidParts[i] = PartsBoxPart(part.pidParts[i])
                if not self.getPartDetails(part.pidParts[i]):
                    self.getBomUpdate.emit(currentChildPartInd, childPartsToCollect, False, "Error in item: {}".format(part.pidParts[i].uuid))
                currentChildPartInd += 1

        if(ret):
            self.getBomFinaly.emit(True, "Ok")
        else:
            self.getBomFinaly.emit(False, "Error in Project BOM collection")

class PartsBoxGetProjectsWorker(QRunnable, QObject):
    getProjectUpdate:ClassVar[Signal] = Signal(int, bool, str)
    getProjectFinaly:ClassVar[Signal] = Signal(bool, str)
    host:str
    reqHeader:str
    retObj:list[PartsBoxProject]|None

    def __init__(self, host:str, reqHeader:str, parent = None):
        # super(PartsBoxWrapperAddPidStockWorker, self).__init__(parent)
        QRunnable.__init__(self)
        QObject.__init__(self, parent)
        self.host = host
        self.retObj = None
        self.reqHeader = reqHeader

    def projectFilter(self, tags:list[str], jSet:dict)->list[PartsBoxProject]|None:
        projectsData:list[PartsBoxProject] = list()
        tempList:list|None = None
        for key, item in jSet.items():
            if key == "data":
                tempList = item
                break
        if tempList is None: return None
        for item in tempList:
            i = item.get("project/tags", None)
            if i is None: continue
            if not set(i).issuperset(tags): continue
            # uuid = item.get('project/id', None)
            # if uuid is None: continue
            if isinstance(i, list):
                projObj:PartsBoxProject|None = PartsBoxProject.fromProjectJson(item)
                if not isinstance(projObj, PartsBoxProject):continue
                projObj.updateProjectParams(item)
                projectsData.append(projObj)
        return projectsData

    def getProjectImage(self, proj:PartsBoxProject)->bool:
        if not isinstance(proj.image, str): return False
        reqUrl = f'https://{self.host}/files/download'
        reqHeader = self.reqHeader
        body = """{"file/id":"""+"\""
        body += proj.image
        body += """"}"""
        try:
            req = requests.post(reqUrl, headers=reqHeader, data=body, timeout=10)
        except:
            # req.close()
            # self.getBomFinaly.emit(False, "Request Error")
            return False
        if req.status_code != 200:
            req.close()
            # self.getBomFinaly.emit(False, "Request Error")
            return False
        req.close()
        # imgContrent = req.content
        try:
            temp = QImage()
            temp.loadFromData(req.content)
            proj.image = QPixmap(temp)
            # temp = QPixmap(req.content)
            # proj.image = temp
        except:
            return False
        return True
    
    @Slot()
    def run(self)->None:
        reqUrl = f'https://{self.host}/project/all'
        reqHeader = self.reqHeader
        body = """{ }"""

        try:
            req = requests.post(reqUrl, headers=reqHeader, data=body, timeout=10)
        except:
            # req.close()
            self.getProjectFinaly.emit(False, "Request Error")
            return
        if req.status_code != 200:
            req.close()
            self.getProjectFinaly.emit(False, "Request Error")
            return
        req.close()
        jSet = req.json()
        self.retObj = self.projectFilter(["PCBA"], jSet)

        for proj in self.retObj:
            self.getProjectImage(proj)
        # self.getProjectLidBom(ret[0])
        self.getProjectFinaly.emit(True, "Ok")

class PartsBoxWrapper(QObject):
    host:str
    reqHeader:str
    workerThreadPool:QThreadPool
    lastRet:list[PartsBoxProject]|None
    pidPartsRet:list[PidPart]|None
    storageListRet:list[PartsBoxStorage]|None
    partsBoxWorkerObj:Any|PartsBoxGetProjectsWorker
    partsBoxGetBomWorker:PartsBoxGetBomWorker
    partsBoxGetAllPidParts:PartsBoxGetAllPidParts
    partsBoxGetStorage:PartsBoxGetStorageWorker
    partsBoxStockWorker:PartsBoxStockWorker

    getProjectsDone:ClassVar[Signal] = Signal(bool, str)

    getProjectBomUpdate:ClassVar[Signal] = Signal(int, int, bool, str)
    getProjectBomDone:ClassVar[Signal] = Signal(bool, str)

    # getAllPidPartsUpdate:ClassVar[Signal] = Signal(int, int, bool, str)
    getAllPidPartsDone:ClassVar[Signal] = Signal(bool, str)

    getPartsBoxStorageDone:ClassVar[Signal] = Signal(bool, str)

    modyfyStockUpdate:ClassVar[Signal] = Signal(int, int, bool, str)
    modyfyStockDone:ClassVar[Signal] = Signal(bool, str)

    def __init__(self, host:str, apiKey:str,):
        super().__init__(None)
        self.host = host
        self.retObj = None
        self.pidPartsRet = None
        self.reqHeader = {
            'Content-Type': 'application/json',
            'Authorization': f'APIKey {apiKey}'}
        self.workerThreadPool = QThreadPool()
        self.lastRet = None
        self.storageListRet = None

    @Slot(bool, str)
    def slot_getProjectFinaly(self, isSucess:bool, message:str)->None:
        self.lastRet = copy.deepcopy(self.partsBoxWorkerObj.retObj)
        # self.partsBoxWorkerObj.getProjectFinaly.disconnect(self.slot_getProjectFinaly)
        self.getProjectsDone.emit(isSucess, message)
        del self.lastRet

    @Slot(int, int, bool, str)
    def slot_getProjectBomUpdate(self, value:int, max:int, sucess:bool, desc:str)->None:
        self.getProjectBomUpdate.emit(value, max, sucess, desc)
    
    @Slot(bool, str)
    def slot_getProjectBomFinally(self, isSucess:bool, message:str)->None:
        # self.partsBoxGetBomWorker.getBomUpdate.disconnect(self.slot_getProjectBomUpdate)
        # self.partsBoxGetBomWorker.getBomFinaly.disconnect(self.slot_getProjectBomFinally)
        self.getProjectBomDone.emit(isSucess, message)

    @Slot(bool, str)
    def slot_getAllPidPartsDone(self, isSucess:bool, message:str)->None:
        self.pidPartsRet = copy.deepcopy(self.partsBoxGetAllPidParts.getPartsRet())
        # self.partsBoxGetAllPidParts.eventFinal.disconnect(self.slot_getAllPidPartsDone)
        self.getAllPidPartsDone.emit(isSucess, message)

    @Slot(bool, str)
    def slot_getAllStorageDone(self, isSucess:bool, message:str)->None:
        self.storageListRet = copy.deepcopy(self.partsBoxGetStorage.retValue)
        self.getPartsBoxStorageDone.emit(isSucess, message)
        # self.partsBoxGetStorage.deleteLater()

    @Slot(int, int, bool, str)
    def slot_modyfyStockUpdate(self, value:int, maxVal:int, sucess:bool, desc:str)->None:
        self.modyfyStockUpdate.emit(value, maxVal, sucess, desc)

    @Slot(bool, str)
    def slot_modyfyStockDone(self, isSucess:bool, message:str)->None:
        self.modyfyStockDone.emit(isSucess, message)
    
    def startGetProjectList(self)->None:
        self.partsBoxWorkerObj = PartsBoxGetProjectsWorker(self.host, self.reqHeader)
        self.partsBoxWorkerObj.getProjectFinaly.connect(self.slot_getProjectFinaly)
        self.workerThreadPool.start(self.partsBoxWorkerObj)
    
    def startGetProjectBom(self, project:PartsBoxProject)->None:
        self.partsBoxGetBomWorker = PartsBoxGetBomWorker(self.host, self.reqHeader, project)
        self.partsBoxGetBomWorker.getBomUpdate.connect(self.slot_getProjectBomUpdate)
        self.partsBoxGetBomWorker.getBomFinaly.connect(self.slot_getProjectBomFinally)
        self.workerThreadPool.start(self.partsBoxGetBomWorker)
    
    def startGetAllPidParts(self)->None:
        self.partsBoxGetAllPidParts = PartsBoxGetAllPidParts(self.host, self.reqHeader)
        self.partsBoxGetAllPidParts.eventFinal.connect(self.slot_getAllPidPartsDone)
        self.workerThreadPool.start(self.partsBoxGetAllPidParts)

    def startGetAllStorages(self)->None:
        self.partsBoxGetStorage = PartsBoxGetStorageWorker(self.host, self.reqHeader)
        self.partsBoxGetStorage.getStorageFinaly.connect(self.slot_getAllStorageDone)
        self.workerThreadPool.start(self.partsBoxGetStorage)

    def startModyfiStock(self, data:list[PidPart], comment:str)->None:
        self.partsBoxStockWorker = PartsBoxStockWorker(self.host, self.reqHeader, data, comment)
        self.partsBoxStockWorker.eventUpdate.connect(self.slot_modyfyStockUpdate)
        self.partsBoxStockWorker.eventFinal.connect(self.slot_modyfyStockDone)
        self.workerThreadPool.start(self.partsBoxStockWorker)

    def getLastRet(self)->list[PartsBoxProject]|None:
        return self.lastRet
    
    def getPidPartsRet(self)->list[PidPart]|None:
        return self.pidPartsRet

    def getStorgeListRet(self)->list[PartsBoxStorage]|None:
        return self.storageListRet

if __name__ == "__main__":
    pass
    # partsBox = PartsBoxWrapperGetProjectsWorker("api.partsbox.com/api/1",\
    #                                             "partsboxapi_51bn1x55t2hh2b508syx04fdvj7c25e8a1798cd7643fa3ccdc4702743be571eb")
    # partsBox.run()