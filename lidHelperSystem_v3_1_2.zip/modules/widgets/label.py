from PySide6 import QtCore, QtGui, QtWidgets
from PySide6.QtWidgets import (QLabel, QWidget, QVBoxLayout, QHBoxLayout, QRadioButton, QFrame, QSizePolicy,
                               QLineEdit, QComboBox, QDialog, QDialogButtonBox, QCalendarWidget, QDateTimeEdit, QPushButton)
from PySide6.QtGui import QColor, QImage, QPainter, QIcon, QPixmap, QPageSize, QPageLayout, QKeyEvent, QPainter, QFontMetrics, QPaintEvent
from PySide6.QtCore import QXmlStreamReader, QSize, QSizeF, QMarginsF, Qt, Signal, QRect, QDate
from PySide6.QtSvg import QSvgRenderer
from PySide6.QtPrintSupport import QPrinter , QPrinterInfo, QPrintDialog, QPageSetupDialog

from typing import Any, Final, ClassVar

class QCScalledLabel(QLabel):

    printer:QPrinter
    # doubleClickEvent:Signal

    def __init__(self, parent = None):
        QLabel.__init__(self)
        self.setText("")
        self._svg = None
        self.status = True
        # self.hintSize = QSize(width, height)
        self.printer = None
        # self.doubleClickEvent = Signal(None)
        self.setSizePolicy(
            QtWidgets.QSizePolicy.Policy.MinimumExpanding,
            QtWidgets.QSizePolicy.Policy.MinimumExpanding
        )
        # self.setScaledContents(True)
        self._parent = parent
     
    def sizeHint(self):
        return QSize(400, 300)
    
    def setSvg(self, svg:str)->None:
        if not isinstance(svg, str): return
        self._svg = svg
        super().update()
    
    def paintEvent(self, event):
        super().paintEvent(event)
        painter = QPainter(self)
        painter.fillRect(self.rect(), Qt.GlobalColor.transparent)  # Clear background properly
        if self._svg:
            svgXmlStream = QXmlStreamReader(self._svg)
            renderer = QSvgRenderer(svgXmlStream)
            renderer.setAspectRatioMode(QtCore.Qt.AspectRatioMode.KeepAspectRatio)
            renderer.render(painter, self.rect())
    # def resizeEvent(self, event):
    #     super().resizeEvent(event)
    #     print(f"Label:")
    #     print(f"  size            = {self.size()}")
    #     print(f"  sizeHint        = {self.sizeHint()}")
    #     print(f"  minSizeHint     = {self.minimumSizeHint()}")
    #     print(f"  QSizePolicy     = {self.sizePolicy().horizontalPolicy()}, {self.sizePolicy().verticalPolicy()}")
    #     print("---")
    def mouseDoubleClickEvent(self, event):
        # self.doubleClickEvent.emit()
        self._parent.labelWidgetDoubleClicked()
        super().mouseDoubleClickEvent(event)

class QCRotatedLabel(QLabel):
    def __init__(self, text='', parent=None):
        super().__init__(text, parent)
        self.setSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Minimum)

    def sizeHint(self):
        fm = QFontMetrics(self.font())
        size = fm.size(0, self.text())
        # Swap width and height because of rotation
        return size.transposed()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setRenderHint(QPainter.RenderHint.TextAntialiasing)

        # Rotate around center
        painter.translate(self.width() / 2, self.height() / 2)
        painter.rotate(-90)
        painter.translate(-self.height() / 2, -self.width() / 2)

        rect = QRect(0, 0, self.height(), self.width())
        painter.drawText(rect, Qt.AlignmentFlag.AlignCenter, self.text())

class QCLabelWidget(QFrame):
    labelWidget:QCScalledLabel
    labelOptionAuto:str
    labelOptionManual:str
    aspectRatioW2H:float
    labelDoubleClickSignal:Signal
    labelDoubleClickSignal = Signal(bool)

    def __init__(self, width:int = 350, height:int = 300, parent = None):
        QFrame.__init__(self)
        self.labelOptionAuto = "Auto"
        self.labelOptionManual = "Manual"
        self.aspectRatioW2H = 1.7 #labelWidth / labelHeight
        self.labelWidget = QCScalledLabel(self)
        self.rotatedLabelAuto = QCRotatedLabel(self.labelOptionAuto)
        self.rotatedLabelManual = QCRotatedLabel(self.labelOptionManual)
        self.radioButtonAuto = QRadioButton(self)
        self.radioButtonManual = QRadioButton(self)

        vBoxLayoutM = QVBoxLayout()
        vBoxLayoutS1 = QVBoxLayout()
        vBoxLayoutS2 = QVBoxLayout()
        hBoxLayout = QHBoxLayout()

        vBoxLayoutS1.addWidget(self.rotatedLabelAuto, 0, Qt.AlignmentFlag.AlignTop|Qt.AlignmentFlag.AlignRight)
        vBoxLayoutS1.addWidget(self.radioButtonAuto, 0, Qt.AlignmentFlag.AlignTop|Qt.AlignmentFlag.AlignRight)
        vBoxLayoutS1.setContentsMargins(0, 0, 0, 0)
        vBoxLayoutS1.setSpacing(0)
        vBoxLayoutS2.addWidget(self.rotatedLabelManual, 0, Qt.AlignmentFlag.AlignTop|Qt.AlignmentFlag.AlignRight)
        vBoxLayoutS2.addWidget(self.radioButtonManual, 0, Qt.AlignmentFlag.AlignTop|Qt.AlignmentFlag.AlignRight)
        vBoxLayoutS2.setContentsMargins(0, 0, 0, 0)
        vBoxLayoutS2.setSpacing(0)
        vBoxLayoutM.addLayout(vBoxLayoutS1, 0)
        vBoxLayoutM.addLayout(vBoxLayoutS2, 0)
        vBoxLayoutM.setContentsMargins(0, 0, 0, 0)
        vBoxLayoutM.setSpacing(2)
        hBoxLayout.addWidget(self.labelWidget, 1, Qt.AlignmentFlag.AlignRight)
        hBoxLayout.addLayout(vBoxLayoutM, 0)
        self.setLayout(hBoxLayout)

        self.setFrameShape(QFrame.Shape.Box)
        self.setFrameShadow(QFrame.Shadow.Sunken)
        self.setLineWidth(1)

        policy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        # policy.setHeightForWidth(True)
        self.setSizePolicy(policy)
        self.radioButtonAuto.setChecked(True)
        # pass True if label in auto mode
        # self.labelDoubleClickSignal = Signal(bool)

    def labelWidgetDoubleClicked(self)->None:
        self.labelDoubleClickSignal.emit(self.radioButtonAuto.isChecked())
    
    def setSvg(self, svg:str)->None:
        self.labelWidget.setSvg(svg)
    
    def setAutoButtonText(self, txt)->None:
        self.rotatedLabelAuto.setText(txt)

    def setManualButtonText(self, txt)->None:
        self.rotatedLabelManual.setText(txt)

    def isLabelModeAuto(self)->bool:
        if self.radioButtonAuto.isChecked():
            return True
        return False
    
    def setMaximumHeight(self, maxh):
        super().setMaximumHeight(maxh)
        self.labelWidget.setMaximumHeight(maxh)

    def setMinimumHeight(self, minh):
        super().setMinimumHeight(minh)
        self.labelWidget.setMinimumHeight(minh)
    # def resizeEvent(self, event):
    #     w = self.width()
    #     h = self.height()
    #     expected_h = w / self.aspectRatioW2H
    #     expected_w = h * self.aspectRatioW2H

    #     if expected_h > h:
    #         # Too tall, reduce width
    #         self.resize(int(expected_w), h)
    #     else:
    #         # Too wide, reduce height
    #         self.resize(w, int(expected_h))

    #     super().resizeEvent(event)
    # def heightForWidth(self, width):
    #     return int(width/self.aspectRatioW2H)

    # def hasHeightForWidth(self):
    #     return True

    # def sizeHint(self):
    #     return QSize(170, 200)

    # def minimumSizeHint(self):
    #     return QSize(85, 50)

class QCLabelPic(QLabel):
    _svg:str|None
    defaultLabel:Final[str] = """
        <svg width="800px" height="800px" viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="120" height="120" fill="#EFF1F3"/>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M33.2503 38.4816C33.2603 37.0472 34.4199 35.8864 35.8543 35.875H83.1463C84.5848 35.875 85.7503 37.0431 85.7503 38.4816V80.5184C85.7403 81.9528 84.5807 83.1136 83.1463 83.125H35.8543C34.4158 83.1236 33.2503 81.957 33.2503 80.5184V38.4816ZM80.5006 41.1251H38.5006V77.8751L62.8921 53.4783C63.9172 52.4536 65.5788 52.4536 66.6039 53.4783L80.5006 67.4013V41.1251ZM43.75 51.6249C43.75 54.5244 46.1005 56.8749 49 56.8749C51.8995 56.8749 54.25 54.5244 54.25 51.6249C54.25 48.7254 51.8995 46.3749 49 46.3749C46.1005 46.3749 43.75 48.7254 43.75 51.6249Z" fill="#687787"/>
        </svg>"""
    
    def __init__(self, parent = None):
        QLabel.__init__(self, "", parent)
        self._svg = None

    def setSvg(self, svg:str|None)->None:
        # if not isinstance(svg, str): return
        self._svg = svg
        super().update()
    
    def paintEvent(self, event:QPaintEvent):
        tSvg:str
        super().paintEvent(event)
        painter = QPainter(self)
        painter.fillRect(self.rect(), Qt.GlobalColor.transparent)  # Clear background properly
        if self._svg:
            tSvg = self._svg
        else:
            tSvg = self.defaultLabel
        svgXmlStream = QXmlStreamReader(tSvg)
        renderer = QSvgRenderer(svgXmlStream)
        renderer.setAspectRatioMode(QtCore.Qt.AspectRatioMode.KeepAspectRatio)
        renderer.render(painter, self.rect())
        painter.end()

class QCBarcodeScannerWidget(QLabel):
    svgInFocus:str
    svgOutFocus:str
    barcodeCaptured:str
    barCodeScanned:ClassVar[Signal] = Signal(str)
    widgetCss:Final[str] = """
            .QBarCodeBoxLabel {
                border-radius: 10px;
                border-color: blue;
                border-width: 2px;
                border-style: solid;
            }
            .QBarCodeBoxLabel[disableField="true"] {
                border-radius: 10px;
                border-color: gray;
                border-width: 2px;
                border-style: solid;
            }
        """
    defaultPicture:Final[str] = """
        <svg width="800px" height="800px" viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="120" height="120" fill="none"/>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M33.2503 38.4816C33.2603 37.0472 34.4199 35.8864 35.8543 35.875H83.1463C84.5848 35.875 85.7503 37.0431 85.7503 38.4816V80.5184C85.7403 81.9528 84.5807 83.1136 83.1463 83.125H35.8543C34.4158 83.1236 33.2503 81.957 33.2503 80.5184V38.4816ZM80.5006 41.1251H38.5006V77.8751L62.8921 53.4783C63.9172 52.4536 65.5788 52.4536 66.6039 53.4783L80.5006 67.4013V41.1251ZM43.75 51.6249C43.75 54.5244 46.1005 56.8749 49 56.8749C51.8995 56.8749 54.25 54.5244 54.25 51.6249C54.25 48.7254 51.8995 46.3749 49 46.3749C46.1005 46.3749 43.75 48.7254 43.75 51.6249Z" fill="#687787"/>
        </svg>"""

    def __init__(self, width:int = 200, height:int = 100):
        QLabel.__init__(self)
        self.setText("")
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setStyleSheet(self.widgetCss)
        self.setProperty('class', 'QBarCodeBoxLabel')
        self.svgInFocus = None
        self.svgOutFocus = None
        self.barcodeCaptured=""
        # self.setDefaultPicture()
    
    def setDefaultPicture(self):
        self.svgOutFocus="""
            <?xml version="1.0" encoding="iso-8859-1"?>
            <!-- Uploaded to: SVG Repo, www.svgrepo.com, Generator: SVG Repo Mixer Tools -->
            <!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
            <svg fill="#000000" height="800px" width="800px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" 
                viewBox="0 0 486.4 486.4" xml:space="preserve">
            <g>
                <path d="M77.9,124.773c-5.799,0-10.5,4.701-10.5,10.5v211.498c0,5.799,4.701,10.5,10.5,10.5c5.799,0,10.5-4.701,10.5-10.5V135.273
                    C88.4,129.474,83.699,124.773,77.9,124.773z"/>
                <path d="M111.372,124.773c-5.799,0-10.5,4.701-10.5,10.5v158.179c0,5.799,4.701,10.5,10.5,10.5c5.799,0,10.5-4.701,10.5-10.5
                    V135.273C121.872,129.474,117.171,124.773,111.372,124.773z"/>
                <path d="M150.472,124.773c-5.799,0-10.5,4.701-10.5,10.5v158.179c0,5.799,4.701,10.5,10.5,10.5c5.799,0,10.5-4.701,10.5-10.5
                    V135.273C160.972,129.474,156.271,124.773,150.472,124.773z"/>
                <path d="M311.149,124.773c-5.799,0-10.5,4.701-10.5,10.5v158.179c0,5.799,4.701,10.5,10.5,10.5c5.799,0,10.5-4.701,10.5-10.5
                    V135.273C321.649,129.474,316.948,124.773,311.149,124.773z"/>
                <path d="M230.995,124.773c-5.799,0-10.5,4.701-10.5,10.5v158.179c0,5.799,4.701,10.5,10.5,10.5s10.5-4.701,10.5-10.5V135.273
                    C241.495,129.474,236.794,124.773,230.995,124.773z"/>
                <path d="M274.123,124.773c-5.799,0-10.5,4.701-10.5,10.5v158.179c0,5.799,4.701,10.5,10.5,10.5c5.799,0,10.5-4.701,10.5-10.5
                    V135.273C284.623,129.474,279.922,124.773,274.123,124.773z"/>
                <path d="M198.091,124.773c-5.799,0-10.5,4.701-10.5,10.5v158.179c0,5.799,4.701,10.5,10.5,10.5c5.799,0,10.5-4.701,10.5-10.5
                    V135.273C208.591,129.474,203.89,124.773,198.091,124.773z"/>
                <path d="M361.675,124.773c-5.799,0-10.5,4.701-10.5,10.5v158.179c0,5.799,4.701,10.5,10.5,10.5c5.799,0,10.5-4.701,10.5-10.5
                    V135.273C372.175,129.474,367.474,124.773,361.675,124.773z"/>
                <path d="M411.083,124.773c-5.799,0-10.5,4.701-10.5,10.5v211.498c0,5.799,4.701,10.5,10.5,10.5s10.5-4.701,10.5-10.5V135.273
                    C421.583,129.474,416.882,124.773,411.083,124.773z"/>
                <path d="M455.211,62.346L31.188,62.346C13.991,62.346,0,76.337,0,93.535v299.33c0,17.197,13.991,31.189,31.188,31.189l424.023,0
                    c17.197,0,31.189-13.991,31.189-31.189V93.535C486.4,76.338,472.409,62.346,455.211,62.346z M465.4,392.865
                    c0,5.618-4.57,10.189-10.189,10.189l-424.023,0c-5.618,0-10.188-4.571-10.188-10.189V93.535c0-5.618,4.57-10.189,10.188-10.189
                    l424.023,0.001c5.618,0,10.189,4.571,10.189,10.188V392.865z"/>
            </g>
            </svg>
        """
        self.svgInFocus="""
            <?xml version="1.0" encoding="UTF-8" standalone="no"?>
            <!-- Uploaded to: SVG Repo, www.svgrepo.com, Generator: SVG Repo Mixer Tools -->

            <svg
            fill="#000000"
            height="800px"
            width="800px"
            version="1.1"
            id="Capa_1"
            viewBox="0 0 486.4 486.4"
            xml:space="preserve"
            sodipodi:docname="barcode_1b.svg"
            inkscape:version="1.3.2 (091e20e, 2023-11-25, custom)"
            xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
            xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
            xmlns="http://www.w3.org/2000/svg"
            xmlns:svg="http://www.w3.org/2000/svg"><defs
            id="defs10" /><sodipodi:namedview
            id="namedview10"
            pagecolor="#ffffff"
            bordercolor="#000000"
            borderopacity="0.25"
            inkscape:showpageshadow="2"
            inkscape:pageopacity="0.0"
            inkscape:pagecheckerboard="0"
            inkscape:deskcolor="#d1d1d1"
            inkscape:zoom="2.24"
            inkscape:cx="400"
            inkscape:cy="400"
            inkscape:window-width="3840"
            inkscape:window-height="2050"
            inkscape:window-x="3768"
            inkscape:window-y="-12"
            inkscape:window-maximized="1"
            inkscape:current-layer="Capa_1" />
            <g
            id="g10">
                <path
            d="M 455.211,62.346 H 31.188 C 13.991,62.346 0,76.337 0,93.535 v 299.33 c 0,17.197 15.076714,31.189 32.273714,31.189 l 422.937286,0 c 17.197,0 31.189,-13.991 31.189,-31.189 V 93.535 c 0,-17.197 -13.991,-31.189 -31.189,-31.189 z M 465.4,392.865 c 0,5.618 -4.57,10.189 -10.189,10.189 H 31.188 C 25.57,403.054 21,398.483 21,392.865 V 93.535 c 0,-5.618 4.57,-10.189 10.188,-10.189 l 424.023,10e-4 c 5.618,0 10.189,4.571 10.189,10.188 z"
            id="path10"
            sodipodi:nodetypes="ssssssssssssssccss"
            style="stroke:none;stroke-opacity:1;fill:#000000;fill-opacity:1" />
            </g>
            <path
            style="fill:#109900;stroke:#00070e;stroke-width:21.28;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:12.3;stroke-dasharray:none"
            d="m 411.21429,132.19658 0,58.08571"
            id="path11"
            sodipodi:nodetypes="cc" /><path
            style="fill:#109900;stroke:#00070e;stroke-width:21.28;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:12.3;stroke-dasharray:none"
            d="m 410.54115,242.60286 0,99.61428"
            id="path11-4"
            sodipodi:nodetypes="cc" /><path
            style="fill:#109900;stroke:#00070e;stroke-width:21.28;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:12.3;stroke-dasharray:none"
            d="m 363.49715,132.26171 0,58.62856"
            id="path11-7"
            sodipodi:nodetypes="cc" /><path
            style="fill:#109900;stroke:#00070e;stroke-width:21.28;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:12.3;stroke-dasharray:none"
            d="m 313.90172,132.468 v 58.62856"
            id="path11-7-4"
            sodipodi:nodetypes="cc" /><path
            style="fill:#109900;stroke:#00070e;stroke-width:21.28;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:12.3;stroke-dasharray:none"
            d="m 313.44572,242.23371 v 58.62856"
            id="path11-7-0"
            sodipodi:nodetypes="cc" /><path
            style="fill:#109900;stroke:#00070e;stroke-width:21.28;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:12.3;stroke-dasharray:none"
            d="M 361.90115,243.34114 V 301.9697"
            id="path11-7-5"
            sodipodi:nodetypes="cc" /><path
            style="fill:#109900;stroke:#00070e;stroke-width:21.28;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:12.3;stroke-dasharray:none"
            d="m 274.8703,132.12058 v 58.62856"
            id="path11-7-4-8"
            sodipodi:nodetypes="cc" /><path
            style="fill:#109900;stroke:#00070e;stroke-width:21.28;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:12.3;stroke-dasharray:none"
            d="m 273.75201,241.8103 v 58.62856"
            id="path11-7-4-5"
            sodipodi:nodetypes="cc" /><path
            style="fill:#109900;stroke:#00070e;stroke-width:21.28;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:12.3;stroke-dasharray:none"
            d="m 232.78801,131.82743 v 58.62856"
            id="path11-7-4-8-4"
            sodipodi:nodetypes="cc" /><path
            style="fill:#109900;stroke:#00070e;stroke-width:21.28;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:12.3;stroke-dasharray:none"
            d="m 231.97372,241.62571 v 58.62856"
            id="path11-7-4-8-7"
            sodipodi:nodetypes="cc" /><path
            style="fill:#109900;stroke:#00070e;stroke-width:21.28;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:12.3;stroke-dasharray:none"
            d="m 200.64001,132.544 v 58.62856"
            id="path11-7-4-8-2"
            sodipodi:nodetypes="cc" /><path
            style="fill:#109900;stroke:#00070e;stroke-width:21.28;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:12.3;stroke-dasharray:none"
            d="m 199.42401,241.984 v 58.62856"
            id="path11-7-4-8-3"
            sodipodi:nodetypes="cc" /><path
            style="fill:#109900;stroke:#00070e;stroke-width:21.28;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:12.3;stroke-dasharray:none"
            d="m 152.00001,132.544 v 58.62856"
            id="path11-7-4-8-8"
            sodipodi:nodetypes="cc" /><path
            style="fill:#109900;stroke:#00070e;stroke-width:21.28;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:12.3;stroke-dasharray:none"
            d="m 151.39201,242.592 v 58.62856"
            id="path11-7-4-8-9"
            sodipodi:nodetypes="cc" /><path
            style="fill:#109900;stroke:#00070e;stroke-width:21.28;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:12.3;stroke-dasharray:none"
            d="m 113.08801,131.936 v 58.62856"
            id="path11-7-4-8-0"
            sodipodi:nodetypes="cc" /><path
            style="fill:#109900;stroke:#00070e;stroke-width:21.28;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:12.3;stroke-dasharray:none"
            d="m 112.48001,241.376 v 58.62856"
            id="path11-7-4-8-32"
            sodipodi:nodetypes="cc" /><path
            style="fill:#109900;stroke:#00070e;stroke-width:21.28;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:12.3;stroke-dasharray:none"
            d="m 79.26801,241.56058 v 99.61428"
            id="path11-4-2"
            sodipodi:nodetypes="cc" /><path
            style="fill:#109900;stroke:#00070e;stroke-width:21.28;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:12.3;stroke-dasharray:none"
            d="m 80.25601,132.544 v 58.62856"
            id="path11-7-9"
            sodipodi:nodetypes="cc" /><rect
            style="fill:#c72b09;fill-opacity:1;stroke:none;stroke-width:2.24281;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:12.3;stroke-dasharray:none"
            id="rect14"
            width="364.52859"
            height="11.67143"
            x="64.057144"
            y="211.03029"
            ry="0.37523535" /></svg>
        """

    def setSvgFocusPictures(self, svgInFocus:str, svgOutFocus:str)->None:
        self.svgInFocus = svgInFocus
        self.svgOutFocus = svgOutFocus
        super().update()
    
    def updateStylesheetOnWidget(self, value:bool)->None:
        self.setProperty("disableField", value)
        self.style().unpolish(self)
        self.style().polish(self)
    
    def focusOutEvent(self, ev):
        self.updateStylesheetOnWidget(True)
        return super().focusOutEvent(ev)
    
    def focusInEvent(self, ev):
        self.updateStylesheetOnWidget(False)
        super().focusInEvent(ev)
    
    def paintEvent(self, event)->None:
        super().paintEvent(event)
        painter = QPainter(self)
        painter.fillRect(self.rect(), Qt.GlobalColor.transparent)  # Clear background properly
        if self.hasFocus():
            if self.svgInFocus is None:
                svgStr = self.defaultPicture
            else:
                svgStr = self.svgInFocus
        else:
            if self.svgOutFocus is None:
                svgStr = self.defaultPicture
            else:
                svgStr = self.svgOutFocus
        svgXmlStream = QXmlStreamReader(svgStr)
        renderer = QSvgRenderer(svgXmlStream)
        renderer.setAspectRatioMode(QtCore.Qt.AspectRatioMode.KeepAspectRatio)
        renderer.render(painter, self.rect())
        painter.end()
    
    def keyPressEvent(self, event):
        _event:QKeyEvent = event
        tx = _event.text()
        if tx == "\r":
            self.barcodeCaptured = str.replace(self.barcodeCaptured, "\n", "")
            self.barcodeCaptured = str.replace(self.barcodeCaptured, "\r", "")
            self.barCodeScanned.emit(str(self.barcodeCaptured))
            self.barcodeCaptured = ""
        if tx:
            self.barcodeCaptured += tx
        super().keyPressEvent(event)


class QCScalledLabel2(QWidget):
    # printer:QPrinter
    doubleClickEvent:ClassVar[Signal] = Signal((bool, ))
    widgetCss:Final[str] = """
            .QWidgetBoxLabel {
                border-radius: 10px;
                border-color: gray;
                border-width: 2px;
                border-style: solid;
                margin: 0;
                padding: 0;
            }
        """
    autoMode:bool
    manualTxt:str
    autoTxt:str

    def __init__(self, autoMode:bool = True, parent = None):
        QWidget.__init__(self)
        self.prepareLayout()
        self.autoMode = autoMode
        self.manualTxt = "M"
        self.autoTxt = "A"
        if(self.autoMode):
            self.buttonAuto.setText(self.autoTxt)
        else:
            self.buttonAuto.setText(self.manualTxt)
        self.buttonAuto.clicked.connect(self.buttonClicked)

    def setSubText(self, autoText:str, manualText:str)->None:
        self.autoTxt = autoText
        self.manualTxt = manualText
        if(self.autoMode):
            self.buttonAuto.setText(self.autoTxt)
        else:
            self.buttonAuto.setText(self.manualTxt)

    def buttonClicked(self, state:bool)->None:
            self.autoMode = not self.autoMode
            if(self.autoMode):
                self.buttonAuto.setText(self.autoTxt)
            else:
                self.buttonAuto.setText(self.manualTxt)
            
    def prepareLayout(self)->None:
        self.picLabel = QCLabelPic(self)
        self.buttonAuto = QPushButton("A", self)
        self.buttonAuto.setMaximumSize(25, 20)
        containerH1 = QWidget(self)
        containerH1.setStyleSheet(self.widgetCss)
        containerH1.setProperty('class', 'QWidgetBoxLabel')
        layoutH1 = QHBoxLayout(containerH1)
        layoutH1.setContentsMargins(5, 5, 10, 5)  # left, top, right, bottom
        layoutH1.setSpacing(1)
        layoutH1.addWidget(self.buttonAuto, 0)
        layoutH1.addWidget(self.picLabel, 1)
        layoutMain = QHBoxLayout()
        layoutMain.setContentsMargins(5, 0, 5, 0)  # left, top, right, bottom
        layoutMain.setSpacing(0)
        layoutMain.addWidget(containerH1)
        self.setLayout(layoutMain)
    
    def setSvg(self, svg:str|None)->None:
        self.picLabel.setSvg(svg)
       
    def resizeEvent(self, event):
        super().resizeEvent(event)
        # print(f"Label:")
        # print(f"  size            = {self.size()}")
        # print(f"  sizeHint        = {self.sizeHint()}")
        # print(f"  minSizeHint     = {self.minimumSizeHint()}")
        # print(f"  QSizePolicy     = {self.sizePolicy().horizontalPolicy()}, {self.sizePolicy().verticalPolicy()}")
        # print("---")

    def mouseDoubleClickEvent(self, event):
        self.doubleClickEvent.emit(self.autoMode)
        # self._parent.labelWidgetDoubleClicked()
        super().mouseDoubleClickEvent(event)
    
