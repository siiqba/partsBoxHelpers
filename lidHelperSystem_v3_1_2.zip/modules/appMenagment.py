from PySide6.QtCore import QObject, Signal, Slot, QDir, QFileDevice, QEvent
from PySide6.QtWidgets import (QWidget)
from PySide6.QtGui import QCloseEvent
from typing import Any, ClassVar, Final

from app.modules.appSettings import AppSettings
from app.modules.partsBoxProvider import PartsBoxWrapper
from app.modules.printer import LabelPrinter

class AppMenagment(QObject):
    MAX_WINDOWS_COUNT:Final[int] = 4
    # {winName: {objId: obj}}
    # winName:str - windows class name
    # objId: int - windows object ID (id(obj))
    # obj: QWidget object
    winCollection : dict[str, dict[int, QWidget]]
    rootPath:QDir
    appSettings:AppSettings|None
    partsBoxWrapper:PartsBoxWrapper|None
    labelPrinter:LabelPrinter|None

    def __init__(self, rootPath:QDir, settingsFileName:str, lastStateFileName:str) -> None:
        super().__init__()
        self.rootPath = rootPath
        self.winCollection = {}
        self.appSettings = AppSettings(rootPath, settingsFileName, lastStateFileName)
        if not self.appSettings.isAppSetingsLoaded():
            print(f"Error in AppMenagment:appSettings -> No settings loaded")
            exit(0)
        self.partsBoxWrapper = None
        self.labelPrinter = None
    
    def showWindow(self, winName:str, extraParameter:Any|None = None) -> None:
        from app.modules.windows.mainAppWindow import MainAppWindow
        from app.modules.windows.lidLabelWindow import LidLabelWindow
        from app.modules.windows.pidInventoryWindow import PidInventoryWindow

        winObj:QWidget|None = None

        if self.winCollection.keys().__contains__(winName):
            if len(self.winCollection[winName]) >= self.MAX_WINDOWS_COUNT:
                for obj in self.winCollection[winName].values(): obj.raise_()
                return
        try:
            if extraParameter is None:
                winObj = eval(winName)(None, self)
            else:
                winObj = eval(winName)(None, self, extraParameter)
        except Exception as e:
            print(f"Error in AppMenagment:showWindow: {e}")
        
        if winObj is None: return

        if self.winCollection.keys().__contains__(winName):
            self.winCollection[winName][id(winObj)] = winObj
        else:
            self.winCollection[winName] = {id(winObj): winObj}
        
        winObj.show()

    @Slot(Any)
    def onWindowClose(self, obj:Any)->None:
        objClassName:str = type(obj).__name__
        objInstanceId:int = id(obj)
        print("class name: {0}, object id: {1}".format(objClassName, objInstanceId))
        if self.winCollection.keys().__contains__(objClassName):
            if self.winCollection[objClassName].keys().__contains__(objInstanceId):
                self.winCollection[objClassName].pop(objInstanceId)
        pass
    
    def closeAllWindows(self)->None:
        objList = list()
        for key, obj in self.winCollection.items():
            if key == "MainAppWindow": continue
            objList.extend(list(obj.values()))
        for oObj in objList:
            oObj.close()


    def isAnyWidowPresent(self)->bool:
        if len(self.winCollection) > 0: return True
        return False
    
    def getAppSettings(self)->AppSettings:
        return self.appSettings
    
    def getLabelPrinter(self)->LabelPrinter:
        if self.labelPrinter is None:
            self.labelPrinter = LabelPrinter()
        return self.labelPrinter
    
    def getPartsBoxWrapper(self)->PartsBoxWrapper|None:
        if self.partsBoxWrapper is None:
            partsBoxApiData = self.appSettings.getParameter(self.appSettings.SETTINGS_TYPE.GLOBAL,\
                                                            self.appSettings.SETTINGS_TYPE.DATA_PROVIDER_PARTBOX)
            if partsBoxApiData is None: return None
            host = partsBoxApiData.get('url', "")
            apiKey = partsBoxApiData.get('key', "")
            self.partsBoxWrapper = PartsBoxWrapper(host, apiKey)
        
        return self.partsBoxWrapper
