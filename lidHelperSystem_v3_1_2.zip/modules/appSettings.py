import json
from typing import Any, ClassVar, Final
import copy
from enum import Enum
from os import path
from PySide6.QtCore import QDir, QObject, Signal
from PySide6.QtGui import QIcon, QPixmap


class AppSettings(QObject):
    SEPARATOR:Final[str] = '/'

    rootPath:QDir
    appSettings:dict|None

    # currentPrinter:PrinterDescriptor|None
    # currentLabel:LabelDescriptor|None

    # new aproache to any param
    anyParam:dict[str, Any]

    # partsBoxWrapper:PartsBoxWrapper

    class SETTINGS_TYPE(Enum):
        GLOBAL = "appGlobal"
        SUPPORTED_LANGUAGE = "supportedLanguage"
        APP_NAME = "appName"
        SUPPORTED_PRINTERS = "supportedPrinters"
        SUPPORTED_LABELS = "supportedLabels"
        DATA_PROVIDER_PARTBOX = "dataProviders/partsBoxApi"

    class LANGUAGE_PARAM(Enum):
        EN = "en"
        PL = "pl"

    currentLanguage:LANGUAGE_PARAM

    langSettingsChanged :ClassVar[Signal] = Signal((Any,))
    # printerSettingsChanged :ClassVar[Signal] = Signal((PrinterDescriptor,))
    # labelSettingsChanged :ClassVar[Signal] = Signal((LabelDescriptor,))
    anyParamChanged: ClassVar[Signal] = Signal((str, Any, bool))

    @staticmethod
    def ob(obj:Any)-> str:
        return type(obj).__name__
    
    def __init__(self, rootPath:QDir, settingsSubPath:str, lastState:str) -> None:
        super().__init__(None)
        self.rootPath = rootPath
        settingsPath= self.rootPath.filePath(settingsSubPath)
        self.appSettings = None
        self.currentLanguage = self.LANGUAGE_PARAM.EN

        try:
            f = open(settingsPath, encoding='utf-8')
            jSet = json.load(f)
            self.settingsOk = True
        except json.decoder.JSONDecodeError as e:
            jSet = None
        finally:
            if f is not None: f.close()
        self.appSettings = jSet

        self.currentPrinter = None
        # self.currentLabel = None
        self.anyParam = dict()

        # partsBoxApiData = self.getParameter(self.SETTINGS_TYPE.GLOBAL, self.SETTINGS_TYPE.DATA_PROVIDER_PARTBOX)
        # if partsBoxApiData is None:
        #     self.partsBoxWrapper = None
        # else:
        #     host = partsBoxApiData.get('url', "")
        #     apiKey = partsBoxApiData.get('key', "")
        #     self.partsBoxWrapper = PartsBoxWrapper(host, apiKey)

    
    def isAppSetingsLoaded(self)->bool:
        if self.appSettings is None: return False
        return True
    
    def setCurrentParam(self, paramObj_key:str|Any, paramObj:Any|None=None, saveCoppy:bool = False)->bool:
        key:str = ""
        pObj:Any|None = None
        if isinstance(paramObj_key, type):
            pObj = paramObj
            key = paramObj_key.__name__
        elif isinstance(paramObj_key, str):
            pObj = paramObj
            key = paramObj_key
        else:
            key = type(paramObj_key).__name__
            pObj = paramObj_key
        if pObj is None: return False
        if saveCoppy:
            self.anyParam[key] = copy.deepcopy(pObj)
        else:
            self.anyParam[key] = pObj
        self.anyParamChanged.emit(key, self.anyParam[key], True)
        return True

    def getCurrentParam(self, name:Any|str)->Any|None:
        key:str = ""
        if isinstance(name, str):
            key = name
        elif isinstance(name, type):
            key = name.__name__
        else:
            key = type(name).__name__
        return self.anyParam.get(key, None)
    
    def getSvgPic(self, name:str)->str:
        """do poprawy"""
        filePath = self.rootPath.filePath("misc/"+name+""".svg""")
        # print(f"getSvgPic: self.rootPath{filePath}")
        ret = None
        f = None
        try:
            f = open(file=filePath)
            ret = f.read()
        except:
            ret = None
        finally:
            if f is not None: f.close()
        return ret

    def getCurrentAnyParam(self, name:Any|str)->Any|None:
        """Do usunięcia"""
        key:str = ""
        if isinstance(name, str):
            key = name
        elif isinstance(name, type):
            key = name.__name__
        else:
            key = type(name).__name__

        if key in self.anyParam:
            return self.anyParam[key]
        else:
            return None
    
    def setCurrentlanguage(self, lang:LANGUAGE_PARAM|str)->bool:
        ln = None
        if isinstance(lang, str):
            try:
                ln = self.LANGUAGE_PARAM(lang.lower())
            except ValueError:
                return False
            self.currentLanguage = ln
        if isinstance(lang, self.LANGUAGE_PARAM):
            self.currentLanguage = lang
        self.langSettingsChanged.emit(self)
        return True
    
    # def setCurrentPrinter(self, printer:dict|PrinterDescriptor|None)->bool:
    #     tp = PrinterDescriptor()
    #     if tp.setPrinter(printer):
    #         self.currentPrinter = tp
    #         self.printerSettingsChanged.emit(self.currentPrinter)
    #         return True
    #     else:
    #         return False
    
    # def setCurrentLabel(self, label:dict|LabelDescriptor|None)->bool:
    #     tl = LabelDescriptor()
    #     if tl.setLabel(label):
    #         self.currentLabel = tl
    #         self.labelSettingsChanged.emit(self.currentLabel)
    #         return True
    #     else:
    #         return False
    
    # def getCurrentPrinter(self)->PrinterDescriptor|None:
    #     return self.currentPrinter
    
    # def getCurrentLabel(self)->LabelDescriptor|None:
    #     return self.currentLabel
    # def getPartboxWrapper(self)->PartsBoxWrapper:
    #     return self.partsBoxWrapper

    def _splitSubPath(self, subPath:str)->list|None:
        tags = subPath.split(self.SEPARATOR)
        return tags

    def _paramPathResolver(self, mainObject:Any|Enum, subPath:str|Enum, isLanguage:bool = False)->list|None:
        rootName:str|None = None
        tags:list|None = None
        if isinstance(mainObject, str):
            rootName = mainObject
        elif isinstance(mainObject, Enum):
            rootName = mainObject.value
        else:
            rootName = type(mainObject).__name__
        if not isinstance(rootName, str): return None
        if isinstance(subPath, Enum):
            subPath = subPath.value
        if not isinstance(subPath, str): return None
        if isLanguage:
            txt = rootName + self.SEPARATOR + "txt" + self.SEPARATOR +\
                subPath + self.SEPARATOR + self.currentLanguage.value
        else:
            txt = rootName + self.SEPARATOR + subPath
        tags = txt.split(self.SEPARATOR)
        return tags
    
    def getParameter(self, mainObject:Any|Enum, subPath:str|Enum)->Any|None:
        tags:list|None = None
        tags = self._paramPathResolver(mainObject, subPath, False)
        if not isinstance(tags, list): return None
        i = self.appSettings
        for tag in tags:
            if tag == "": continue
            try:
                i = i[tag]
            except:
                return None
        return i
    
    def tr(self, mainObject:Any|Enum, subPath:str|Enum)->str:
        tags:list|None = None
        tags = self._paramPathResolver(mainObject, subPath, True)
        if not isinstance(tags, list): return "NaN2"
        i = self.appSettings
        for tag in tags:
            if tag == "": continue
            try:
                i = i[tag]
            except:
                return "NaN3"
        if not isinstance(i ,str): return "NaN4"
        return i







