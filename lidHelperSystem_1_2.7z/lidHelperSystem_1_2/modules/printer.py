from PySide6.QtGui import QImage, QPainter, QPixmap, QPageSize, QPageLayout
from PySide6.QtCore import QXmlStreamReader, QSize, QSizeF, QMarginsF, QObject, Signal, QDate, QThreadPool, QRunnable, Slot, QMutex, QMutexLocker
from PySide6.QtPrintSupport import QPrinterInfo, QPrinter
from PySide6.QtSvg import QSvgRenderer

from typing import ClassVar, Any

from modules.labels import LabelDescriptor
    

class PrinterDescriptor(object):
    name:str
    dpi:int
    systemName:str

    basicKeys: ClassVar[list[str]]=["name", "dpi", "systemName"]

    @classmethod
    def getInstance(cls, printer:Any|dict|None)->Any|None:
        if printer is None: return None
        tempObj = cls()
        if isinstance(printer, PrinterDescriptor):
            tempObj.name = printer.name
            tempObj.dpi = printer.dpi
            tempObj.systemName = printer.systemName
        elif isinstance(printer, dict):
            for key in cls.basicKeys:
                if key in printer:
                    setattr(tempObj, key, printer[key])
                else:
                    return None
        return tempObj
    
    def __new__(cls):
        return super(__class__, cls).__new__(cls)
    
    def __init__(self):
        # super().__init__(None)
        # if not self.setPrinter(printer):
        self.name = "NaN"
        self.dpi = 0
        self.systemName = "NaN"

    def __str__(self):
        return f"{self.name}-> DPI:{self.dpi}, SusyemName:{self.systemName}"

class PrinterJob(object):
    svgToPrint:str
    # printerDescriptor:PrinterDescriptor
    labelDescriptor:LabelDescriptor

    def __new__(cls):
        return super(__class__, cls).__new__(cls)
    
    def __init__(self, svgToPrint:str, labelDescriptor:LabelDescriptor):
        self.svgToPrint = svgToPrint
        # self.printerDescriptor = printerDescriptor
        self.labelDescriptor = labelDescriptor


class PrinterWorker(QRunnable, QObject):
    # eventUpdate:ClassVar[Signal] = Signal(int, int, bool, str)
    # eventFinal:ClassVar[Signal] = Signal(bool, str)
    svgLabel:str
    mutex:QMutex
    printer:QPrinter
    def __init__(self, svgLabel:str, printer:QPrinter, mutex:QMutex, parent = None):
        QRunnable.__init__(self)
        QObject.__init__(self, parent)
        self.mutex = mutex
        self.svgLabel = svgLabel
        self.printer = printer
    
    @Slot()
    def run(self)->None:
        svgXmlStreeam = QXmlStreamReader(self.svgLabel)
        svgRender = QSvgRenderer(svgXmlStreeam)
        if not self.mutex.tryLock(10000): return
        svgPainter = QPainter(self.printer)
        svgRender.render(svgPainter)
        svgPainter.end()
        self.mutex.unlock()


class LabelPrinter(QObject):
    currentPrinter:QPrinter|None
    printerMutex:QMutex
    printerTimeout_ms:int
    threadPool:QThreadPool
    # labelDescriptor:LabelDescriptor|None

    def __init__(self, printerTimeout_ms:int= 10000, parent = None):
        # super(PartsBoxWrapperAddPidStockWorker, self).__init__(parent)
        QObject.__init__(self, parent)
        self.currentPrinter = None
        self.printerMutex = QMutex()
        self.printerTimeout_ms = printerTimeout_ms
        self.threadPool = QThreadPool(parent)
        # self.labelDescriptor = None
    
    def printLabel(self, svgLabel:str)->bool:
        if self.currentPrinter is None: return False
        printerWorker = PrinterWorker(svgLabel, self.currentPrinter, self.printerMutex)
        self.threadPool.start(printerWorker)
        return True

    def setPrinterParam(self, printerDescriptor:PrinterDescriptor, labelDescriptor:LabelDescriptor)->bool:
        # if self.labelDescriptor is None: return False
        printerName:str = printerDescriptor.systemName
        printersInfo = QPrinterInfo.availablePrinters()
        selectedPrinter:QPrinterInfo|None = None

        for printer in printersInfo:
            if printer.isNull():
                continue
            if not printerName in printer.printerName():
                continue
            selectedPrinter = printer
            break
        
        if selectedPrinter is None: return False
        tempPrinter = QPrinter(selectedPrinter)

        tempPrinter.setResolution(printerDescriptor.dpi)
        labelSize = QSizeF(labelDescriptor.width, labelDescriptor.height)
        retOk = tempPrinter.setPageSize(QPageSize(labelSize, QPageSize.Unit.Millimeter))
        if not retOk :return False
        retOk = tempPrinter.setPageOrientation(QPageLayout.Orientation.Portrait)
        if not retOk :return False
        tempPrinter.setFullPage(True)
        retOk = tempPrinter.setPageMargins(QMarginsF(0.0, 0.0, 0.0, 0.0), QPageLayout.Unit.Millimeter)
        if not retOk :return False
        retOk = tempPrinter.isValid()
        if not retOk :return False
        if self.printerMutex.tryLock(self.printerTimeout_ms):
            self.currentPrinter = tempPrinter
            self.printerMutex.unlock()
            return True
        return False



        