from PySide6.QtCore import Qt, QDir
from PySide6.QtWidgets import (QPushButton, QWidget, QLineEdit, QGridLayout, QComboBox,
                               QHBoxLayout, QVBoxLayout, QLabel, QMessageBox,
                               QSizePolicy, QTableView, QTextEdit, QMainWindow, QListView,
                               QHeaderView, QFileDialog, QProgressBar)
from PySide6.QtGui import QPixmap
from modules.appMenagment import AppMenagment
from modules.appSettings import AppSettings
from modules.partsBoxProvider import PartsBoxProject
from modules.labels import LabelDescriptor
from modules.printer import PrinterDescriptor

class MainAppWindow(QMainWindow):
    appMenagment:AppMenagment
    appSettings:AppSettings
    projectsList:list[PartsBoxProject]|None

    def __init__(self, parent: QWidget | None, appMenagment:AppMenagment) -> None:
        super().__init__(parent)
        self.appMenagment = appMenagment
        self.appSettings = self.appMenagment.getAppSettings()
        # if self.appSettings is None: exit(0)
        self.prepareLayout()
        self.updateLayoutValues()
        langList = self.appSettings.getParameter(self.appSettings.SETTINGS_TYPE.GLOBAL,\
                                      self.appSettings.SETTINGS_TYPE.SUPPORTED_LANGUAGE)
        # for item in langList:
        self.comboBoxLanguage.addItems(langList)
        printersList = self.appSettings.getParameter(self.appSettings.SETTINGS_TYPE.GLOBAL,\
                                      self.appSettings.SETTINGS_TYPE.SUPPORTED_PRINTERS)
        for printer in printersList: self.comboBoxPrinter.addItem(printer["name"])
        tPrinter = PrinterDescriptor.getInstance(printersList[0])
        self.appSettings.setCurrentParam(tPrinter)
        labelsList = self.appSettings.getParameter(self.appSettings.SETTINGS_TYPE.GLOBAL,\
                                      self.appSettings.SETTINGS_TYPE.SUPPORTED_LABELS)
        for label in labelsList: self.comboBoxLabel.addItem(label["name"])
        tLabel = LabelDescriptor.getInstance(labelsList[0])
        self.appSettings.setCurrentParam(tLabel)
        self.comboBoxLanguage.currentTextChanged.connect(self.languageSelectChanged)
        self.comboBoxPrinter.currentIndexChanged.connect(self.printerSelectChanged)
        self.comboBoxLabel.currentIndexChanged.connect(self.labelSelectionChanged)
        self.appSettings.langSettingsChanged.connect(self.updateLayoutValues)
        self.pushButtonPartsBoxRefresh.clicked.connect(self.paushButtonEventReloadPartsBox)
        self.pushButtonLidLabels.clicked.connect(self.pushButtonLidLabelsPressed)
        self.comboBoxProject.currentIndexChanged.connect(self.selectedProjectChanged)
        self.pushButtonPidRaport.clicked.connect(self.pushButtonPidRaportClicked)
        self.pushButtonPidInventory.clicked.connect(self.pushButtonPidInventoryClicked)

        self.projectsList = None

    def updateLayoutValues(self)->None:
        self.setWindowTitle(self.appSettings.tr(self.appSettings.SETTINGS_TYPE.GLOBAL,\
                                                self.appSettings.SETTINGS_TYPE.APP_NAME))
        self.labelComboBoxLanguage.setText(self.appSettings.tr(self, "labelComboBoxLanguage"))
        self.labelComboBoxPrinter.setText(self.appSettings.tr(self, "labelComboBoxPrinter"))
        self.labelComboBoxLabel.setText(self.appSettings.tr(self, "labelComboBoxLabel"))
        self.labelPartsBoxRefresh.setText(self.appSettings.tr(self, "labelPartsBoxRefresh"))
        self.pushButtonPartsBoxRefresh.setText(self.appSettings.tr(self, "pushButtonPartsBoxRefresh"))
        self.pushButtonPidInventory.setText(self.appSettings.tr(self, "pushButtonPidInventory"))
        self.pushButtonLidLabels.setText(self.appSettings.tr(self, "pushButtonLidLabels"))
        self.pushButtonPidRaport.setText(self.appSettings.tr(self, "pushButtonPidRaport"))

    def setEnableUi(self, enable:bool=True)->None:
        self.setLayoutActivity(enable)

    def prepareLayout(self)->None:
        self.labelComboBoxLanguage = QLabel("Language:")
        self.comboBoxLanguage = QComboBox(self)
        self.labelComboBoxPrinter = QLabel("Printer:")
        self.comboBoxPrinter = QComboBox(self)
        self.labelComboBoxLabel = QLabel("Label:")
        self.comboBoxLabel = QComboBox(self)
        self.labelPartsBoxRefresh = QLabel("PartBox:")
        self.pushButtonPartsBoxRefresh = QPushButton("refresh", self)
        self.comboBoxProject = QComboBox(self)
        self.textEditProjectSDS = QTextEdit("", self)
        self.textEditProjectFDS = QTextEdit("", self)
        self.pushButtonPidRaport = QPushButton("PID report", self)
        self.pushButtonLidLabels = QPushButton("LID labels", self)
        self.pushButtonPidInventory = QPushButton("PID inventory", self)
        self.progressBarMain = QProgressBar(self)
        self.progressBarMain.setTextVisible(True)
        self.progressBarMain.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.labelProjectPicture = QLabel("No Picture")

        containerG1 = QWidget(self)
        containerG1.setProperty('class', 'widgetBorder')
        layoutG1 = QGridLayout(containerG1)
        layoutG1.addWidget(self.labelComboBoxLanguage, 0, 0, Qt.AlignmentFlag.AlignLeft)
        self.comboBoxLanguage.setMinimumWidth(100)
        layoutG1.addWidget(self.comboBoxLanguage, 1, 0, Qt.AlignmentFlag.AlignLeft)
        layoutG1.addWidget(self.labelComboBoxPrinter, 0, 1, Qt.AlignmentFlag.AlignLeft)
        self.comboBoxPrinter.setMinimumWidth(120)
        layoutG1.addWidget(self.comboBoxPrinter, 1, 1, Qt.AlignmentFlag.AlignLeft)
        layoutG1.addWidget(self.labelComboBoxLabel, 0, 2, Qt.AlignmentFlag.AlignLeft)
        self.comboBoxLabel.setMinimumWidth(120)
        layoutG1.addWidget(self.comboBoxLabel, 1, 2, Qt.AlignmentFlag.AlignLeft)
        expandWidgetG1 = QWidget(self)
        expandWidgetG1.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)
        layoutG1.addWidget(expandWidgetG1, 0, 3)
        layoutG1.addWidget(self.labelPartsBoxRefresh, 0, 4, Qt.AlignmentFlag.AlignLeft)
        layoutG1.addWidget(self.pushButtonPartsBoxRefresh, 1, 4, Qt.AlignmentFlag.AlignRight)

        containerH1 = QWidget(self)
        layoutH1 = QHBoxLayout(containerH1)
        self.labelProjectPicture.setMaximumWidth(250)
        self.labelProjectPicture.setMinimumWidth(150)
        layoutH1.addWidget(self.labelProjectPicture, 0, Qt.AlignmentFlag.AlignLeft)
        layoutH1.addWidget(self.textEditProjectSDS, 1)

        containerG2 = QWidget(self)
        containerG2.setProperty('class', 'widgetBorder')
        layoutG2 = QGridLayout(containerG2)
        layoutG2.addWidget(self.pushButtonPidRaport, 0, 0)
        layoutG2.addWidget(self.pushButtonLidLabels, 0, 1)
        layoutG2.addWidget(self.pushButtonPidInventory, 1, 0)

        layoutV2 = QVBoxLayout()
        layoutV2.addWidget(containerG1, 0, Qt.AlignmentFlag.AlignTop)
        layoutV2.addWidget(self.progressBarMain, 0, Qt.AlignmentFlag.AlignTop)
        layoutV2.addWidget(self.comboBoxProject, 0, Qt.AlignmentFlag.AlignTop)
        # layoutV2.addWidget(self.textEditProjectSDS, 0, Qt.AlignmentFlag.AlignTop)
        layoutV2.addWidget(containerH1, 0, Qt.AlignmentFlag.AlignTop)
        layoutV2.addWidget(self.textEditProjectFDS, 1)
        layoutV2.addWidget(containerG2, 0, Qt.AlignmentFlag.AlignBottom)

        self.mainWidget = QWidget(self)
        self.mainWidget.setLayout(layoutV2)
        self.setCentralWidget(self.mainWidget)

    def setLayoutActivity(self, isEnabled:bool = True)->None:
        self.labelComboBoxLanguage.setEnabled(isEnabled)
        self.comboBoxLanguage.setEnabled(isEnabled)
        self.labelComboBoxPrinter.setEnabled(isEnabled)
        self.comboBoxPrinter.setEnabled(isEnabled)
        self.labelComboBoxLabel.setEnabled(isEnabled)
        self.comboBoxLabel.setEnabled(isEnabled)
        self.labelPartsBoxRefresh.setEnabled(isEnabled)
        self.pushButtonPartsBoxRefresh.setEnabled(isEnabled)
        self.comboBoxProject.setEnabled(isEnabled)
        self.textEditProjectSDS.setEnabled(isEnabled)
        self.textEditProjectFDS.setEnabled(isEnabled)
        self.pushButtonPidRaport.setEnabled(isEnabled)
        self.pushButtonLidLabels.setEnabled(isEnabled)
        self.labelProjectPicture.setEnabled(isEnabled)
    
    def languageSelectChanged(self, text:str)->None:
        self.appSettings.setCurrentlanguage(text)

    def printerSelectChanged(self, index:int)->None:
        printersList = self.appSettings.getParameter(self.appSettings.SETTINGS_TYPE.GLOBAL,\
                                      self.appSettings.SETTINGS_TYPE.SUPPORTED_PRINTERS)
        if len(printersList) < index: return
        pDesc = PrinterDescriptor.getInstance(printersList[index])
        if pDesc is None: return
        self.appSettings.setCurrentParam(pDesc)

    def labelSelectionChanged(self, index:int)->None:
        # LabelDescriptor
        labelsList = self.appSettings.getParameter(self.appSettings.SETTINGS_TYPE.GLOBAL,\
                                      self.appSettings.SETTINGS_TYPE.SUPPORTED_LABELS)
        if len(labelsList) < index: return
        lDesc = LabelDescriptor.getInstance(labelsList[index])
        if lDesc is None: return
        self.appSettings.setCurrentParam(lDesc)

    def paushButtonEventReloadPartsBox(self)->None:
        partsBoxWrapper = self.appMenagment.getPartsBoxWrapper()
        if partsBoxWrapper is None: return
        self.progressBarMain.setMinimum(0)
        self.progressBarMain.setMaximum(0)
        self.progressBarMain.setFormat("Collecting projects data")
        # self.progressBarMain.setValue(0)
        self.setEnableUi(enable=False)
        partsBoxWrapper.getProjectsDone.connect(self.partsBoxGetProjectsListFinal)
        partsBoxWrapper.startGetProjectList()

    def pushButtonPidRaportClicked(self)->None:
        self.appMenagment.closeAllWindows()

    def partsBoxGetProjectsListFinal(self, isSucces:bool, message:str)->None:
        self.setEnableUi(enable=True)
        self.progressBarMain.reset()
        self.progressBarMain.setMaximum(1)
        self.progressBarMain.setValue(0)
        self.progressBarMain.setFormat(message)
        partsBoxWrapper = self.appMenagment.getPartsBoxWrapper()
        self.projectsList = partsBoxWrapper.getLastRet()
        partsBoxWrapper.getProjectsDone.disconnect(self.partsBoxGetProjectsListFinal)
        if self.projectsList is None: return
        # self.progressBarMain.setMaximum(1)
        # self.progressBarMain.setValue(0)
        # message += "\n druga linia"
        self.progressBarMain.setFormat(message)
        self.comboBoxProject.clear()
        for project in self.projectsList:
            self.comboBoxProject.addItem(project.name)

    def selectedProjectChanged(self, selectedIndex:int)->None:
        if self.projectsList is None: return
        if selectedIndex >= len(self.projectsList): return
        selectedProject = self.projectsList[selectedIndex]
        if isinstance(selectedProject.image, QPixmap):
            self.labelProjectPicture.setText("")
            self.labelProjectPicture.setPixmap(selectedProject.image.scaled(250, 250, Qt.AspectRatioMode.KeepAspectRatio))
        else:
            self.labelProjectPicture.setText("No Pic")

        self.textEditProjectSDS.setText( selectedProject.description)
        self.textEditProjectFDS.setText( selectedProject.notes)
    
    def pushButtonPidInventoryClicked(self)->None:
        partsBoxWrapper = self.appMenagment.getPartsBoxWrapper()
        if partsBoxWrapper is None: return
        self.setEnableUi(enable=True)
        # dummy = self.projectsList[self.comboBoxProject.currentIndex()]
        self.appMenagment.showWindow('PidInventoryWindow')

    def pushButtonLidLabelsPressed(self)->None:
        partsBoxWrapper = self.appMenagment.getPartsBoxWrapper()
        if partsBoxWrapper is None: return
        if self.projectsList is None: return
        if len(self.projectsList) < self.comboBoxProject.currentIndex(): return
        self.progressBarMain.setMinimum(0)
        self.progressBarMain.setMaximum(1)
        self.progressBarMain.setValue(0)
        self.setEnableUi(enable=False)
        partsBoxWrapper.getProjectBomDone.connect(self.partsBoxGetProjectBomFinal)
        partsBoxWrapper.getProjectBomUpdate.connect(self.partsBoxGetProjectBomUpdate)
        self.projectsList[self.comboBoxProject.currentIndex()].cleareBom()
        partsBoxWrapper.startGetProjectBom(self.projectsList[self.comboBoxProject.currentIndex()])
    
    def partsBoxGetProjectBomFinal(self, isSucces:bool, message:str)->None:
        partsBoxWrapper = self.appMenagment.getPartsBoxWrapper()
        partsBoxWrapper.getProjectBomDone.disconnect(self.partsBoxGetProjectBomFinal)
        partsBoxWrapper.getProjectBomUpdate.disconnect(self.partsBoxGetProjectBomUpdate)
        # self.progressBarMain.setMaximum(1)
        # self.progressBarMain.setValue(0)
        self.progressBarMain.reset()
        self.setEnableUi(enable=True)
        dummy = self.projectsList[self.comboBoxProject.currentIndex()]
        self.appMenagment.showWindow('LidLabelWindow', self.projectsList[self.comboBoxProject.currentIndex()])
        pass

    def partsBoxGetProjectBomUpdate(self, value:int, maxValue:int, isSucces:bool, message:str)->None:
        self.progressBarMain.setMaximum(maxValue)
        self.progressBarMain.setValue(value)
        self.progressBarMain.setFormat(message)

