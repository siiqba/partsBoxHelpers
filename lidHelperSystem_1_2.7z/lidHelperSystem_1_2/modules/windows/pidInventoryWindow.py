from PySide6.QtCore import Qt, QDir, QEvent, QSizeF, QAbstractTableModel, QModelIndex, QTimer, QItemSelection, QPersistentModelIndex
from PySide6.QtWidgets import (QPushButton, QWidget, QLineEdit, QGridLayout, QComboBox,
                               QHBoxLayout, QVBoxLayout, QLabel, QMessageBox,
                               QSizePolicy, QTableView, QTextEdit, QMainWindow, QListView,
                               QHeaderView, QFileDialog, QProgressBar, QAbstractItemView)
from PySide6.QtGui import QPixmap, QColor
from modules.appMenagment import AppMenagment
from modules.appSettings import AppSettings
from modules.partsBoxProvider import PartsBoxProject, PartsBoxPart, PartsBoxWrapper, PidPart
from modules.widgets.label import QCLabelWidget, QCScalledLabel2, QCBarcodeScannerWidget
from modules.labels import PartLabel, LabelDescriptor, SVG_COLOR, SVG_FONTWEIGHT
from modules.printer import PrinterDescriptor, LabelPrinter
# from modules.labels import PartLabel, SVG_FONTWEIGHT, SVG_COLOR, LabelDescriptor, PrinterDescriptor
from enum import Enum
from typing import Any, ClassVar, Final
import re

class UserMessageStatus:
    OK:ClassVar[str]="OK"
    ERROR:ClassVar[str]="ERROR"
    WORNING:ClassVar[str]="WORNING"
    IDLE:ClassVar[str]=""

class UserMessage:
    message:str
    status:str
    def __init__(self, message:str, status:str):
        self.message = message
        self.status = status
    
    def getStatus(self)->str:
        return self.status
    
    def getMessage(self)->str:
        return self.message

class UserMessages:
    USER_MESSAGE_TIMEOUT_MS:ClassVar[int] = 1000
    OK :ClassVar[UserMessage] = UserMessage("Ok", UserMessageStatus.OK)
    BARCODE_UNKNOW :ClassVar[UserMessage] = UserMessage("Bar code unknow", UserMessageStatus.ERROR)
    BARCODE_OK :ClassVar[UserMessage] = UserMessage("Zeskanowano poprawny barcode", UserMessageStatus.OK)
    PART_OK :ClassVar[UserMessage] = UserMessage("Znaleziono komponent", UserMessageStatus.OK)
    PART_ERROR :ClassVar[UserMessage] = UserMessage("Nie znaleziono komponentu", UserMessageStatus.WORNING)
    PART_UPDATE_OK :ClassVar[UserMessage] = UserMessage("Znaleziono komponent", UserMessageStatus.OK)
    PART_UPDATE_ERROR :ClassVar[UserMessage] = UserMessage("Nie znaleziono komponentu", UserMessageStatus.WORNING)
    FILE_SAVED_OK: ClassVar[UserMessage] = UserMessage("Plik zapisany prawidłowo", UserMessageStatus.OK)
    FILE_SAVED_ERROR: ClassVar[UserMessage] = UserMessage("Błąd przy zapisie pliku", UserMessageStatus.ERROR)
    FILE_LOAD_OK: ClassVar[UserMessage] = UserMessage("Plik wczytany prawidłowo", UserMessageStatus.OK)
    FILE_LOAD_ERROR: ClassVar[UserMessage] = UserMessage("Błąd przy wczytywaniu pliku", UserMessageStatus.ERROR)
    PID_FIND_OK: ClassVar[UserMessage] = UserMessage("Znaleziono element Pid", UserMessageStatus.OK)
    PID_FIND_ERR: ClassVar[UserMessage] = UserMessage("Nie znaleziono elementu Pid", UserMessageStatus.WORNING)
    
class PidPartsInventory(QAbstractTableModel):
    # colorError:ClassVar[QColor] = QColor(212, 101, 11, 50)
    # colorWorning:ClassVar[QColor] = QColor(240, 241, 137, 50)
    # colorOk:ClassVar[QColor] = QColor(9, 128, 17, 50)
    colorError:ClassVar[QColor] = QColor(200, 0, 0, 60)
    colorWorning:ClassVar[QColor] = QColor(0, 0, 127, 60)
    colorOk:ClassVar[QColor] = QColor(0, 127, 0, 60)

    itemData:list[PidPart]
    headerTableNames:list[str]
    #musi mieć taki sam wymiar jak "headerTableNames"
    columnCrossName:Final[list[str]]=["name", "mpn", "manufacturer", "footprint", "description", "quantity", "stockQuantity", "wasCounted"]
    
    suspendException:int

    def __init__(self, parent = None):
        super().__init__(parent)
        self.itemData = list()
        self.headerTableNames = ["PID", "MPN", "Manufacturer", "Footprint", "Description", \
                                       "Stock", "Magazin", "Status"]
        self.suspendException = 0
    
    def __len__(self)->int:
        return len(self.itemData)
    
    def setSuspendException(self, suspend:int|bool)->None:
        if isinstance(suspend, bool):
            self.suspendException = 1
        elif isinstance(suspend, int):
            self.suspendException = suspend

    def __getitem__(self, keyIndex:str|int)->PidPart|None:
        if isinstance(keyIndex, int):
            if keyIndex < len(self.itemData):
                return self.itemData[keyIndex]
            else:
                if self.suspendException > 0:
                    self.suspendException -= 1
                    return None
                else: raise IndexError(keyIndex)
        elif isinstance(keyIndex, str):
            index = self.getIndex(keyIndex)
            if index < 0:
                if self.suspendException > 0:
                    self.suspendException -= 1
                    return None
                raise KeyError(keyIndex)
            return self.itemData[index]
    
    def rowCount(self, index)->int:
        return len(self.itemData)

    def columnCount(self, /, parent = ...):
        return len(self.headerTableNames)
    
    def updateHeaderNames(self, names:list[str])->None:
        self.data
        self.beginResetModel()
        self.headerTableNames = names
        self.endResetModel()
    
    def headerData(self, section, orientation, role):
        if role == Qt.ItemDataRole.DisplayRole:
            if orientation == Qt.Orientation.Horizontal:
                return self.headerTableNames[section] if section < len(self.headerTableNames) else None
            elif orientation == Qt.Orientation.Vertical:
                return str(section + 1)

    def data(self, index:QModelIndex|QPersistentModelIndex, role:int)->Any|None:
        if role == Qt.ItemDataRole.DisplayRole:
            if index.row() >= len(self.itemData) or index.column() >= len(self.columnCrossName): return None
            val = self.itemData[index.row()][self.columnCrossName[index.column()]]
            if isinstance(val, bool):
                if val:
                    val = "I"
                else:
                    val = "N"
            return val
        elif role == Qt.ItemDataRole.DecorationRole:
            if index.row() >= len(self.itemData) or index.column() != 0: return None
            return None#QColor(255, 0, 0, 10)
        elif role == Qt.ItemDataRole.BackgroundRole:
            if index.row() >= len(self.itemData) or index.column() >= len(self.columnCrossName): return None
            if self.itemData[index.row()].wasCounted:
                if self.itemData[index.row()].quantity == 0:
                    return self.colorWorning
                else:
                    return self.colorOk
            return self.colorError
        return None
    #column: int, /, order: PySide6.QtCore.Qt.SortOrder
    def sort(self, column:int, /, order:Qt.SortOrder = ...)->None:
        rev = (order == Qt.SortOrder.DescendingOrder)
        keyLambda = None
        if column == 0:
            keyLambda = lambda part: part.name
        elif column == 1:
            keyLambda = lambda part: part.mpn
        elif column == 2:
            keyLambda = lambda part: part.manufacturer
        elif column == 3:
            keyLambda = lambda part: part.footprint
        elif column == 5:
            keyLambda = lambda part: part.quantity
        elif column == 6:
            keyLambda = lambda part: part.stockQuantity
        elif column == 7:
            keyLambda = lambda part: part.wasCounted

        if keyLambda is None: return

        self.itemData.sort(key=keyLambda, reverse=rev)
        self.layoutChanged.emit()
        # return super().sort(column, order)
    
    def append(self, value:PidPart|list[PidPart])->None:
        row = len(self.itemData)
        if isinstance(value, PidPart):
            self.beginInsertRows(QModelIndex(), row, row)
            self.itemData.append(value)
            self.endInsertRows()
        elif isinstance(value, list):
            self.beginInsertRows(QModelIndex(), row, row + len(value) - 1)
            self.itemData.extend(value)
            self.endInsertRows()
    
    def setPartQuantity(self, pid:str, quantity:int)->int:
        ind = self.getIndex(pid)
        if ind < 0: return -1
        self.beginResetModel()
        self.itemData[ind].wasCounted = True
        self.itemData[ind].quantity = quantity
        self.endResetModel()
        return ind
    
    def addPartQuantity(self, pid:str, quantity:int)->int:
        ind = self.getIndex(pid)
        if ind < 0: return -1
        self.beginResetModel()
        self.itemData[ind].wasCounted = True
        self.itemData[ind].quantity = self.itemData[ind].quantity + quantity
        self.endResetModel()
        return ind

    def getPart(self, pid:str)->PidPart|None:
        ind = self.getIndex(pid)
        if ind < 0: return None
        return self.itemData[ind]
    
    def getIndex(self, pid:str)->int:
        retInd:int = -1
        for i in range(0, len(self.itemData)):
            if self.itemData[i].name == pid:
                retInd = i
                break
        return retInd

    def appendSelective(self, value:PidPart|list[PidPart])->None:
        index:int = -1
        if isinstance(value, PidPart):
            index = self.getIndex(value.name)
            if index < 0:
                self.append(value)
                return
            if self.itemData[index].wasCounted: return
            self.itemData[index].quantity = value.quantity
            self.itemData[index].wasCounted = value.wasCounted
        elif isinstance(value, list):
            for part in value:
                index = self.getIndex(part.name)
                if index < 0:
                    self.append(part)
                    continue
                if self.itemData[index].wasCounted: continue
                self.itemData[index].quantity = part.quantity
                self.itemData[index].wasCounted = part.wasCounted


class PidInventoryWindow(QMainWindow):
    appMenagment:AppMenagment
    appSettings:AppSettings
    # projectsList:list[PartsBoxProject]|None
    partsBoxWrapper:PartsBoxWrapper|None
    # pidPartsBoxContent:list[PidPart]|None
    pidPartsInventory:PidPartsInventory
    currentPidPart:PidPart
    currentSvgLabelPid:str|None
    userMessageBoxTimer:QTimer
    currentPrinterDescriptor: PrinterDescriptor|None
    currentLabelDescriptor: LabelDescriptor|None
    # currentLabelPrinter:LabelPrinter
    tableAutoSelection:bool

    def __init__(self, parent: QWidget | None, appMenagment:AppMenagment) -> None:
        super().__init__(parent)
        self.appMenagment = appMenagment
        self.appSettings = self.appMenagment.getAppSettings()
        self.partsBoxWrapper = None
        self.currentPrinterDescriptor = None
        self.currentLabelDescriptor = None
        self.currentSvgLabelPid = None
        self.pidPartsInventory = PidPartsInventory(self)
        # if self.appSettings is None: exit(0)
        self.prepareLayout()
        self.updateLayoutValues()
        self.updateToolTipValues()
        svgFocusIn = self.appSettings.getSvgPic("barcodeFocusIn")
        svgFocusOut = self.appSettings.getSvgPic("barcodeFocusOut")
        self.barcodeScanner.setSvgFocusPictures(svgFocusIn, svgFocusOut)
        self.lineEditQuantity.textChanged.connect(self.lineEditQuantityChanged)
        self.tableViewParts.setModel(self.pidPartsInventory)
        self.userMessageBoxTimer = QTimer(self)
        self.userMessageBoxTimer.setInterval(UserMessages.USER_MESSAGE_TIMEOUT_MS)
        self.userMessageBoxTimer.setSingleShot(True)
        self.userMessageBoxTimer.timeout.connect(self.userMessageBoxTimeoutEvent)
        self.appSettings.langSettingsChanged.connect(self.updateLayoutValues)
        self.appSettings.langSettingsChanged.connect(self.updateToolTipValues)
        self.buttonRefreshPartsBox.clicked.connect(self.refreshPartsBoxData)
        self.barcodeScanner.barCodeScanned.connect(self.barCodeScanned)
        self.buttonAdd.clicked.connect(self.buttonAddClicked)
        self.buttonUpdate.clicked.connect(self.buttonUpdateClicked)
        self.tableViewParts.selectionModel().selectionChanged.connect(self.tableViewPartsSelectionEvent)
        self.buttonSave.clicked.connect(self.buttonSavePressedEvent)
        self.buttonLoad.clicked.connect(self.buttonLoadPressEvent)
        self.lineEditQuantity.returnPressed.connect(self.lineEditQuantityEnterEvent)

        self.currentLabelDescriptor = self.appSettings.getCurrentParam(LabelDescriptor)
        self.currentPrinterDescriptor = self.appSettings.getCurrentParam(PrinterDescriptor)
        if isinstance(self.currentLabelDescriptor, LabelDescriptor) and isinstance(self.currentPrinterDescriptor, PrinterDescriptor):
            currentLabelPrinter = self.appMenagment.getLabelPrinter()
            currentLabelPrinter.setPrinterParam(self.currentPrinterDescriptor, self.currentLabelDescriptor)

        self.appSettings.anyParamChanged.connect(self.appCurrentParamchangedEvent)
        self.labelPid.doubleClickEvent.connect(self.labelPidDoubleClickEvent)
        self.lineEditFindPid.textChanged.connect(self.lineEditFindPidChangedEvent)
        self.buttonFind.clicked.connect(self.buttonFindClickedEvent)
        self.lineEditFindPid.returnPressed.connect(self.buttonFindEnterPresed)
        self.setCurrentPidPart(None)
        self.tableAutoSelection = False
    
    def appCurrentParamchangedEvent(self, key:str, paramObj:Any, isValid:bool)->None:
        if isinstance(paramObj, LabelDescriptor):
            self.currentLabelDescriptor = self.appSettings.getCurrentParam(LabelDescriptor)
            if isinstance(self.currentLabelDescriptor, LabelDescriptor) and isinstance(self.currentPrinterDescriptor, PrinterDescriptor):
                currentLabelPrinter = self.appMenagment.getLabelPrinter()
                currentLabelPrinter.setPrinterParam(self.currentPrinterDescriptor, self.currentLabelDescriptor)
        if isinstance(paramObj, PrinterDescriptor):
            self.currentPrinterDescriptor = self.appSettings.getCurrentParam(PrinterDescriptor)
            if isinstance(self.currentLabelDescriptor, LabelDescriptor) and isinstance(self.currentPrinterDescriptor, PrinterDescriptor):
                currentLabelPrinter = self.appMenagment.getLabelPrinter()
                currentLabelPrinter.setPrinterParam(self.currentPrinterDescriptor, self.currentLabelDescriptor)

    def prepareLayout(self)->None:
        ############################################ ROW 1
        # Edit Box Message
        self.lineEditMessage = QLineEdit("Message", self)
        self.lineEditMessage.setProperty('class', 'editLineMessage')
        self.lineEditMessage.setReadOnly(True)
        self.lineEditMessage.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        #Progress bar
        self.progressBarr = QProgressBar(self)
        self.progressBarr.setTextVisible(True)
        self.progressBarr.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.progressBarr.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        #layout H1 + container H1 !!!!!!!!!!!!
        containerH1 = QWidget(self)
        containerH1.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)
        containerH1.setProperty('class', 'widgetBorder')
        layoutH1 = QHBoxLayout(containerH1)
        layoutH1.addWidget(self.lineEditMessage, 2)
        layoutH1.addWidget(self.progressBarr, 1)
        # layoutH1.addWidget(self.progressBarr, 1, Qt.AlignmentFlag.AlignRight)

        ############################################ ROW 2
        # Edit Box PID
        self.lineEditPid = QLineEdit("", self)
        self.lineEditPid.setReadOnly(True)
        self.lineEditPid.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.lineEditPid.setProperty('class', 'lineEditLargeFont')
        self.lineEditPid.setMaximumWidth(150)
        self.lineEditPid.setMinimumWidth(100)
        # Edit Box PID Description
        self.lineEditPidDescription = QLineEdit("", self)
        self.lineEditPidDescription.setReadOnly(True)
        self.lineEditPidDescription.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.lineEditPidDescription.setProperty('class', 'lineEditLargeFont')
        # Edit Box Quantity
        self.lineEditQuantity = QLineEdit("0", self)
        self.lineEditQuantity.setProperty('class', 'lineEditLargeFontQuantity')
        self.lineEditQuantity.setMaximumWidth(170)
        self.lineEditQuantity.setMinimumWidth(100)
        #layout H2 + container H2 !!!!!!!!!!!!!!
        containerH2 = QWidget(self)
        layoutH2 = QHBoxLayout(containerH2)
        layoutH2.addWidget(self.lineEditPid, 0, Qt.AlignmentFlag.AlignLeft)
        layoutH2.addWidget(self.lineEditPidDescription, 1)
        layoutH2.addWidget(self.lineEditQuantity, 0, Qt.AlignmentFlag.AlignRight)

        ############################################ ROW 3
        self.labelPid = QCScalledLabel2(False, self)
        self.labelPid.setMinimumHeight(200)
        self.labelPid.setMaximumWidth(400)
        # self.labelPid.setSvg("""<svg width="800px" height="800px" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
        #     <path fill-rule="evenodd" clip-rule="evenodd" d="M6.42436 0H9.57565L14.995 16H11.8276L10.8115 13H5.18855L4.17242 16H1.005L6.42436 0ZM6.20468 10H9.79533L8 4.69952L6.20468 10Z" fill="#000000"/>
        #     </svg>""")
        # self.labelPid = QWidget(self)
        # self.labelPid.setMinimumSize(50, 50)
        # self.labelPid.setProperty('class', 'widgetBorder')
        spacer1 = QWidget(self)
        # spacer1.setProperty('class', 'widgetTest')#LAYOUT DEBUG
        self.buttonAdd = QPushButton("Add", self)
        spacer2 = QWidget(self)
        # spacer2.setProperty('class', 'widgetTest')#LAYOUT DEBUG
        # self.barcodeScanner = QCScalledLabel2()
        self.barcodeScanner = QCBarcodeScannerWidget(self)
        # self.barcodeScanner.setProperty('class', 'widgetBorder')
        self.barcodeScanner.setMaximumWidth(300)
        #layout H3 + container H3
        containerH3 = QWidget(self)
        layoutH3 = QHBoxLayout(containerH3)
        containerH3.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)
        layoutH3.addWidget(self.labelPid, 3)
        layoutH3.addWidget(spacer1, 1)
        layoutH3.addWidget(self.buttonAdd, 0, Qt.AlignmentFlag.AlignBottom)
        layoutH3.addWidget(spacer2, 1)
        layoutH3.addWidget(self.barcodeScanner, 1)

        ############################################ ROW 6
        self.lineEditFindPid = QLineEdit("", self)
        self.buttonFind = QPushButton("Find", self)
        spacer6 = QWidget(self)
        # spacer6.setProperty('class', 'widgetTest')#LAYOUT DEBUG
        containerH6 = QWidget(self)
        # containerH6.setProperty('class', 'widgetTest')#LAYOUT DEBUG
        layoutH6 = QHBoxLayout(containerH6)
        layoutH6.setContentsMargins(10, 10, 10, 0) #left top right bottom
        layoutH6.setSpacing(2)
        layoutH6.addWidget(self.lineEditFindPid, 0)
        layoutH6.addWidget(self.buttonFind, 0)
        layoutH6.addWidget(spacer6, 1)
        ############################################ ROW 4
        self.tableViewParts = QTableView(self)
        self.tableViewParts.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)#SelectRows
        self.tableViewParts.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tableViewParts.setSortingEnabled(True)
        self.buttonRemove = QPushButton("Remove", self) 
        self.buttonUpdate = QPushButton("Update", self)
        spacer3 = QWidget(self)
        # spacer3.setProperty('class', 'widgetTest')#LAYOUT DEBUG
        #layout V3 + container V3 !!!!!!!!!!!!
        containerV3 = QWidget(self)
        layoutV3 = QVBoxLayout(containerV3)
        layoutV3.addWidget(self.buttonRemove, 0, Qt.AlignmentFlag.AlignTop)
        layoutV3.addWidget(self.buttonUpdate, 0, Qt.AlignmentFlag.AlignTop)
        layoutV3.addWidget(spacer3, 1)
        #layout H4 + container H4 !!!!!!!!!!!!
        containerH4 = QWidget(self)
        # containerH4.setProperty('class', 'widgetTest')#LAYOUT DEBUG
        layoutH4 = QHBoxLayout(containerH4)
        layoutH4.setContentsMargins(10, 1, 10, 10) #left top right bottom
        layoutH4.setSpacing(2)
        # layoutH4.addWidget(self.tableViewParts, 1, Qt.AlignmentFlag.AlignLeft)
        layoutH4.addWidget(self.tableViewParts, 1)
        layoutH4.addWidget(containerV3, 0)

        ############################################ ROW 2+3+4
        #layout V2 + container V2 !!!!!!!!!!!!
        containerV2 = QWidget(self)
        containerV2.setProperty('class', 'widgetBorder')
        layoutV2 = QVBoxLayout(containerV2)
        layoutV2.setSpacing(2)
        layoutV2.addWidget(containerH2, 0, Qt.AlignmentFlag.AlignTop)
        layoutV2.addWidget(containerH3, 0, Qt.AlignmentFlag.AlignTop)
        layoutV2.addWidget(containerH6, 0, Qt.AlignmentFlag.AlignTop)
        layoutV2.addWidget(containerH4, 4)

        ############################################ ROW 4
        self.buttonSave = QPushButton("Save", self)
        self.buttonLoad = QPushButton("Load", self)
        spacer4 = QWidget(self)
        # spacer4.setProperty('class', 'widgetTest')#LAYOUT DEBUG
        self.buttonRefreshPartsBox = QPushButton("Refresh\nPartsBox", self)
        self.buttonToPartsBox = QPushButton("To\nPartsBox", self)
        #layout H5 + container H5 !!!!!!!!!!!!
        containerH5 = QWidget(self)
        layoutH5 = QHBoxLayout(containerH5)
        layoutH5.addWidget(self.buttonSave, 0, Qt.AlignmentFlag.AlignLeft)
        layoutH5.addWidget(self.buttonLoad, 0, Qt.AlignmentFlag.AlignLeft)
        layoutH5.addWidget(spacer4, 1)
        layoutH5.addWidget(self.buttonRefreshPartsBox, 0, Qt.AlignmentFlag.AlignRight)
        layoutH5.addWidget(self.buttonToPartsBox, 0, Qt.AlignmentFlag.AlignRight)

        ############################################ Main Widget
        #layout V1 + container V1 !!!!!!!!!!!!
        self.containerV1 = QWidget(self)
        layoutV1 = QVBoxLayout()
        layoutV1.addWidget(containerH1, 0, Qt.AlignmentFlag.AlignTop)
        layoutV1.addWidget(containerV2, 1)
        layoutV1.addWidget(containerH5, 0, Qt.AlignmentFlag.AlignTop)
        # self.mainWidget = QWidget(self)
        self.containerV1.setLayout(layoutV1)
        self.setCentralWidget(self.containerV1)

    def updateToolTipValues(self)->None:
        self.buttonAdd.setToolTip(self.appSettings.tr(self, "buttonAdd.ToolTip"))
        self.buttonFind.setToolTip(self.appSettings.tr(self, "buttonFind.ToolTip"))
        self.buttonRemove.setToolTip(self.appSettings.tr(self, "buttonRemove.ToolTip"))
        self.buttonUpdate.setToolTip(self.appSettings.tr(self, "buttonUpdate.ToolTip"))
        self.barcodeScanner.setToolTip(self.appSettings.tr(self, "barcodeScanner.ToolTip"))
        self.buttonLoad.setToolTip(self.appSettings.tr(self, "buttonLoad.ToolTip"))
        self.buttonSave.setToolTip(self.appSettings.tr(self, "buttonSave.ToolTip"))
        self.buttonRefreshPartsBox.setToolTip(self.appSettings.tr(self, "buttonRefreshPartsBox.ToolTip"))
        self.buttonToPartsBox.setToolTip(self.appSettings.tr(self, "buttonToPartsBox.ToolTip"))
        self.lineEditFindPid.setToolTip(self.appSettings.tr(self, "lineEditFindPid.ToolTip"))
        self.lineEditQuantity.setToolTip(self.appSettings.tr(self, "lineEditQuantity.ToolTip"))
        self.labelPid.setToolTip(self.appSettings.tr(self, "labelPid.ToolTip"))

    def updateLayoutValues(self)->None:
        self.setWindowTitle(self.appSettings.tr(self.appSettings.SETTINGS_TYPE.GLOBAL,\
                                                self.appSettings.SETTINGS_TYPE.APP_NAME))
        self.buttonAdd.setText(self.appSettings.tr(self, "buttonAdd"))
        self.buttonRemove.setText(self.appSettings.tr(self, "buttonRemove"))
        self.buttonUpdate.setText(self.appSettings.tr(self, "buttonUpdate"))
        self.buttonSave.setText(self.appSettings.tr(self, "buttonSave"))
        self.buttonLoad.setText(self.appSettings.tr(self, "buttonLoad"))
        self.buttonRefreshPartsBox.setText(self.appSettings.tr(self, "buttonRefreshPartsBox"))
        self.buttonToPartsBox.setText(self.appSettings.tr(self, "buttonToPartsBox"))
        self.labelPid.setSubText(self.appSettings.tr(self, "labelPid.A"),
                                    self.appSettings.tr(self, "labelPid.M"))
        self.buttonFind.setText(self.appSettings.tr(self, "buttonFind"))
        tableHeaderName = [
            self.appSettings.tr(self, "tableViewParts.A"),
            self.appSettings.tr(self, "tableViewParts.B"),
            self.appSettings.tr(self, "tableViewParts.C"),
            self.appSettings.tr(self, "tableViewParts.D"),
            self.appSettings.tr(self, "tableViewParts.E"),
            self.appSettings.tr(self, "tableViewParts.F"),
            self.appSettings.tr(self, "tableViewParts.G"),
            self.appSettings.tr(self, "tableViewParts.H")]
        self.pidPartsInventory.updateHeaderNames(tableHeaderName)

        UserMessages.OK.message = self.appSettings.tr(self, "UserMessages.OK")
        UserMessages.BARCODE_UNKNOW.message = self.appSettings.tr(self, "UserMessages.BARCODE_UNKNOW")
        UserMessages.BARCODE_OK.message = self.appSettings.tr(self, "UserMessages.BARCODE_OK")
        UserMessages.PART_OK.message = self.appSettings.tr(self, "UserMessages.PART_OK")
        UserMessages.PART_ERROR.message = self.appSettings.tr(self, "UserMessages.PART_ERROR")
        UserMessages.FILE_SAVED_OK.message = self.appSettings.tr(self, "UserMessages.FILE_SAVED_OK")
        UserMessages.FILE_SAVED_ERROR.message = self.appSettings.tr(self, "UserMessages.FILE_SAVED_ERROR")
        UserMessages.FILE_LOAD_OK.message = self.appSettings.tr(self, "UserMessages.FILE_LOAD_OK")
        UserMessages.FILE_LOAD_ERROR.message = self.appSettings.tr(self, "UserMessages.FILE_LOAD_ERROR")
        UserMessages.PART_UPDATE_OK.message = self.appSettings.tr(self, "UserMessages.PART_UPDATE_OK")
        UserMessages.PART_UPDATE_ERROR.message = self.appSettings.tr(self, "UserMessages.PART_UPDATE_ERROR")
        UserMessages.PID_FIND_OK.message = self.appSettings.tr(self, "UserMessages.PID_FIND_OK")
        UserMessages.PID_FIND_ERR.message = self.appSettings.tr(self, "UserMessages.PID_FIND_ERR")

    def setLayoutEnabled(self, enabled:bool = True)->None:
        self.buttonAdd.setEnabled(enabled)
        self.buttonRemove.setEnabled(enabled)
        self.buttonUpdate.setEnabled(enabled)
        self.buttonSave.setEnabled(enabled)
        self.buttonLoad.setEnabled(enabled)
        self.buttonRefreshPartsBox.setEnabled(enabled)
        self.buttonToPartsBox.setEnabled(enabled)
        self.tableViewParts.setEnabled(enabled)

    def slot_getAllPidPartsDone(self, isSucess:bool, message:str)->None:
        self.partsBoxWrapper.getAllPidPartsDone.disconnect(self.slot_getAllPidPartsDone)
        self.progressBarr.setMaximum(1)
        self.progressBarr.reset()
        self.setLayoutEnabled(True)
        if isSucess:
            self.partsBoxWrapper = self.appMenagment.getPartsBoxWrapper()
            ret = self.partsBoxWrapper.getPidPartsRet()
            self.pidPartsInventory.appendSelective(ret)
    
    def refreshPartsBoxData(self)->None:
        self.partsBoxWrapper = self.appMenagment.getPartsBoxWrapper()
        if self.partsBoxWrapper is None: return
        self.setLayoutEnabled(False)
        self.partsBoxWrapper.getAllPidPartsDone.connect(self.slot_getAllPidPartsDone)
        self.progressBarr.setMinimum(0)
        self.progressBarr.setMaximum(0)
        self.progressBarr.setFormat("Collecting PIDs data")
        self.partsBoxWrapper.startGetAllPidParts()

    def printLabel(self, part:PidPart|None)->None:
        if self.currentLabelDescriptor is None: return
        if part is None: return
        labelPidContentList=[
            "PidItemData",
            [
                [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.BOLD, False, part.name],
                [PartLabel.LABEL_CONTENT_ITEM_TYPE_BAR, SVG_FONTWEIGHT.NORMAL, False, part.name],
                [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.BOLD, False, part.mpn],
                [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, False, part.manufacturer]
            ]
        ]
        if isinstance(part.sds, list):
            if len(part.sds) == 1:
                labelPidContentList[1].append([PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, True, part.sds[0]])
            elif len(part.sds) > 1:
                labelPidContentList[1].append([PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, True, part.sds[0]])
                labelPidContentList[1].append([PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, False, part.sds[1]])
        else:
            labelPidContentList[1].append([PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, True, "Null"])
        
        labelGenerator = PartLabel()
        labelGenerator.setLabelSize(QSizeF(self.currentLabelDescriptor.width, self.currentLabelDescriptor.height))
        labelGenerator.setLabelMargin(self.currentLabelDescriptor.margin)
        labelGenerator.setIconColors(SVG_COLOR.BLACK, SVG_COLOR.NONE)
        printableLabel = labelGenerator.getSvgLabel(labelPidContentList, False)
        currentLabelPrinter = self.appMenagment.getLabelPrinter()
        currentLabelPrinter.printLabel(printableLabel)

    def updatePidlabel(self, part:PidPart|None)->None:
        if self.currentLabelDescriptor is None: return
        # if self.currentPrinterDescriptor is None: return
        if part is None:
            labelPidContentList=[
                "PidItemData",
                [
                    [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.BOLD, False, " "],
                    [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, False, " "],
                    [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.BOLD, False, " "],
                    [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, False, " "],
                    [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, True, " "],
                    [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, False, " "]
                ]
            ]
        else:
            labelPidContentList=[
                "PidItemData",
                [
                    [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.BOLD, False, part.name],
                    [PartLabel.LABEL_CONTENT_ITEM_TYPE_BAR, SVG_FONTWEIGHT.NORMAL, False, part.name],
                    [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.BOLD, False, part.mpn],
                    [PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, False, part.manufacturer]
                ]
            ]
            if isinstance(part.sds, list):
                if len(part.sds) == 1:
                    labelPidContentList[1].append([PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, True, part.sds[0]])
                elif len(part.sds) > 1:
                    labelPidContentList[1].append([PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, True, part.sds[0]])
                    labelPidContentList[1].append([PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, False, part.sds[1]])
            else:
                labelPidContentList[1].append([PartLabel.LABEL_CONTENT_ITEM_TYPE_TXT, SVG_FONTWEIGHT.NORMAL, True, "Null"])

        labelGenerator = PartLabel()
        labelGenerator.setLabelSize(QSizeF(self.currentLabelDescriptor.width, self.currentLabelDescriptor.height))
        labelGenerator.setLabelMargin(self.currentLabelDescriptor.margin)
        labelGenerator.setIconColors(SVG_COLOR.BLACK, SVG_COLOR.CORAL)
        self.currentSvgLabelPid = labelGenerator.getSvgLabel(labelPidContentList, True)
        self.labelPid.setSvg(self.currentSvgLabelPid)

    def labelPidDoubleClickEvent(self, isAuto:bool)->None:
        self.printLabel(self.currentPidPart)

    def fillPartInfoField(self, part:PidPart|None)->None:
        # if self.pidPartsBoxContent is None: return
        # if (ind <= 0) or (ind >= len(self.pidPartsBoxContent)): return
        if part is None:
            self.lineEditPid.setText("")
            self.lineEditPidDescription.setText("")
            self.lineEditQuantity.setText("")
            return
        
        self.lineEditPid.setText(part.name)
        self.lineEditPidDescription.setText(part.description)
        self.lineEditQuantity.setText("")
        # self.lineEditQuantity.setFocus(Qt.FocusReason.OtherFocusReason)

    def barCodeScanned(self, txt:str)->None:
        mat = re.findall(r"#[a-zA-Z]{1,3}[0-9]{1,7}[a-zA-z]?", txt)
        if not(isinstance(mat, list) and len (mat)>0):
            self.displayMessage(UserMessages.BARCODE_UNKNOW)
        else:
            self.displayMessage(UserMessages.BARCODE_OK)
        partIndex = self.pidPartsInventory.getIndex(txt)
        if partIndex >= 0:
            part = self.pidPartsInventory[partIndex]
        else:
            part = None
        if not part is None:
            self.tablePartSelectItem(partIndex)
            self.lineEditQuantity.setFocus(Qt.FocusReason.OtherFocusReason)
        self.setCurrentPidPart(part)
    
    def userMessageBoxTimeoutEvent(self)->None:
        self.lineEditMessage.setProperty("subStyle", UserMessageStatus.IDLE)
        self.lineEditMessage.style().unpolish(self.lineEditMessage)
        self.lineEditMessage.style().polish(self.lineEditMessage)
    
    def displayMessage(self, message:UserMessage)->None:
        self.lineEditMessage.setText(message.getMessage())
        self.lineEditMessage.setProperty("subStyle", message.getStatus())
        self.lineEditMessage.style().unpolish(self.lineEditMessage)
        self.lineEditMessage.style().polish(self.lineEditMessage)
        if self.userMessageBoxTimer.isActive():
            self.userMessageBoxTimer.stop()
            self.userMessageBoxTimer.setInterval(UserMessages.USER_MESSAGE_TIMEOUT_MS)
        self.userMessageBoxTimer.start()
    
    def lineEditFindPidChangedEvent(self, txt:str)->None:
        if len(txt) == 0: return
        txt = str.upper(txt)
        if txt[0] != "#":
            txt = "#" + txt
        mat = re.findall(r"#+[a-zA-Z]{0,3}[0-9]{0,7}[a-zA-Z]?", txt)
        if (isinstance(mat, list) and len (mat)>0):
            self.lineEditFindPid.setText(mat[0])
        else:
            self.lineEditFindPid.setText("")

    def buttonFindEnterPresed(self)->None:
        self.buttonFindClickedEvent()

    def buttonFindClickedEvent(self)->None:
        pidTxt = self.lineEditFindPid.text()
        partIndex = self.pidPartsInventory.getIndex(pidTxt)
        if partIndex < 0:
            self.displayMessage(UserMessages.PID_FIND_ERR)
            return
        self.displayMessage(UserMessages.PID_FIND_OK)
        self.tablePartSelectItem(partIndex, False)
        
    def lineEditQuantityChanged(self, text:str)->None:
        """Validate input in quantity line edit to ensure it is numeric."""
        # temp = re.sub(r'[^0-9]', '', text)
        nt:str = ""
        # temp = re.search(r'(0?)([1-9][0-9]*)?', text)
        temp = re.search(r'(0)?([1-9][0-9]*)?', text)
        temp = temp.groups()
        if temp[0] is not None:
            nt = temp[0]
        if temp[1] is not None:
            nt = temp[1]
        self.sender().setText(nt)
        # self.updateStylesheetOnWidget(self.sender(), False) [1-9][0-9]*
    
    def buttonAddClicked(self)->None:
        quantityTxt = self.lineEditQuantity.text()
        if not str.isnumeric(quantityTxt): quantityTxt = "0"
        quantity = int(quantityTxt)
        pid = self.lineEditPid.text()
        part = self.pidPartsInventory.getPart(pid)
        # self.setCurrentPidPart(part)
        if part is None:
            self.displayMessage(UserMessages.PART_ERROR)
            return
        self.displayMessage(UserMessages.PART_OK)

        insertedIndex = self.pidPartsInventory.addPartQuantity(pid, quantity)
        if insertedIndex < 0: return
        self.lineEditQuantity.setText("")
        self.barcodeScanner.setFocus(Qt.FocusReason.ShortcutFocusReason)
        curIndexStart = self.tableViewParts.verticalScrollBar().sliderPosition()
        currentIndexEnd = curIndexStart + self.tableViewParts.verticalScrollBar().pageStep()
        if insertedIndex in range(curIndexStart, currentIndexEnd): return

        tableViewMaxIndex = self.tableViewParts.verticalScrollBar().maximum()
        insertedIndex = min(tableViewMaxIndex, insertedIndex)
        self.tableViewParts.verticalScrollBar().setSliderPosition(insertedIndex)
    
    def buttonUpdateClicked(self)->None:
        quantityTxt = self.lineEditQuantity.text()
        if not str.isnumeric(quantityTxt): quantityTxt = "0"
        quantity = int(quantityTxt)
        pid = self.lineEditPid.text()
        part = self.pidPartsInventory.getPart(pid)
        # self.setCurrentPidPart(part)
        if part is None:
            self.displayMessage(UserMessages.PART_UPDATE_ERROR)
            return
        self.displayMessage(UserMessages.PART_UPDATE_OK)
        self.barcodeScanner.setFocus(Qt.FocusReason.ShortcutFocusReason)
        insertedIndex = self.pidPartsInventory.setPartQuantity(pid, quantity)
        if insertedIndex < 0: return
        self.lineEditQuantity.setText("")
        self.barcodeScanner.setFocus(Qt.FocusReason.ShortcutFocusReason)
        curIndexStart = self.tableViewParts.verticalScrollBar().sliderPosition()
        currentIndexEnd = curIndexStart + self.tableViewParts.verticalScrollBar().pageStep()
        if insertedIndex in range(curIndexStart, currentIndexEnd): return

        tableViewMaxIndex = self.tableViewParts.verticalScrollBar().maximum()
        insertedIndex = min(tableViewMaxIndex, insertedIndex)
        self.tableViewParts.verticalScrollBar().setSliderPosition(insertedIndex)

    def lineEditQuantityEnterEvent(self)->None:
        self.buttonAddClicked()
        
    def setCurrentPidPart(self, part:PidPart|None)->None:
        self.currentPidPart = part
        self.fillPartInfoField(self.currentPidPart)
        self.updatePidlabel(self.currentPidPart)

    def tableViewPartsSelectionEvent(self, selected :QItemSelection, deselected:QItemSelection):
        if self.tableAutoSelection:
            self.tableAutoSelection = False
            return
        if len(selected.indexes()) <= 0: return
        selRowIndex = selected.indexes()[0].row()
        # print(selRowIndex)
        self.pidPartsInventory.setSuspendException(True)
        part = self.pidPartsInventory[selRowIndex]
        self.setCurrentPidPart(part)
        
    def buttonLoadPressEvent(self)->None:
        fileName = QFileDialog.getOpenFileName(self, filter="JSON (*.json)")
        if len(fileName[0]) < 4: return
        ret = self.loadFromFile(fileName[0])
        if ret:
            self.displayMessage(UserMessages.FILE_LOAD_OK)
        else:
            self.displayMessage(UserMessages.FILE_LOAD_ERROR)

    def buttonSavePressedEvent(self)->None:
        fileName = QFileDialog.getSaveFileName(self, filter="JSON (*.json)")
        if len(fileName[0]) < 4: return
        ret = self.saveToFile(fileName[0])
        if ret:
            self.displayMessage(UserMessages.FILE_SAVED_OK)
        else:
            self.displayMessage(UserMessages.FILE_SAVED_ERROR)

    def loadFromFile(self, fileName:str)->bool:
        import json
        ret = True
        fullJson = None
        try:
            f = open(file=fileName, mode="r", encoding='utf-8')
            fullJson = json.load(f)
        except:
            ret = False
            fullJson = None
        finally:
            f.close()
        if fullJson is None: return ret
        for item in fullJson:
            tObj:PidPart|None = PidPart.fromFileJson(item)
            if tObj is None:
                ret = False
                continue
            self.pidPartsInventory.appendSelective(tObj)

        return ret

    def saveToFile(self, fileName:str)->bool:
        ret = True
        size = len(self.pidPartsInventory.itemData)
        if size < 1: return False
        try:
            f = open(file=fileName, mode="w", encoding='utf-8')
            f.write('[\n')
            for i in range(0, size):
                _part:PidPart = self.pidPartsInventory.itemData[i]
                lineTxt = _part.toFileJson()
                if lineTxt is None:
                    ret = False
                    continue
                if i < (size-1): lineTxt += ",\n"
                f.write(lineTxt)
            f.write(']\n')
        except:
            ret = False
        finally:
            f.close()
        return ret

    def tablePartSelectItem(self, index:int, singleLock:bool=True):
        self.tableAutoSelection = singleLock
        scrollIndex = index
        scrollIndexStart = self.tableViewParts.verticalScrollBar().sliderPosition()
        scrollIndexEnd = scrollIndexStart + self.tableViewParts.verticalScrollBar().pageStep()
        if not (index in range(scrollIndexStart, scrollIndexEnd)):
            tableViewMaxIndex = self.tableViewParts.verticalScrollBar().maximum()
            scrollIndex = scrollIndex - int(self.tableViewParts.verticalScrollBar().pageStep()/2)
            if scrollIndex < 0: scrollIndex = 0
            scrollIndex = min(tableViewMaxIndex, scrollIndex)
            self.tableViewParts.verticalScrollBar().setSliderPosition(scrollIndex)

        self.tableViewParts.selectRow(index)