from PySide6.QtCore import (QObject, QAbstractTableModel, QAbstractItemModel,
                            QModelIndex, Qt, Signal, QDate, QThreadPool, QRunnable, Slot)
from PySide6.QtGui import QPixmap, QImage
from queue import Queue
# from threading import Thread
from typing import Any, ClassVar, Final, Self
from enum import Enum
import requests
# import json
# import re
# import time
# import hashlib
# import secrets
import copy

import json



class PidPart(QObject):
    MAPING_LIST:ClassVar[list[str]] = ["uuid", "name", "mpn", "manufacturer", "description", "sds", \
                                       "footprint", "quantity", "stockQuantity", "wasCounted"]
    MAPING_JSON_SIMPLE:ClassVar[dict[str, str]] = {"part/name": "name", "part/mpn":"mpn", "part/manufacturer":"manufacturer",\
                                              "part/description": "description", "part/footprint": "footprint"}
    uuid:str|None
    name:str|None
    mpn:str|None
    manufacturer:str|None
    description:str|None
    sds:list[str]|None
    footprint:str|None
    quantity:int
    stockQuantity:int
    wasCounted:bool

    def __init__(self,  uuid:str|None = None, parent =None):
        super().__init__(parent)
        self.uuid = uuid
        self.name = None
        self.mpn = None
        self.manufacturer = None
        self.description = None
        self.sds = None
        self.footprint = None
        self.quantity = 0
        self.stockQuantity = 0
        self.wasCounted = False

    @staticmethod
    def getPartFullStock(stockList:list[dict])->int:
        stockSum:int = 0
        for stock in stockList:
            if not isinstance(stock, dict): continue
            t = stock.get('stock/quantity', 0)
            if not isinstance(t, int): continue
            stockSum += t
        return stockSum

    @classmethod
    def fromPartJson(cls, data:dict|None)->Self|None:
        if data is None: return None
        tempItem = data.get("part/id", None)
        if not isinstance(tempItem, str): return None
        tObj:PidPart = cls(tempItem)
        for tag, name in PidPart.MAPING_JSON_SIMPLE.items():
            tempItem = data.get(tag, None)
            if tempItem is None: continue
            setattr(tObj, name, tempItem)
        tempData = data.get('part/custom-fields', None)
        if isinstance(tempData, list):
            tempItem:list[str] = list()
            for i in tempData:
                t = i.get('key', "")
                if t == 'SDS_1':
                    tempItem.append(i.get('value', "PB Null"))
                if t == 'SDS_2':
                    tempItem.append(i.get('value', "PB Null"))
            if len(tempItem) > 0:
                tObj.sds = tempItem
        tempData = data.get('part/stock', [])
        if len(tempData) > 0:
            tObj.stockQuantity = PidPart.getPartFullStock(tempData)
        return tObj
    
    # mpn manufacturer description sds footprint quantity stockQuantity wasCounted
    @classmethod
    def fromFileJson(cls, data:dict|None)->Self|None:
        if not isinstance(data, dict): return None

        temp = data.get("uuid", None)
        if not isinstance(temp, str): return None
        tObj:PidPart = cls(temp)

        temp = data.get("name", None)
        if not isinstance(temp, str): return None
        tObj.name = temp

        temp = data.get("mpn", None)
        if not isinstance(temp, str): return None
        tObj.mpn = temp

        temp = data.get("manufacturer", None)
        if not isinstance(temp, str): return None
        tObj.manufacturer = temp

        temp = data.get("description", "None")
        if not isinstance(temp, str): return None
        tObj.description = temp

        """allow NULL for some of parts in partsBox"""
        temp = data.get("sds", None)
        # if not isinstance(temp, list): return None
        tObj.sds = temp

        temp = data.get("footprint", "None")
        if not isinstance(temp, str): return None
        tObj.footprint = temp

        temp = data.get("quantity", None)
        if not isinstance(temp, int): return None
        tObj.quantity = temp

        temp = data.get("stockQuantity", None)
        if not isinstance(temp, int): return None
        tObj.stockQuantity = temp

        temp = data.get("wasCounted", None)
        if not isinstance(temp, bool): return None
        tObj.wasCounted = temp

        return tObj
    
    def __deepcopy__(self, memo)->Self:
        return self.__copy__()
    
    def __copy__(self)->Self:
        copyObj = PidPart(self.uuid)
        copyObj.name = self.name
        copyObj.mpn = self.mpn
        copyObj.manufacturer = self.manufacturer
        copyObj.description = self.description
        copyObj.sds = copy.deepcopy(self.sds)
        copyObj.footprint = self.footprint
        copyObj.quantity = self.quantity
        copyObj.stockQuantity = self.stockQuantity
        copyObj.wasCounted = self.wasCounted
        return copyObj
    
    def copy(self)->Self:
        return self.__copy__()
    
    def toFileJson(self)->str|None:
        tempDict = dict()
        tempDict["uuid"] = self.uuid
        tempDict["name"] = self.name
        tempDict["mpn"] = self.mpn
        tempDict["manufacturer"] = self.manufacturer
        tempDict["description"] = self.description
        tempDict["sds"] = self.sds
        tempDict["footprint"] = self.footprint
        tempDict["quantity"] = self.quantity
        tempDict["stockQuantity"] = self.stockQuantity
        tempDict["wasCounted"] = self.wasCounted
        txt = None
        try:
            txt = json.dumps(tempDict, indent=0)
        except:
            txt = None
        return txt
    
    def __str__(self):
        txt =  f"{self.uuid}, {self.name}, {self.mpn}, {self.manufacturer}, {self.description}"
        if isinstance(self.sds, list):
            for i in self.sds:
                txt += f", {i}"
        txt += f", {self.footprint}, {self.stockQuantity}, {self.quantity}"
        return txt

    def __repr__(self):
        return self.__str__()     

    def __getitem__(self, key)->Any|None:
        if isinstance(key, str):
            return getattr(self, key, None)
        if isinstance(key, int):
            if key < len(self.MAPING_LIST):
                return getattr(self, self.MAPING_LIST[key], None) 
            else:
                return None
    

# 'entry/id' 'entry/quantity' 'entry/part-id' 'entry/designators': ['IC1'] 'entry/name': 'I0056'
class PartsBoxPart(QObject):
    uuid:str|None #OK
    partsCount:int #OK
    designators:list[str]|None #OK
    pidParts:list[str]|list[Any]|None #OK
    isLid:bool #OK
    isPid:bool #OK
    description:str
    footprint:str
    name:str
    sds1:str|None
    sds2:str|None
    mpn:str|None
    manufacturer:str|None
    
    @classmethod
    def fromProjectJson(cls, project:dict|None)->Any|None:
        if project is None: return None
        partId = project.get('entry/part-id', None)
        if partId is None: return None
        designators = project.get('entry/designators', None)
        partsCount = project.get('entry/quantity', 0)
        newObj = cls(partId)
        newObj.partsCount = partsCount
        if isinstance(designators, list):
            newObj.designators = copy.deepcopy(designators)
        return newObj

    def __init__(self, entryUUID:str|None = None):
        self.partsCount = 0
        self.isLid = False
        self.isPid = False
        self.description = ""
        self.footprint = ""
        self.name = ""
        self.uuid = entryUUID
        self.pidParts = None
        self.designatore = None
        self.sds1 = None
        self.sds2 = None
       
    def updateParamFromPartJson(self, json:dict|None)->bool:
        if not isinstance(json, dict): return False
        temp = json.get('part/tags', None)
        if isinstance(temp, list):
            self.isLid = False
            self.isPid = False
            if set(temp).issuperset(["LID"]): self.isLid = True
            if set(temp).issuperset(["PID"]): self.isPid = True
        temp = json.get('part/part-ids', None)
        if isinstance(temp, list):
            self.pidParts = copy.deepcopy(temp)
        self.description = str(json.get('part/description', ""))
        self.footprint = str(json.get('part/footprint', ""))
        self.name = str(json.get('part/name', ""))
        temp = json.get('part/custom-fields', None)
        if isinstance(temp, list):
            for cfield in temp:
                if isinstance(cfield, dict):
                    fk = cfield.get("key", None)
                    if not fk is None:
                        if (fk == "SDS_1"): self.sds1 = cfield.get("value", "")
                        if (fk == "SDS_2"): self.sds2 = cfield.get("value", "")
        self.mpn = json.get('part/mpn', None)
        self.manufacturer = json.get('part/manufacturer', None)
        return True


class PartsBoxProject(QObject):
    bom:list[PartsBoxPart]|None
    notes:str
    name:str
    description:str
    custom_fields:list[dict]|None
    uuid:str
    image:str|None

    def __init__(self, uuid:str):
        super().__init__(None)
        self.bom = None
        self.image = None
        self.notes = ""
        self.name = ""
        self.description = ""
        self.custom_fields = None
        self.uuid = uuid

    @classmethod
    def fromProjectJson(cls, json:dict|None)->Any:
        if not isinstance(json, dict): return None
        uuid = json.get('project/id', None)
        if uuid is None: return None
        return cls(uuid)

    def updateProjectParams(self, json:dict|None)->bool:
        if not isinstance(json, dict): return False
        self.notes = json.get('project/notes', "")
        self.name = json.get('project/name', "")
        self.description = json.get('project/description', "")
        self.custom_fields = copy.deepcopy(json.get('project/custom-fields', []))
        self.image = json.get('project/img-id', None)
        return True
    
    def __deepcopy__(self, memo)->Any:
        newObj = PartsBoxProject(self.uuid)
        newObj.notes = self.notes
        newObj.name = self.name
        newObj.description = self.description
        newObj.image = self.image
        if not self.custom_fields is None:
            newObj.custom_fields = copy.deepcopy(self.custom_fields)
        if not self.bom is None:
            newObj.bom = copy.deepcopy(self.bom)
        return newObj

    def addProjectBomItem(self, part:PartsBoxPart|None)->bool:
        if not isinstance(part, PartsBoxPart): return False
        if self.bom is None:
            self.bom = list()
        self.bom.append(part)
        return True
    
    def cleareBom(self)->None:
        if self.bom is None: return
        self.bom.clear()
        self.bom = None
    
class PartsBoxGetAllPidParts(QRunnable, QObject):
    # eventUpdate:ClassVar[Signal] = Signal(int, int, bool, str)
    eventFinal:ClassVar[Signal] = Signal(bool, str)

    host:str
    reqHeader:str
    retObj:list[PidPart]|None
    
    def __init__(self, host:str, reqHeader:str, parent = None):
        QRunnable.__init__(self)
        QObject.__init__(self, parent)

        self.host = host
        self.reqHeader = reqHeader
        self.retObj = None

    def pidFilter(self, data:list)->bool:
        self.retObj = list()
        for part in data:
            if not isinstance(part, dict): continue
            tags = part.get("part/tags", None)
            if tags is None: continue
            if not set(tags).issuperset(("PID",)): continue
            partObj = PidPart.fromPartJson(part)
            if partObj is None: continue
            self.retObj.append(partObj)
        if len(self.retObj) == 0: return False
        return True


    def getAllParts(self)->bool:
        reqUrl = f'https://{self.host}/part/all'
        reqHeader = self.reqHeader
        body = """{ }"""
        try:
            req = requests.post(reqUrl, headers=reqHeader, data=body, timeout=10)
        except:
            return False
        if req.status_code != 200:
            req.close()
            return False
        req.close()
        jSet = req.json()
        del req
        jSet = jSet.get("data", None)
        if jSet is None: return False
        return self.pidFilter(jSet)

    
    def getPartsRet(self)->list[PidPart]|None:
        return self.retObj
    
    @Slot()
    def run(self)->None:
        # self.eventUpdate.emit(-1, -1, True, "Collect PIDs data")
        if self.getAllParts():
            self.eventFinal.emit(True, "Data collected")
        else:
            self.eventFinal.emit(False, "Error")
        
        
        

class PartsBoxGetBomWorker(QRunnable, QObject):
    # getBomStart:ClassVar[Signal] = Signal(int, bool, str)
    # signal(value, maxValue, Ok/Error, "description")
    getBomUpdate:ClassVar[Signal] = Signal(int, int, bool, str)
    getBomFinaly:ClassVar[Signal] = Signal(bool, str)
    host:str
    reqHeader:str
    retObj:list[PartsBoxProject]|None
    project:PartsBoxProject

    def __init__(self, host:str, reqHeader:str, project:PartsBoxProject, parent = None):
        QRunnable.__init__(self)
        QObject.__init__(self, parent)

        self.host = host
        self.reqHeader = reqHeader
        self.project = project
    
    def getPartDetails(self, part:PartsBoxPart)->bool:
        # self.getBomUpdate.emit(0, 1, True, "Collecting BOM Items")
        reqUrl = f'https://{self.host}/part/get'
        reqHeader = self.reqHeader
        body = """{"part/id":"""+"\""
        body += part.uuid
        body += """"}"""
        try:
            req = requests.post(reqUrl, headers=reqHeader, data=body, timeout=10)
        except:
            # req.close()
            # self.getBomFinaly.emit(False, "Request Error")
            return False
        if req.status_code != 200:
            req.close()
            # self.getBomFinaly.emit(False, "Request Error")
            return False
        req.close()
        jSet = req.json()
        jSet = jSet.get("data", None)
        if jSet is None: return False
        return part.updateParamFromPartJson(jSet)
        # return True

    def countChildPartsInProject(self, project:PartsBoxProject)->int:
        ret:int = 0
        if not isinstance(project.bom, list): return 0
        for part in project.bom:
            if not isinstance(part, PartsBoxPart): continue
            _part:PartsBoxPart = part
            if not isinstance(_part.pidParts, list): continue
            for pUUID in _part.pidParts:
                if not isinstance(pUUID, str): continue
                ret += 1
        return ret

    def getProjectBom(self)->bool:
        # self.getBomUpdate.emit(0, 1, True, "Collecting BOM Items")
        reqUrl = f'https://{self.host}/project/get-entries'
        reqHeader = self.reqHeader
        body = """{"project/id":"""+"\""
        body += self.project.uuid
        body += """"}"""
        try:
            req = requests.post(reqUrl, headers=reqHeader, data=body, timeout=10)
        except:
            # req.close()
            # self.getBomFinaly.emit(False, "Request Error")
            return False
        if req.status_code != 200:
            req.close()
            # self.getBomFinaly.emit(False, "Request Error")
            return False
        req.close()
        jSet = req.json()
        jSet = jSet.get("data", None)
        if jSet is None: return False
        # partList = list()
        for item in jSet:
            i = PartsBoxPart.fromProjectJson(item)
            # i = PartsBoxPart(item, isLid=True)
            if i is not None: self.project.addProjectBomItem(i)
        # self.getBomUpdate.emit(1, 1, True, "Collecting BOM Items")
        return True

    @Slot()
    def run(self)->None:
        ret:bool = True
        self.getBomUpdate.emit(0, 1, True, "Collecting BOM Items")
        if not self.getProjectBom():
            self.getBomFinaly.emit(False, "Error in Project BOM collection")
            return
        self.getBomUpdate.emit(1, len(self.project.bom)+1, True, "Collecting BOM Items")
        
        for i in range(0, len(self.project.bom), 1):
            self.getBomUpdate.emit(i+2, len(self.project.bom)+1, True, "Collecting BOM Main Item (LID): {}".format(self.project.bom[i].uuid))
            if not self.getPartDetails(self.project.bom[i]):
                # self.getBomFinaly.emit(False, "Error in part detail collection")
                self.getBomUpdate.emit(i+2, len(self.project.bom)+1, False, "Error in item: {}".format(self.project.bom[i].uuid))
                ret = False
                continue
            
        
        childPartsToCollect = self.countChildPartsInProject(self.project)
        currentChildPartInd = 1
        self.getBomUpdate.emit(0, childPartsToCollect, True, "Collecting BOM Sub Items")

        for part in self.project.bom:
            if not isinstance(part, PartsBoxPart): continue
            # childPartsList = part.pidParts
            if not isinstance(part.pidParts, list): continue
            for i in range(0, len(part.pidParts), 1):
                if not isinstance(part.pidParts[i], str): continue
                self.getBomUpdate.emit(currentChildPartInd, childPartsToCollect, True, "Collecting BOM Sub Item (PID): {}".format(part.pidParts[i]))
                part.pidParts[i] = PartsBoxPart(part.pidParts[i])
                if not self.getPartDetails(part.pidParts[i]):
                    self.getBomUpdate.emit(currentChildPartInd, childPartsToCollect, False, "Error in item: {}".format(part.pidParts[i].uuid))
                currentChildPartInd += 1

        if(ret):
            self.getBomFinaly.emit(True, "Ok")
        else:
            self.getBomFinaly.emit(False, "Error in Project BOM collection")


class PartsBoxGetProjectsWorker(QRunnable, QObject):
    getProjectUpdate:ClassVar[Signal] = Signal(int, bool, str)
    getProjectFinaly:ClassVar[Signal] = Signal(bool, str)
    host:str
    reqHeader:str
    retObj:list[PartsBoxProject]|None

    def __init__(self, host:str, reqHeader:str, parent = None):
        # super(PartsBoxWrapperAddPidStockWorker, self).__init__(parent)
        QRunnable.__init__(self)
        QObject.__init__(self, parent)
        self.host = host
        self.retObj = None
        self.reqHeader = reqHeader

    def projectFilter(self, tags:list[str], jSet:dict)->list[PartsBoxProject]|None:
        projectsData:list[PartsBoxProject] = list()
        tempList:list|None = None
        for key, item in jSet.items():
            if key == "data":
                tempList = item
                break
        if tempList is None: return None
        for item in tempList:
            i = item.get("project/tags", None)
            if i is None: continue
            if not set(i).issuperset(tags): continue
            # uuid = item.get('project/id', None)
            # if uuid is None: continue
            if isinstance(i, list):
                projObj:PartsBoxProject|None = PartsBoxProject.fromProjectJson(item)
                if not isinstance(projObj, PartsBoxProject):continue
                projObj.updateProjectParams(item)
                projectsData.append(projObj)
        return projectsData

    def getProjectImage(self, proj:PartsBoxProject)->bool:
        if not isinstance(proj.image, str): return False
        reqUrl = f'https://{self.host}/files/download'
        reqHeader = self.reqHeader
        body = """{"file/id":"""+"\""
        body += proj.image
        body += """"}"""
        try:
            req = requests.post(reqUrl, headers=reqHeader, data=body, timeout=10)
        except:
            # req.close()
            # self.getBomFinaly.emit(False, "Request Error")
            return False
        if req.status_code != 200:
            req.close()
            # self.getBomFinaly.emit(False, "Request Error")
            return False
        req.close()
        # imgContrent = req.content
        try:
            temp = QImage()
            temp.loadFromData(req.content)
            proj.image = QPixmap(temp)
            # temp = QPixmap(req.content)
            # proj.image = temp
        except:
            return False
        return True
    
    @Slot()
    def run(self)->None:
        reqUrl = f'https://{self.host}/project/all'
        reqHeader = self.reqHeader
        body = """{ }"""

        try:
            req = requests.post(reqUrl, headers=reqHeader, data=body, timeout=10)
        except:
            # req.close()
            self.getProjectFinaly.emit(False, "Request Error")
            return
        if req.status_code != 200:
            req.close()
            self.getProjectFinaly.emit(False, "Request Error")
            return
        req.close()
        jSet = req.json()
        self.retObj = self.projectFilter(["PCBA"], jSet)

        for proj in self.retObj:
            self.getProjectImage(proj)
        # self.getProjectLidBom(ret[0])
        self.getProjectFinaly.emit(True, "Ok")


class PartsBoxWrapper(QObject):
    host:str
    reqHeader:str
    workerThreadPool:QThreadPool
    lastRet:list[PartsBoxProject]|None
    pidPartsRet:list[PidPart]|None
    partsBoxWorkerObj:Any|PartsBoxGetProjectsWorker
    partsBoxGetBomWorker:PartsBoxGetBomWorker
    partsBoxGetAllPidParts:PartsBoxGetAllPidParts

    getProjectsDone:ClassVar[Signal] = Signal(bool, str)

    getProjectBomUpdate:ClassVar[Signal] = Signal(int, int, bool, str)
    getProjectBomDone:ClassVar[Signal] = Signal(bool, str)

    # getAllPidPartsUpdate:ClassVar[Signal] = Signal(int, int, bool, str)
    getAllPidPartsDone:ClassVar[Signal] = Signal(bool, str)

    def __init__(self, host:str, apiKey:str,):
        super().__init__(None)
        self.host = host
        self.retObj = None
        self.pidPartsRet = None
        self.reqHeader = {
            'Content-Type': 'application/json',
            'Authorization': f'APIKey {apiKey}'}
        self.workerThreadPool = QThreadPool()
        self.lastRet = None

    @Slot(bool, str)
    def slot_getProjectFinaly(self, isSucess:bool, message:str)->None:
        self.lastRet = copy.deepcopy(self.partsBoxWorkerObj.retObj)
        # self.partsBoxWorkerObj.getProjectFinaly.disconnect(self.slot_getProjectFinaly)
        self.getProjectsDone.emit(isSucess, message)
        del self.lastRet

    @Slot(int, int, bool, str)
    def slot_getProjectBomUpdate(self, value:int, max:int, sucess:bool, desc:str)->None:
        self.getProjectBomUpdate.emit(value, max, sucess, desc)
    
    @Slot(bool, str)
    def slot_getProjectBomFinally(self, isSucess:bool, message:str)->None:
        # self.partsBoxGetBomWorker.getBomUpdate.disconnect(self.slot_getProjectBomUpdate)
        # self.partsBoxGetBomWorker.getBomFinaly.disconnect(self.slot_getProjectBomFinally)
        self.getProjectBomDone.emit(isSucess, message)

    @Slot(bool, str)
    def slot_getAllPidPartsDone(self, isSucess:bool, message:str)->None:
        self.pidPartsRet = copy.deepcopy(self.partsBoxGetAllPidParts.getPartsRet())
        # self.partsBoxGetAllPidParts.eventFinal.disconnect(self.slot_getAllPidPartsDone)
        self.getAllPidPartsDone.emit(isSucess, message)
    
    def startGetProjectList(self)->None:
        self.partsBoxWorkerObj = PartsBoxGetProjectsWorker(self.host, self.reqHeader)
        self.partsBoxWorkerObj.getProjectFinaly.connect(self.slot_getProjectFinaly)
        self.workerThreadPool.start(self.partsBoxWorkerObj)
    
    def startGetProjectBom(self, project:PartsBoxProject)->None:
        self.partsBoxGetBomWorker = PartsBoxGetBomWorker(self.host, self.reqHeader, project)
        self.partsBoxGetBomWorker.getBomUpdate.connect(self.slot_getProjectBomUpdate)
        self.partsBoxGetBomWorker.getBomFinaly.connect(self.slot_getProjectBomFinally)
        self.workerThreadPool.start(self.partsBoxGetBomWorker)
    
    def startGetAllPidParts(self)->None:
        self.partsBoxGetAllPidParts = PartsBoxGetAllPidParts(self.host, self.reqHeader)
        self.partsBoxGetAllPidParts.eventFinal.connect(self.slot_getAllPidPartsDone)
        self.workerThreadPool.start(self.partsBoxGetAllPidParts)

    def getLastRet(self)->list[PartsBoxProject]|None:
        return self.lastRet
    
    def getPidPartsRet(self)->list[PidPart]|None:
        return self.pidPartsRet


if __name__ == "__main__":
    pass
    # partsBox = PartsBoxWrapperGetProjectsWorker("api.partsbox.com/api/1",\
    #                                             "partsboxapi_51bn1x55t2hh2b508syx04fdvj7c25e8a1798cd7643fa3ccdc4702743be571eb")
    # partsBox.run()